import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Pressable } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { colors } from '../src/util/colors';
import { getFocusedRouteNameFromRoute } from '@react-navigation/native';

import FrontScreen from './FrontScreen';
import FrontUser from './FrontUser';
import FrontNotif from './FrontNotif';


const Tab = createBottomTabNavigator();

export default function FrontScreenNav() {
  const getTabIconColor = (route, focused, defaultColor) => {
    const routeName = getFocusedRouteNameFromRoute(route) ?? 'FrontScreen';
    if (route.name === 'Front' && routeName !== 'FrontScreen') {
      return colors.l_gray;
    }
    return focused ? colors.secondary : defaultColor;
  };

  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: false,
        tabBarStyle: { height: 100 },
        tabBarButton: (props) => (
          <Pressable
            {...props}
            android_ripple={{ color: 'transparent' }}
            style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}
          >
            {props.children}
          </Pressable>
        ),
      }}
    >
      <Tab.Screen
        name="FrontScreen"
        component={FrontScreen}
        options={({ route }) => ({
          tabBarIcon: ({ focused }) => (
            <Feather name="home" color={getTabIconColor(route, focused, colors.l_gray)} size={22} />
          ),
        })}
      />

      <Tab.Screen
        name="UserTab"
        component={FrontUser}
        options={{
          tabBarIcon: ({ focused }) => (
            <Feather
              name="user"
              color={focused ? colors.secondary : colors.l_gray}
              size={23}
            />
          ),
        }}
      />

      <Tab.Screen
        name="NotifTab"
        component={FrontNotif}
        options={{
          tabBarIcon: ({ focused }) => (
            <Feather
              name="bell"
              color={focused ? colors.secondary : colors.l_gray}
              size={22}
            />
          ),
        }}
      />
    </Tab.Navigator>
  );
}
