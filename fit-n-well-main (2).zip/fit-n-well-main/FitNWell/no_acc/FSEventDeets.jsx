import React from 'react';
import { StyleSheet, Text, View, Image, TouchableOpacity, ScrollView, SafeAreaView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { Entypo } from '@expo/vector-icons';
import { colors } from '../src/util/colors';

const FSEventDeets = ({ route, navigation }) => {
  const { event } = route.params;
  const insets = useSafeAreaInsets(); 

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.headerRow}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
          <Text style={styles.backText}>Events</Text>
        </TouchableOpacity>
      </View>

      {/* Scrollable content with bottom padding so it doesn't go under signInBox */}
      <ScrollView
        style={styles.contentWrapper}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 80 + insets.bottom }} // extra space for bottom box
      >
        <Image source={event.image} style={styles.image} />
        <Text style={styles.title}>{event.title}</Text>
        <View style={styles.i_divider} />

        <View style={styles.row}>
          <Entypo name="pin" size={23} color={colors.main} style={styles.icon} />
          <Text style={styles.eventdeets}>Event Details</Text>
        </View>

        <Text style={styles.label}>
          Date: <Text style={styles.value}>{event.date}</Text>
        </Text>

        <Text style={styles.label}>
          Time: <Text style={styles.value}>{event.time}</Text>
        </Text>

        <View style={styles.ii_divider} />
        <Text style={styles.label}>Description:</Text>
        <Text style={styles.description}>{event.description}</Text>
      </ScrollView>
    
      <View style={[styles.signInBox, { paddingBottom: insets.bottom }]}>
        <View style={styles.signInLabel}>
          <FontAwesome6 name="lock" size={16} color="#fff" style={{ marginRight: 6 }} />
          <Text style={styles.signInText}>Sign in for full access.</Text>
        </View>

        <TouchableOpacity 
          style={styles.signInButton}
          onPress={() => navigation.navigate('SignIn')}
        >
          <Text style={styles.signInButtonText}>Sign in</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

export default FSEventDeets;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 30,
  },
  backText: {
    fontSize: 19,
    marginLeft: 8,
    color: colors.secondary,
    fontFamily: 'InterBold',
    letterSpacing: -0.5,
  },
  contentWrapper: {
    paddingHorizontal: 20,
  },
  image: {
    width: '100%',
    height: 250,
    borderRadius: 10,
    marginTop: 20,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    marginRight: 5,
  },
  title: {
    fontSize: 25,
    fontFamily: 'InterBold',
    letterSpacing: -.5,
    color: colors.d_gray,
    marginTop: 20,
  },
  i_divider: {
    height: 0.2,
    backgroundColor: colors.d_gray,
    marginVertical: 15,
  },
  eventdeets: {
    fontSize: 18,
    fontFamily: 'InterItalic',
    marginTop: 5,
    color: colors.main,
    letterSpacing: -.5,
  },
  label: {
    fontSize: 18,
    fontFamily: 'InterItalic',
    color: colors.l_gray,
    letterSpacing: -.5,
  },
  value: {
    fontSize: 18,
    fontFamily: 'InterBoldItalic',
    color: colors.d_gray,
    letterSpacing: -.5,
  },
  ii_divider: {
    height: 0.4,
    backgroundColor: colors.d_gray,
    marginVertical: 15,
    marginTop: 20,
    marginBottom: 20,
  },
  description: {
    fontSize: 18,
    fontFamily: 'InterItalic',
    color: colors.d_gray,
    letterSpacing: -.5,
    marginBottom: 20,
  },
  signInBox: {
    backgroundColor: colors.secondary,
    paddingVertical: 15,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0, // fixed at bottom
  },
  signInLabel: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  signInText: {
    fontFamily: 'InterItalic',
    fontSize: 14,
    letterSpacing: -.5,
    color: '#fff',
  },
  signInButton: {
    backgroundColor: '#fff', 
    padding: 9, 
    borderRadius: 30, 
    width: "40%",
    height: 40,
    shadowColor: colors.l_gray, 
    shadowOpacity: 0.1, 
    shadowOffset: { width: 0, height: 2 }, 
    elevation: 5,
  },
  signInButtonText: {
    alignSelf: 'center',
    fontSize: 14,
    fontFamily: 'InterBold',
    color: colors.d_gray,
    letterSpacing: -.4, 
  },
});
