import { Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import React from 'react';
import { SafeAreaView } from 'react-native-safe-area-context'; 
import { useNavigation } from '@react-navigation/native';
import { colors } from '../src/util/colors';

const FrontNotif = () => {
  const navigation = useNavigation();

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}> 
      <View style={styles.container}>
        <Image 
          source={require('../src/assets/photos/midbg.png')} 
          style={styles.backgroundImage} 
          resizeMode="cover" 
        />

        <Image source={require('../src/assets/photos/fnw1.png')} style={styles.logo} />
        <Text style={styles.title}>FitNWell</Text>
        <Text style={styles.subtitle}>Let's get started!</Text>

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('SignIn')}>
          <Text style={styles.buttonText}>Sign in</Text>
        </TouchableOpacity>

        <Text style={styles.linkText}>
          {"Don't have an account? "}
          <Text style={styles.link} onPress={() => navigation.navigate('CreateAcc')}>
            Sign up
          </Text>
        </Text>
      </View>
    </SafeAreaView>
  );
};

export default FrontNotif

const styles = StyleSheet.create({
    container: { 
      flex: 1, 
      alignItems: 'center', 
      justifyContent: 'center', 
      backgroundColor: '#fff' 
    },
    backgroundImage: {
      position: 'absolute',
      width: 550,
      height: 750,
      bottom: '30%',
      alignSelf: 'center',
      zIndex: 0,
      opacity: 0.6,
    },
    logo: { 
      width: 210, 
      height: 140, 
      marginTop: 60,
      marginBottom: 20 },
    title: { 
      fontSize: 40, 
      fontFamily: 'InterBoldItalic', 
      letterSpacing: -.4,
      color: colors.d_gray},
    subtitle: { 
      fontSize: 15, 
      fontFamily: 'InterRegular', 
      color: colors.d_gray, 
      letterSpacing: -.4,
      marginBottom: 120 },
    button: {
      backgroundColor: '#fff', 
      padding: 9, 
      borderRadius: 30, 
      width: "53%",
      height: 42,
      shadowColor: colors.l_gray, 
      shadowOpacity: 0.1, 
      shadowOffset: { width: 0, height: 2 }, 
      elevation: 5,
      marginBottom: 10,
      justifyContent: 'center',
      alignItems: 'center'},
    buttonText: { 
      fontSize: 16,
      letterSpacing: -.4,
      fontFamily: 'InterBold',
      color: colors.d_gray },
    linkText: { 
      marginTop: 1,
      fontSize: 13,
      fontFamily: 'InterRegular',
      color: colors.l_gray,
      letterSpacing: -.4 },
    link: { 
      fontSize: 13,
      fontFamily: 'InterBold',
      color: colors.main,
      letterSpacing: -.4  },
  });
  
