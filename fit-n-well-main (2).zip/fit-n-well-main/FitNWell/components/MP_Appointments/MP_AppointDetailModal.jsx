import React from 'react';
import { View, Text, Modal, StyleSheet, TouchableOpacity, SafeAreaView, ScrollView } from 'react-native';
import AntDesign from '@expo/vector-icons/AntDesign';
import { colors } from '../../src/util/colors';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';

export default function MP_AppointDetailModal({ visible, onClose, activity, onConfirm }) {
  if (!activity) return null;

  const statusColor = {
    Pending: colors.pending,
    Completed: colors.secondary,
    Approved: colors.main,
    Missed: colors.d_gray,
  }[activity.status] || colors.l_gray;

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const month = date.toLocaleString('en-US', { month: 'long' });
    const day = date.getDate().toString().padStart(2, '0');
    const year = date.getFullYear();
    return `${month} ${day}, ${year}`;
  };

  const handleConfirm = () => {
    if (onConfirm) {
      onConfirm(activity);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="fade">
      <SafeAreaView style={styles.overlay}>
        <View style={styles.modalBox}>
          {/* Header with Title & Close Icon */}
          <View style={styles.headerRow}>
            <Text style={styles.title}>Session{'\n'}Scheduled</Text>
            <TouchableOpacity style={styles.closeButton} onPress={onClose}>
              <AntDesign name="closecircle" size={26} color={colors.l_gray} />
            </TouchableOpacity>
          </View>
          
          {/* Horizontal line */}
          <View style={styles.separator} />

          {/* Scrollable Content */}
          <ScrollView 
            contentContainerStyle={{ paddingBottom: 20 }} 
            showsVerticalScrollIndicator={false}
          >
            {/* Details + Status Row */}
            <View style={styles.row}>
              {/* Left: Details */}
              <View style={styles.detailsColumn}>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Date</Text>
                  <Text style={styles.detailValue}>{formatDate(activity.date)}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Time</Text>
                  <Text style={styles.detailValue}>{activity.time}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Place</Text>
                  <Text style={styles.detailValue}>{activity.place}</Text>
                </View>
              </View>
              
              {/* Vertical Divider */}
              <View style={styles.verticalDivider} />
              
              {/* Right: Status */}
              <View style={styles.statusColumn}>
                <View style={[styles.statusBadge, { backgroundColor: statusColor }]}>
                  <Text style={styles.statusText}>{activity.status}</Text>
                </View>
              </View>
            </View>

            {/* Bottom horizontal line */}
            <View style={styles.separator} />

            {/* Reminder Section for Pending */}
            {activity.status === 'Pending' ? (
              <View style={styles.reminderSection}>
                <Text style={styles.reminderTitle}>Reminder</Text>
                <Text style={styles.reminderText}>
                  Kindly check your schedule to make sure you don't miss your appointment.
                </Text>
              </View>
            ) : null}

            {/* Action Section for Missed */}
            {activity.status === 'Missed' && (
              <View style={styles.actionSection}>
                <View style={styles.actionContent}>
                  <MaterialCommunityIcons
                    name="timer-sand-complete"
                    size={60}
                    color={colors.secondary}
                    style={[
                      styles.actionIcon,
                      { transform: [{ rotate: '9deg' }], marginTop: 0 },
                    ]}
                  />
                  <Text style={styles.actionQuestion}>
                    Would you like to choose a {'\n'} new date and time?
                  </Text>
                  <TouchableOpacity style={styles.confirmButton} onPress={handleConfirm}>
                    <Text style={styles.confirmButtonText}>Confirm</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
          </ScrollView>
        </View>
      </SafeAreaView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  modalBox: {
    height: '80%',
    width: '91%',
    backgroundColor: '#fff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 20,
    paddingTop: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 10,
  },
  closeButton: {
    padding: 4,
    marginTop: -21,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
    marginTop: 10,
  },
  title: {
    fontSize: 30,
    fontFamily: 'InterBold',
    letterSpacing: -1,
    color: colors.secondary,
    flex: 1,
    lineHeight: 32,
  },
  separator: {
    height: 1,
    backgroundColor: colors.l_gray,
    marginVertical: 10,
    marginTop: 5,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'stretch',
    minHeight: 120,
  },
  detailsColumn: {
    flex: 1,
    justifyContent: 'center',
  },
  statusColumn: {
    width: 110,
    justifyContent: 'flex-start',
    marginTop: 5,
    alignItems: 'center',
  },
  verticalDivider: {
    width: 1,
    backgroundColor: colors.l_gray,
    marginHorizontal: 15,
    height: '98%', 
  },
  detailRow: {
    marginBottom: 12,
  },
  detailLabel: {
    fontSize: 15,
    fontFamily: 'InterRegular',
    letterSpacing: -0.5,
    color: colors.d_gray,
    marginBottom: 3,
  },
  detailValue: {
    fontSize: 15,
    fontFamily: 'InterBold',
    letterSpacing: -0.5,
    color: colors.d_gray,
  },
  statusBadge: {
    alignSelf: 'center',
    paddingVertical: 5,
    paddingHorizontal: 15,
    borderRadius: 8,
    minWidth: 80,
    alignItems: 'center',
  },
  statusText: {
    color: colors.inp,
    fontFamily: 'InterBold',
    fontSize: 15,
    letterSpacing: -.3,
  },
  reminderSection: {
    marginBottom: 10,
  },
  reminderTitle: {
    fontSize: 22,
    fontFamily: 'InterBold',
    letterSpacing: -0.5,
    color: colors.main,
    marginBottom: 10,
    marginLeft: 40,
  },
  reminderText: {
    fontSize: 15,
    fontFamily: 'InterItalic',
    letterSpacing: -0.5,
    color: colors.d_gray,
    lineHeight: 22,
    marginLeft: 40,
    marginRight: 30,
  },
  actionSection: {
    marginTop: 10,
  },
  actionContent: {
    alignItems: 'center',
  },
  actionIcon: {
    marginBottom: 15,
  },
  actionQuestion: {
    fontSize: 15,
    fontFamily: 'InterRegular',
    letterSpacing: -0.5,
    color: colors.d_gray,
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 22,
  },
  confirmButton: {
    backgroundColor: '#fff',
    padding: 9,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: -1,
    marginBottom: 45,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
    width: '53%',
    height: 40,
    alignSelf: 'center',
  },
  confirmButtonText: {
    fontSize: 16,
    fontFamily: 'InterBold',
    letterSpacing: -0.4,
    color: colors.d_gray,
  },
});