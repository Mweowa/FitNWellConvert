import React from 'react';
import { View, Text, StyleSheet, SafeAreaView, TouchableOpacity } from 'react-native';
import { colors } from '../../src/util/colors';

export default function MP_AppointCard({ date, title, status, timeLabel, time, place, onPress }) {

  const statusColor = {
    Pending: colors.pending,
    Completed: colors.secondary,
    Approved: colors.main,
    Missed: colors.d_gray,
  }[status] || colors.l_gray;

  // Format date to match image format (e.g., "06, June 2025")
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = date.toLocaleString('en-US', { month: 'long' });
    const year = date.getFullYear();
    return `${day}, ${month} ${year}`;
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <TouchableOpacity activeOpacity={0.8} onPress={onPress}>
        <View style={styles.card}>
          <Text style={styles.date} numberOfLines={1} adjustsFontSizeToFit={true}>{formatDate(date)}</Text>

          <View style={styles.ii_divider} />
          
          <View style={styles.contentRow}>
            <View style={styles.detailsColumn}>
              <Text style={styles.timeLabel}>Time</Text>
              <Text style={styles.timeValue}>{time}</Text>

              <Text style={styles.placeLabel}>Place</Text>
              <Text style={styles.placeValue}>{place}</Text>
            </View>

            <View style={[styles.statusBadge, { backgroundColor: statusColor }]}>

              <Text style={styles.statusText}>{status}</Text>
            </View>
          </View>
          
          {/* Vertical divider positioned after content */}
          <View style={styles.iii_divider} />
        </View>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  card: {
    backgroundColor: colors.inp,
    paddingHorizontal: 20,
    padding: 15,
    width: 330,
    height: 160,
    borderRadius: 15,
    marginBottom: 15,
    justifyContent: 'center',
    position: 'relative',
  },
  date: { 
    fontFamily: "InterBold",
    fontSize: 28,
    color: colors.secondary,
    letterSpacing: -.3,
    marginBottom: -10,
    marginTop: -5,
    flexWrap: 'nowrap',
    numberOfLines: 1,
  },
  ii_divider: {
    height: 0.34,
    backgroundColor: colors.l_gray,
    marginVertical: 15,
    marginBottom: 15,
  },
  iii_divider: {
    width: 0.5,
    height: 100,
    backgroundColor: colors.l_gray,
    position: 'absolute',
    right: 135,
    bottom: 10,
  },
  contentRow: {  
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    marginBottom: 2,
  },
  detailsColumn: {
    flex: 1,
    marginRight: 10,
  },
  timeLabel: { 
    fontSize: 15,  
    fontFamily: "InterRegular",
    color: colors.d_gray,
    letterSpacing: -.5,
    marginTop: -10,
    marginBottom: 4,
  },
  timeValue: {
    fontSize: 15,
    fontFamily: "InterBold",
    color: colors.d_gray,
    marginBottom: 8,
    marginTop: -5,
    letterSpacing: -0.5,
  },
  placeLabel: { 
    fontSize: 15,  
    fontFamily: "InterRegular",
    color: colors.d_gray,
    letterSpacing: -.5,
    marginTop: 0,
    marginBottom: 4,
  },
  placeValue: {
    fontSize: 15,
    fontFamily: "InterBold",
    color: colors.d_gray,
    marginTop: -5,
    letterSpacing: -0.5,
  },
  statusBadge: {
    alignSelf: 'flex-start',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 6,
    marginLeft: 10,
    minHeight: 32,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 48,
  },
  statusText: { 
    color: colors.inp, 
    fontFamily: "InterBold",
    fontSize: 15,
    letterSpacing: -.3,
  },
});