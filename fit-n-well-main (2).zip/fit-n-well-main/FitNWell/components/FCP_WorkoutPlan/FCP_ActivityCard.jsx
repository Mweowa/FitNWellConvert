import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { colors } from '../../src/util/colors';

// Helper function to format the date string
const formatDate = (dateString) => {
    if (!dateString || isNaN(new Date(dateString))) {
        return ''; // Or return a default message like 'Invalid Date'
    }
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        month: 'long',
        day: '2-digit',
        year: 'numeric',
    });
};

export default function FCP_ActivityCard({
    startDate,
    endDate,
    title,
    status,
    onPress,
    // The new props we added in the parent component
    isCompletedDay,
    completedDate,
}) {
    const statusColor = {
        Ongoing: colors.secondary,
        Done: colors.verified,
        Missed: colors.rejected,
    }[status] || colors.l_gray;

    // This is the key change: Conditionally determine the date string to display
    // Now it checks for the isCompletedDay flag and uses the completedDate prop
    const dateToDisplay = isCompletedDay && completedDate
        ? `${formatDate(completedDate)}`
        : `${formatDate(startDate)} - ${formatDate(endDate)}`;

    return (
        <TouchableOpacity activeOpacity={0.8} onPress={onPress} style={styles.cardContainer}>
            <View style={styles.card}>
                {/* Display the determined date */}
                <Text style={styles.date}>{dateToDisplay}</Text>

                {/* Changed layout: Title on top, status badge below */}
                <View style={styles.titleColumn}>
                    <Text style={styles.title} numberOfLines={1}>
                        {title}
                    </Text>
                    <View style={[styles.statusBadge, { backgroundColor: statusColor }]}>
                        <Text style={styles.statusText}>{status}</Text>
                    </View>
                </View>
            </View>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    cardContainer: {
        width: 330,
        height: 140,
        borderRadius: 15,
        marginBottom: 15,
        alignSelf: 'center', // Centers the card within its parent
    },
    card: {
        backgroundColor: colors.inp,
        paddingHorizontal: 20,
        paddingVertical: 15, // Changed from 'padding' to 'paddingVertical' for consistency
        flex: 1, // Card now takes up the full space of its container
        justifyContent: 'center',
        borderRadius: 15,
    },
    date: {
        fontFamily: 'InterLight',
        fontSize: 15,
        color: colors.d_gray,
        letterSpacing: -0.3,
        marginBottom: -3,
    },
    // New: stacked column layout for title and badge
    titleColumn: {
        flexDirection: 'column',
        alignItems: 'flex-start', // Aligns badge under title
    },
    title: {
        fontSize: 28,
        fontFamily: 'InterBold',
        color: colors.d_gray,
        letterSpacing: -1,
        marginBottom: 5, // Space between title and badge
    },
    statusBadge: {
        alignSelf: 'flex-start',
        paddingVertical: 3,
        paddingHorizontal: 12,
        borderRadius: 5,
        minHeight: 30,
        justifyContent: 'center',
        flexShrink: 0, // Prevents badge from shrinking on long titles
    },
    statusText: {
        color: colors.inp,
        fontFamily: 'InterBold',
        fontSize: 15,
        letterSpacing: -0.3,
    },
});
