import React from 'react';
import { View, TouchableOpacity, Image, StyleSheet, Platform, SafeAreaView } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import Ionicons from '@expo/vector-icons/Ionicons';
import { colors } from '../src/util/colors';

const HeaderContent = () => {
  const navigation = useNavigation();
  const route = useRoute();

  const canGoBack = navigation.canGoBack();
  const isRootScreen = route.name === 'HomeMain';

  const alwaysGoHomeScreens = ['User','Notif', 'RoutePlanning','FitnessSelection', 'FitnessCoach', 'Appointment','ActivityLogger','Recommended']; // ✅ Add other screens here if needed

  const handleLeftPress = () => {
    if (alwaysGoHomeScreens.includes(route.name)) {
      // ✅ For these screens, reset navigation to Home
      navigation.reset({
        index: 0,
        routes: [
          {
            name: 'MainApp',
            state: {
              index: 0,
              routes: [
                {
                  name: 'MainTabs',
                  state: {
                    index: 0,
                    routes: [{ name: 'Home' }], 
                  },
                },
              ],
            },
          },
        ],
      });
    } else if (isRootScreen && navigation.getParent()) {
      navigation.getParent()?.openDrawer();
    } else if (canGoBack) {
      navigation.goBack();
    }
  };


  return (
    <SafeAreaView style={{ backgroundColor: '#fff' }}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={handleLeftPress} style={styles.iconWrapper}>
          {isRootScreen ? (
            <Ionicons name="menu" size={28} color={colors.l_gray} />
          ) : (
            <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
          )}
        </TouchableOpacity>

        <Image source={require('../src/assets/photos/fnw1.png')} style={styles.logo} />
      </View>
    </SafeAreaView>
  );
};

export default HeaderContent;

const styles = StyleSheet.create({
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  iconWrapper: {
    marginTop: 30,
  },
  logo: {
    width: 65,
    height: 65,
    resizeMode: 'contain',
    marginTop: 30,
  },
});
