import React from 'react';
import { View, Text, StyleSheet, SafeAreaView, TouchableOpacity } from 'react-native';
import { colors } from '../../src/util/colors';

export default function SRP_ActivityCard({ date, type, status, distance, duration, onPress }) {
  const statusColor = {
    Pending: colors.pending,
    Verified: colors.verified,
    Rejected: colors.rejected,
  }[status] || colors.l_gray;

  return (
    <SafeAreaView style={styles.safeArea}>
      <TouchableOpacity activeOpacity={0.8} onPress={onPress}>
        <View style={styles.card}>
          {/* ✅ Date and Title beside each other */}
          <View style={styles.dateTypeRow}>
            <Text style={styles.date}>{date}</Text>
            <Text style={styles.type}>{type}</Text>
          </View>

          {/* Row containing Distance + Status Badge */}
          <View style={styles.typeRow}>
            <Text style={styles.distance}>{distance}</Text>
            <View style={[styles.statusBadge, { backgroundColor: statusColor }]}>
              <Text style={styles.statusText}>{status}</Text>
            </View>
          </View>

          <Text style={styles.duration}>
            Duration: <Text style={{ fontFamily: "InterBold" }}>{duration}</Text>
          </Text>
        </View>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  card: {
    backgroundColor: colors.inp,
    paddingHorizontal: 20,
    padding: 15,
    width: 330,
    height: 140,
    borderRadius: 15,
    marginBottom: 15,
    justifyContent: 'center',
  },
  dateTypeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  date: {
    fontFamily: "InterLight",
    fontSize: 15,
    color: colors.d_gray,
    letterSpacing: -0.3,
  },
  type: {
    fontFamily: "InterMedium",
    fontSize: 15,
    color: colors.d_gray,
    letterSpacing: -0.3,
    maxWidth: 180,
    marginLeft: 10,
    
  },
  typeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 2,
  },
  distance: {
    fontSize: 28,
    fontFamily: "InterBold",
    color: colors.d_gray,
    letterSpacing: -1,
    flexShrink: 1,
  },
  duration: {
    fontSize: 20,
    fontFamily: "InterRegular",
    color: colors.d_gray,
    letterSpacing: -0.5,
    marginTop: 0,
  },
  statusBadge: {
    alignSelf: 'center',
    paddingVertical: 3,
    paddingHorizontal: 12,
    borderRadius: 5,
    marginLeft: 10,
    minHeight: 30,
    justifyContent: 'center',
  },
  statusText: {
    color: colors.inp,
    fontFamily: "InterBold",
    fontSize: 15,
    letterSpacing: -0.3,
  }
});
