import React from 'react';
import {
  View,
  Text,
  Modal,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  Image, // Ensure Image is imported
} from 'react-native';
import AntDesign from '@expo/vector-icons/AntDesign';
import { colors } from '../../src/util/colors';

export default function SRP_ActivityDetailModal({ visible, onClose, activity }) {
  if (!activity) return null;

  const statusColor = {
    Pending: colors.pending,
    Verified: colors.verified,
    Rejected: colors.rejected,
  }[activity.status] || colors.l_gray;

  // Destructure activity properties with default values
  const {
    title = 'Afternoon Walk',
    type,
    description = 'Started at 5:30 AM, through city park and finished near the riverbank. Cool morning breeze and great pace.',
    distance = '6.2 km',
    duration = '38 mins',
    steps = '7,530',
    pace = '6:15',
    elevation = '45m',
    status = 'Pending',
    imageUrl, // Assuming an imageUrl property exists in your activity object
    mapImageUrl, // Assuming a mapImageUrl property for the map static image
  } = activity;

  return (
    <Modal visible={visible} transparent animationType="fade">
      <SafeAreaView style={styles.overlay}>
        <View style={styles.modalBox}>
          {/* Close Button */}
          <TouchableOpacity style={styles.closeBtn} onPress={onClose}>
            <AntDesign name="close" size={22} color={'#666'} />
          </TouchableOpacity>

          <ScrollView contentContainerStyle={styles.scrollContainer} showsVerticalScrollIndicator={false}>
            {/* Distance & Time */}
            <View style={styles.statsContainer}>
              <View style={styles.metricBox}>
                <Text style={styles.metricLabel}>Distance</Text>
                <Text style={styles.metricValue}>{distance}</Text>
              </View>
              <View style={styles.verticalDivider} />
              <View style={styles.metricBox}>
                <Text style={styles.metricLabel}>Time</Text>
                <Text style={styles.metricValue}>{duration}</Text>
              </View>
            </View>

            {/* Steps, Pace, Elevation */}
            <View style={styles.detailsRow}>
              <View style={styles.detailItem}>
                <Text style={styles.detailLabel}>Steps</Text>
                <Text style={styles.detailValue}>{steps}</Text>
              </View>
              <View style={styles.detailItem}>
                <Text style={styles.detailLabel}>Pace</Text>
                <Text style={styles.detailValue}>{pace}</Text>
              </View>
              <View style={styles.detailItem}>
                <Text style={styles.detailLabel}>Elevation</Text>
                <Text style={styles.detailValue}>{elevation}</Text>
              </View>
            </View>

            <View style={styles.divider} />

            {/* Title & Description */}
            <Text style={styles.title}>{title}</Text>
            <Text style={styles.type}>Type: {type}</Text>
            <Text style={styles.description}>{description}</Text>

            {/* Map and Image Row */}
            <View style={styles.mapAndImageRow}>
              {/* Map Container (left box) */}
              {mapImageUrl ? (
                <Image
                  source={{ uri: mapImageUrl }}
                  style={styles.mapBox}
                  resizeMode="cover"
                />
              ) : (
                // Placeholder if no map image is provided
                <View style={[styles.mapBox, styles.placeholderBox]}>
                  <Text style={styles.placeholderText}>Map Unavailable</Text>
                </View>
              )}

              {/* Activity Image (right box) */}
              {imageUrl ? (
                <Image
                  source={{ uri: imageUrl }}
                  style={styles.activityImageBox}
                  resizeMode="cover"
                />
              ) : (
                // Placeholder if no activity image is provided
                <View style={[styles.activityImageBox, styles.placeholderBox]}>
                  <Text style={styles.placeholderText}>No Image</Text>
                </View>
              )}
            </View>

            {/* Status Badge */}
            <View style={[styles.statusBadge, { backgroundColor: statusColor }]}>
              <Text style={styles.statusText}>{status}</Text>
            </View>
          </ScrollView>
        </View>
      </SafeAreaView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  modalBox: {
    height: '80%',
    width: '91%',
    backgroundColor: '#f2f2f2',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 20,
  },
  closeBtn: {
    position: 'absolute',
    top: 15,
    right: 15,
    zIndex: 1,
  },
  scrollContainer: {
    paddingTop: 10,
    paddingBottom: 30,
  },
  // Removed imageContainer and activityImage for the top standalone image
  dateTypeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  dateText: {
    fontSize: 16,
    color: '#333',
  },
  type: {
    fontSize: 15,
    color: colors.d_gray,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  statsContainer: {
    backgroundColor: colors.d_gray,
    borderRadius: 14,
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 20,
    marginBottom: 20,
    marginTop: 30,
  },
  metricBox: {
    alignItems: 'center',
    flex: 1,
  },
  metricLabel: {
    color: colors.inp,
    fontSize: 13,
    marginBottom: 4,
  },
  metricValue: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
  },
  verticalDivider: {
    width: 1,
    backgroundColor: colors.secondary,
    marginHorizontal: 10,
    width: 2,
  },
  detailsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  detailItem: {
    alignItems: 'center',
    flex: 1,
  },
  detailLabel: {
    color: '#666',
    fontSize: 13,
  },
  detailValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    borderBottomWidth: 2,
    borderBottomColor: colors.main,
    paddingBottom: 2,
  },
  divider: {
    height: 1,
    backgroundColor: colors.l_gray,
    marginBottom: 20,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  description: {
    fontSize: 14,
    color: '#666',
    marginBottom: 20,
  },
  mapAndImageRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  mapBox: {
    width: '50%', // Roughly half, accounting for spaceBetween
    height: 110,
    borderRadius: 12,
    backgroundColor: colors.l_gray, // Default background for map area
  },
  activityImageBox: {
    width: '48%', // Roughly half, accounting for spaceBetween
    height: 110,
    borderRadius: 12,
    backgroundColor: colors.l_gray, // Default background for map area
  },
  placeholderBox: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  placeholderText: {
    color: colors.d_gray,
    fontSize: 14,
  },
  statusBadge: {
    alignSelf: 'center',
    paddingVertical: 6,
    paddingHorizontal: 20,
    borderRadius: 8,
    marginTop: 20,
  },
  statusText: {
    fontWeight: 'bold',
    color: '#fff',
    fontSize: 14,
  },
});