import React from 'react';
import {
    View,
    Text,
    Modal,
    StyleSheet,
    TouchableOpacity,
    SafeAreaView,
    ScrollView
} from 'react-native';
import AntDesign from '@expo/vector-icons/AntDesign';
import { colors } from '../../src/util/colors';

export default function FCP_ActivityHistoryDetailModal({ visible, onClose, activity }) {
    if (!activity) return null;

    // Map your workout plan structure to categories
    const groupedExercises = {
        "Warm Up": activity.warmUp || [],
        "Main Exercise": activity.mainExercise || [],
        "Cool Down": activity.coolDown || []
    };

    return (
        <Modal visible={visible} transparent animationType="fade">
            <SafeAreaView style={styles.overlay}>
                <View style={styles.modalBox}>
                    
                    {/* Header */}
                    <View style={styles.headerRow}>
                        <Text style={styles.title} numberOfLines={1}>
                            {activity.title || 'Workout Plan'}
                        </Text>
                        <TouchableOpacity onPress={onClose}>
                            <AntDesign name="closecircle" size={26} color={colors.l_gray} />
                        </TouchableOpacity>
                    </View>

                    {/* Exercises List */}
                    <ScrollView contentContainerStyle={styles.scrollContent}>
                        {Object.keys(groupedExercises).map((cat) => (
                            <View key={cat} style={{ marginBottom: 20 }}>
                                <Text style={styles.categoryHeader}>{cat}</Text>
                                {groupedExercises[cat].length > 0 ? (
                                    groupedExercises[cat].map((ex, idx) => (
                                        <View key={idx} style={styles.exerciseItem}>
                                            {/* Bullet point and exercise text are combined */}
                                            <Text style={styles.bulletText}>
                                                • {ex.name}
                                                {ex.sets && ex.reps ? ` - ${ex.sets}x${ex.reps}` : ex.time ? ` - ${ex.time}` : ''}
                                            </Text>
                                        </View>
                                    ))
                                ) : (
                                    <Text style={styles.noExerciseText}>No exercises in this category</Text>
                                )}
                            </View>
                        ))}
                    </ScrollView>
                </View>
            </SafeAreaView>
        </Modal>
    );
}

const styles = StyleSheet.create({
    overlay: {
        flex: 1,
        justifyContent: 'flex-end',
        alignItems: 'center',
        backgroundColor: 'rgba(0,0,0,0.3)',
    },
    modalBox: {
        height: '85%',
        width: '91%',
        backgroundColor: '#fff',
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        paddingHorizontal: 20,
        paddingTop: 15,
        elevation: 10,
    },
    headerRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 10,
        marginTop: 10,
    },
    title: {
        fontSize: 26,
        fontFamily: 'InterBold',
        color: colors.l_gray,
        flex: 1,
        marginRight: 10,
    },
    scrollContent: {
        paddingBottom: 20
    },
    categoryHeader: {
        fontSize: 18,
        fontFamily: 'InterBold',
        color: colors.main,
        marginBottom: 6,
    },
    exerciseItem: {
        // We'll just style the text directly instead of a separate row
        marginBottom: 8,
    },
    bulletText: {
        fontSize: 16,
        fontFamily: 'InterRegular',
        color: colors.d_gray,
    },
    noExerciseText: {
        fontSize: 14,
        fontFamily: 'InterRegular',
        color: colors.l_gray,
        fontStyle: 'italic'
    }
});
