import React from 'react';
import { View, Text, StyleSheet, SafeAreaView, TouchableOpacity } from 'react-native';
import { colors } from '../../src/util/colors';

export default function FCP_ActivityHistoryCard({ date, title, type, status, exercises = [], onPress }) {
  const statusColor = {
    Pending: colors.pending,
    Verified: colors.verified,
    Rejected: colors.rejected,
  }[status] || colors.l_gray;

  return (
    <SafeAreaView style={styles.safeArea}>
      <TouchableOpacity activeOpacity={0.8} onPress={onPress}>
        <View style={styles.card}>
          {/* Date & Title */}
          <Text style={styles.date}>{date}</Text>
          <Text style={styles.title}>{title}</Text>
          {type && <Text style={styles.type}>{type}</Text>}

          {/* Exercise list preview */}
          {exercises.length > 0 && (
            <View style={styles.exerciseList}>
              {exercises.map((ex, index) => (
                <Text key={index} style={styles.exerciseText}>
                  • {ex.name} – {ex.sets}×{ex.reps}
                </Text>
              ))}
            </View>
          )}

          {/* Status Badge */}
         
        </View>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  card: {
    backgroundColor: colors.inp,
    paddingHorizontal: 20,
    paddingVertical: 15,
    width: 330,
    borderRadius: 15,
    marginBottom: 15,
  },
  date: {
    fontFamily: "InterLight",
    fontSize: 15,
    color: colors.d_gray,
    letterSpacing: -0.3,
    marginBottom: 5,
  },
  title: {
    fontSize: 22,
    fontFamily: "InterBold",
    color: colors.d_gray,
    letterSpacing: -1,
    marginBottom: 4,
  },
  type: {
    fontSize: 16,
    fontFamily: "InterRegular",
    color: colors.d_gray,
    marginBottom: 8,
  },
  exerciseList: {
    marginTop: 6,
    marginBottom: 8,
  },
  exerciseText: {
    fontSize: 15,
    fontFamily: "InterRegular",
    color: colors.d_gray,
    marginBottom: 2,
  },
 
});
