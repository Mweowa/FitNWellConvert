import React from 'react';
import { View, TouchableOpacity, Text, StyleSheet } from 'react-native';
import { colors } from '../../src/util/colors';


export default function FRS_TabSwitch({ activeTab, setActiveTab }) {
  return (
    <View style={styles.container}>
      {['Awaiting', 'History'].map(tab => (
        <TouchableOpacity
          key={tab}
          style={[styles.tab, activeTab === tab && styles.activeTab]}
          onPress={() => setActiveTab(tab)}>
          <Text style={[styles.tabText, activeTab === tab && styles.activeTabText]}>{tab}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flexDirection: 'row', 
    backgroundColor: colors.inp, 
    borderRadius: 30, 
    margin: 15, 
    padding: 5,
    marginTop: 20,
    marginBottom: 3,
    elevation: 5,
    shadowColor: colors.d_gray, 
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
  },
  tab: { 
    flex: 1, 
    paddingVertical: 15, 
    borderRadius: 40, 
    alignItems: 'center',
  },
  activeTab: { 
    backgroundColor: colors.main,
  },
  tabText: { 
    fontFamily: "InterBold",
    fontSize: 15,
    color: colors.d_gray,
    letterSpacing: -.1,
  },
  activeTabText: { 
    color: colors.inp 
  },
});
