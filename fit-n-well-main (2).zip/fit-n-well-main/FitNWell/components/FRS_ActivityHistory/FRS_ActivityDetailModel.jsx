import React from 'react';
import { View, Text, Modal, StyleSheet, TouchableOpacity, SafeAreaView, ScrollView, Image } from 'react-native';
import AntDesign from '@expo/vector-icons/AntDesign';
import { colors } from '../../src/util/colors';

export default function FRS_ActivityDetailModal({ visible, onClose, activity }) {
  if (!activity) return null;

  const statusColor = {
    Pending: colors.pending,
    Verified: colors.verified,
    Rejected: colors.rejected,
  }[activity.status] || colors.l_gray;

  return (
    <Modal visible={visible} transparent animationType="fade">
      <SafeAreaView style={styles.overlay}>
        <View style={styles.modalBox}>

          {/* Header with Title & Close Icon */}
          <View style={styles.headerRow}>
            <Text style={styles.title}>{activity.title}</Text>
            <TouchableOpacity onPress={onClose}>
              <AntDesign name="closecircle" size={26} color={colors.l_gray} />
            </TouchableOpacity>
          </View>

          {/* Scrollable Content */}
          <ScrollView 
            contentContainerStyle={{ paddingBottom: 20 }} 
            showsVerticalScrollIndicator={false}
          >
            {activity.image ? (
              <Image source={{ uri: activity.image }} style={styles.photoBox} />
            ) : (
              <View style={styles.photoBox} />
            )}
            
            <Text style={styles.deet_head}>Activity Details</Text>
            <Text style={styles.type}>
              Type: <Text style={{ fontFamily: 'InterBold' }}>{activity.type}</Text>
            </Text>
            <Text style={styles.date}>
              Date: <Text style={{ fontFamily: 'InterBold' }}>{activity.date}</Text>
            </Text>

            <View style={styles.i_divider} />

            <View style={[styles.statusBadge, { backgroundColor: statusColor }]}>
              <Text style={styles.statusText}>{activity.status}</Text>
            </View>
          </ScrollView>

        </View>
      </SafeAreaView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  modalBox: {
    height: '80%',
    width: '91%',
    backgroundColor: '#fff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 20,
    paddingTop: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 10,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
    marginTop: 10,
  },
  title: {
    fontSize: 28,
    fontFamily: 'InterBold',
    letterSpacing: -1,
    color: colors.l_gray,
    flex: 1,
    marginRight: 10,
  },
  photoBox: {
    width: '100%',
    height: 200,
    backgroundColor: colors.inp,
    borderRadius: 10,
    marginVertical: 10,
    marginBottom: 20,
  },
  deet_head: {
    fontSize: 22,
    fontFamily: 'InterBold',
    letterSpacing: -0.5,
    color: colors.main,
    marginBottom: 10,
  },
  type: {
    fontSize: 18,
    fontFamily: 'InterRegular',
    letterSpacing: -0.5,
    color: colors.d_gray,
    marginBottom: -5,
  },
  date: {
    fontSize: 18,
    fontFamily: 'InterRegular',
    letterSpacing: -0.5,
    color: colors.d_gray,
    marginBottom: 15,
  },
  i_divider: {
    height: 0.5,
    backgroundColor: colors.l_gray,
    marginVertical: 15,
  },
  statusBadge: {
    alignSelf: 'center',
    paddingVertical: 5,
    paddingHorizontal: 15,
    borderRadius: 8,
    marginTop: 15,
  },
  statusText: {
    color: colors.inp,
    fontFamily: 'InterBold',
    fontSize: 16,
  },
});
