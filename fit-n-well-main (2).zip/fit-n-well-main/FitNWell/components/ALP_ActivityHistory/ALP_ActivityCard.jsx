import React from 'react';
import { View, Text, StyleSheet, SafeAreaView, TouchableOpacity } from 'react-native';
import { colors } from '../../src/util/colors';

export default function ALP_ActivityCard({ date, title, type, status, onPress }) {
  const statusColor = {
    Pending: colors.pending,
    Verified: colors.verified,
    Rejected: colors.rejected,
  }[status] || colors.l_gray;

  return (
    <SafeAreaView style={styles.safeArea}>
      {/* ✅ Wrap card with TouchableOpacity to make it clickable */}
      <TouchableOpacity activeOpacity={0.8} onPress={onPress}>
        <View style={styles.card}>
          <Text style={styles.date}>{date}</Text>

          {/* Row containing Title + Status Badge */}
          <View style={styles.titleRow}>
            <Text style={styles.title}>{title}</Text>
            <View style={[styles.statusBadge, { backgroundColor: statusColor }]}>
              <Text style={styles.statusText}>{status}</Text>
            </View>
          </View>

          <Text style={styles.type}>
            Activity: <Text style={{ fontFamily: "InterBold" }}>{type}</Text>
          </Text>
        </View>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  card: {
    backgroundColor: colors.inp,
    paddingHorizontal: 20,
    padding: 15,
    width: 330,
    height: 140,
    borderRadius: 15,
    marginBottom: 15,
    justifyContent: 'center',
  },
  date: { 
    fontFamily: "InterLight",
    fontSize: 15,
    color: colors.d_gray,
    letterSpacing: -.3,
    marginBottom: -5,
  },
  titleRow: {  
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 2,
  },
  title: { 
    fontSize: 28, 
    fontFamily: "InterBold", 
    color: colors.d_gray, 
    letterSpacing: -1,
    flexShrink: 1,
  },
  type: { 
    fontSize: 20,  
    fontFamily: "InterRegular",
    color: colors.d_gray,
    letterSpacing: -.5,
    marginTop: 0,
  },
  statusBadge: {
    alignSelf: 'center',
    paddingVertical: 3,
    paddingHorizontal: 12,
    borderRadius: 5,
    marginLeft: 10,
    minHeight: 30,
    justifyContent: 'center',
  },
  statusText: { 
    color: colors.inp, 
    fontFamily: "InterBold",
    fontSize: 15,
    letterSpacing: -.3,
  }
});
