import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { DrawerContentScrollView } from '@react-navigation/drawer';
import { Feather } from '@expo/vector-icons';
import { colors } from '../src/util/colors';

export default function DrawerContent (props) {
  return (
    <DrawerContentScrollView {...props}>
      <View style={styles.header}>
        <View style={styles.avatar} />
        <Text style={styles.name}>Gracielle Moribus</Text>
        <Text style={styles.role}>Academic Staff</Text>
      </View>
      
      <View style={styles.dividerWrapper}>
        <View style={styles.i_divider} />
      </View>

      <View style={styles.extraOptions}>
        <TouchableOpacity
          style={styles.row} onPress={() => props.navigation.navigate('MainTabs')}
        >
          <Feather name="home" size={18} color={colors.main} />
          <Text style={styles.i_text}>Home</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.row}
          onPress={() => props.navigation.navigate('MainTabs', { screen: 'UserTab' })}
        >
          <Feather name="user" size={18} color={colors.main} />
          <Text style={styles.i_text}>Profile</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.row}
          onPress={() => props.navigation.navigate('MainTabs', { screen: 'NotifTab' })}
        >
          <Feather name="bell" size={18} color={colors.main} />
          <Text style={styles.i_text}>Notification</Text>
        </TouchableOpacity>

        <View style={styles.ii_divider} />

        <View style={styles.otherOptions}>
          <TouchableOpacity style={styles.row} onPress={() => alert('Settings coming soon')}>
            <Feather name="settings" size={16} color={colors.l_gray} />
            <Text style={styles.ii_text}>Settings and Privacy</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.row} onPress={() => alert('Help Center coming soon')}>
            <Feather name="help-circle" size={16} color={colors.l_gray} />
            <Text style={styles.ii_text}>Help Center</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.row} onPress={() => props.navigation.navigate('SignIn')}>
            <Feather name="log-out" size={16} color={colors.l_gray} />
            <Text style={styles.ii_text}>Logout</Text>
          </TouchableOpacity>
        </View>
      </View>
    </DrawerContentScrollView>
  );
}

const styles = StyleSheet.create({
  header: {
    padding: 20,
    justifyContent: 'flex-start',
  },
  avatar: {
    width: 90,
    height: 90,
    backgroundColor: colors.l_gray,
    borderRadius: 70,
    marginBottom: 10,
  },
  name: {
    fontFamily: 'InterBold',
    letterSpacing: -0.5,
    fontSize: 25,
    color: colors.d_gray,
  },
  role: {
    fontFamily: 'InterRegular',
    fontSize: 15,
    letterSpacing: -0.3,
    color: colors.l_gray,
  },
  dividerWrapper: {
    paddingHorizontal: 20, 
  },
  i_divider: {
    height: 0.2,
    backgroundColor: colors.l_gray,
    marginVertical: 15,
    width: '100%',
    alignSelf: 'center',
  },
  extraOptions: {
    marginTop: 10,
    paddingHorizontal: 20,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
  },
  i_text: {
    fontFamily: 'InterBold',
    fontSize: 18,
    letterSpacing: -0.5,
    marginLeft: 10,
    color: colors.d_gray
  },
  ii_divider: {
    height: 0.5,
    backgroundColor: colors.l_gray,
    marginVertical: 15,
    width: '100%',
    alignSelf: 'center',
    marginTop: 25,
  },
  otherOptions: {
    marginTop: 10,
  },
  ii_text: {
    fontFamily: 'InterRegular',
    fontSize: 13,
    letterSpacing: -.5,
    marginLeft: 10,
    color: colors.l_gray
  },
});
