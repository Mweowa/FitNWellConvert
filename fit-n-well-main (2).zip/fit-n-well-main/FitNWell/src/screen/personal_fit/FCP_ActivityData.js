// src/screens/fitnesscoach/FCP_ActivityData.js
export const INITIAL_ACTIVITIES = [
    {
        id: '1',
        startDate: '2025-08-04',
        endDate: '2025-08-17',
        title: 'Workout Plan 1',
        status: 'Ongoing',
        approval: 'Verified',
        planDates: ['Monday', 'Wednesday', 'Friday'],
        loggedDates: [],
        warmUp: [
            { id: 'wu1', name: 'Jumping Jacks', time: '1 min', isDone: false },
            { id: 'wu2', name: 'Arm Circles', time: '1 min', isDone: false },
        ],
        mainExercise: [
            { id: 'me1', name: 'Push Ups', sets: 3, reps: 10, isDone: false },
            { id: 'me2', name: 'Squats', sets: 3, reps: 10, isDone: false },
        ],
        coolDown: [
            { id: 'cd1', name: 'Stretching', time: '1 min', isDone: false },
        ],
    },
    {
        id: '2',
        startDate: '2025-05-13',
        endDate: '2025-05-20',
        title: 'Workout Plan 3',
        status: 'Done',
        approval: 'Verified',
        planDates: ['Tuesday', 'Thursday', 'Monday', 'Tuesday'],
        loggedDates: ['2025-05-13', '2025-05-15', '2025-05-19', '2025-05-20'], // remove logged date kapag i-test sa ongoing 
        warmUp: [
            { id: 'wu4', name: 'Neck Rolls', time: '1 min', isDone: true }, // change to false kapag gusto i-test sa ongoing
        ],
        mainExercise: [
            { id: 'me4', name: 'Lunges', sets: 3, reps: 12, isDone: true },
        ],
        coolDown: [
            { id: 'cd4', name: 'Deep Breathing', time: '2 min', isDone: true },
        ],
    },
];
