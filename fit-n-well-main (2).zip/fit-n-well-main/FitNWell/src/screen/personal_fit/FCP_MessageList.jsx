import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { colors } from '../../util/colors'; // Adjust path as needed

// --- Mock Data for Conversations ---
// This array simulates data that would typically come from an API or database.
const conversations = [
  {
    id: '1',
    name: 'Coach Anne',
    lastMessage: 'Hi! Got it! I\'ll adjust your next workout to be lighter...',
    time: 'Just now', // Not in image, but common in chat lists
    unread: true, // Not in image, but common
  },
  {
    id: '2',
    name: 'Support Team',
    lastMessage: 'Your query has been resolved.',
    time: 'Yesterday',
    unread: false,
  },
];

// --- MessageList Component Definition ---
// This is a functional component that represents the entire chat list screen.
const FCP_MessageList = () => { // <--- Renamed from ChatListScreen for clarity
  // Hook to access navigation functionalities provided by @react-navigation/native
  const navigation = useNavigation();

  // --- renderConversationItem Function ---
  // This function is responsible for rendering each individual item in the FlatList.
  // It receives an 'item' object (from the 'conversations' array) as a prop.
  const renderConversationItem = ({ item }) => (
    // TouchableOpacity makes the entire card tappable.
    // When pressed, it navigates to 'ChatScreen' passing conversation details as params.
    <TouchableOpacity
      style={styles.conversationCard}
      onPress={() => navigation.navigate('FCP_ChatScreen', { conversationId: item.id, participantName: item.name })}
    >
      {/* Placeholder for the avatar/profile picture */}
      <View style={styles.avatarPlaceholder} />
      
      {/* Container for conversation name and last message */}
      <View style={styles.conversationContent}>
        <Text style={styles.conversationName}>{item.name}</Text>
        {/* numberOfLines={1} and ellipsizeMode='tail' ensure long messages truncate with "..." */}
        <Text style={styles.conversationLastMessage} numberOfLines={1}>
          {item.lastMessage}
        </Text>
      </View>
      
      {/* Optional Section: Time and Unread Indicator (currently commented out) */}
      {/* <View style={styles.conversationMeta}>
          <Text style={styles.conversationTime}>{item.time}</Text>
          {item.unread && <View style={styles.unreadIndicator} />}
        </View> 
      */}
    </TouchableOpacity>
  );

  // --- Component JSX Structure ---
  return (
    // SafeAreaView ensures content is not obscured by notches or status bars on modern devices.
    <SafeAreaView style={styles.container}>
      {/* --- Header Section --- */}
       {/* Header */}
      <View style={styles.headerRow}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
          <Text style={styles.backText}>Chat</Text>
        </TouchableOpacity>
      </View>
      {/* --- "Messages" Heading --- */}
      {/* This is the main title for the screen, prominent and styled */}
      <Text style={styles.messagesHeading}>Messages</Text>

      {/* --- List of Conversations (FlatList) --- */}
      {/* FlatList is optimized for rendering long lists of data efficiently */}
      <FlatList
        data={conversations} // The array of data to display
        keyExtractor={(item) => item.id} // Unique key for each item, crucial for performance
        renderItem={renderConversationItem} // The function to render each item
        contentContainerStyle={styles.listContentContainer} // Styles applied to the content wrapper
      />
    </SafeAreaView>
  );
};

// --- Export the Component ---
export default FCP_MessageList;

// --- StyleSheet Definition ---
// StyleSheet.create is used for optimizing and organizing styles in React Native.
const styles = StyleSheet.create({
  container: {
    flex: 1, // Ensures the container takes up all available space
    backgroundColor: '#fff', // White background
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 30,
  },
  backText: {
    fontSize: 19,
    marginLeft: 8,
    color: colors.secondary,
    fontFamily: 'InterBold',
    letterSpacing: -0.5,
  },
  messagesHeading: {
    fontSize: 28,
    fontFamily: 'InterBold', // Custom font (requires loading)
    letterSpacing: -1, // Adjusts spacing between characters
    color: colors.secondary, // Greenish color
    marginLeft: 20,
    marginTop: 10,
    marginBottom: 15,
  },
  listContentContainer: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  conversationCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.inp, // Light grey background for each card
    borderRadius: 15, // Rounded corners for the card
    padding: 15,
    marginBottom: 15, // Space between cards
    shadowColor: '#000', // Subtle shadow for a lifted effect
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3, // Android specific shadow
  },
  avatarPlaceholder: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: colors.l_gray, // Light grey for avatar placeholder
    marginRight: 15,
  },
  conversationContent: {
    flex: 1, // Allows this content to take up remaining space
  },
  conversationName: {
    fontSize: 18,
    fontFamily: 'InterBold',
    color: colors.d_gray,
    marginBottom: 5,
  },
  conversationLastMessage: {
    fontSize: 16,
    fontFamily: 'InterRegular',
    color: colors.d_gray,
  },
  // --- Optional Styles for Meta Data (if uncommented in JSX) ---
  // conversationMeta: {
  //   alignItems: 'flex-end',
  //   marginLeft: 10,
  // },
  // conversationTime: {
  //   fontSize: 12,
  //   color: colors.l_gray,
  //   marginBottom: 5,
  // },
  // unreadIndicator: {
  //   width: 10,
  //   height: 10,
  //   borderRadius: 5,
  //   backgroundColor: colors.unreadBadge, // Assuming you have an unread badge color
  // },
});