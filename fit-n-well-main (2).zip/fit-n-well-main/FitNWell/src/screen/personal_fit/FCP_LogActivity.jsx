import React, { useState, useEffect } from 'react';
import {
    StyleSheet,
    Text,
    TextInput,
    View,
    TouchableOpacity,
    KeyboardAvoidingView,
    TouchableWithoutFeedback,
    Keyboard,
    Platform,
    Alert,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import Feather from '@expo/vector-icons/Feather';
import { colors } from '../../util/colors';

const FCP_LogActivity = () => {
    const navigation = useNavigation();
    const route = useRoute();
    const { 
        selectedDate, 
        planTitle, 
        activityData, 
        dailyWorkouts, 
        onLog 
    } = route.params || {};

    const [description, setDescription] = useState('');
    const [displayDate, setDisplayDate] = useState('');

    useEffect(() => {
        if (selectedDate) {
            const dateObj = new Date(selectedDate);
            const formatted = dateObj.toLocaleDateString('en-US', {
                month: 'short',
                day: '2-digit',
                year: 'numeric',
            });
            setDisplayDate(formatted);
        }
    }, [selectedDate]);

    const calculateTotalSessions = (startDate, endDate, planDays) => {
        if (!startDate || !endDate || planDays.length === 0) return 0;

        const start = new Date(startDate);
        const end = new Date(endDate);
        const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

        let count = 0;
        let current = new Date(start);

        while (current <= end) {
            const currentDay = daysOfWeek[current.getDay()];
            if (planDays.includes(currentDay)) count++;
            current.setDate(current.getDate() + 1);
        }

        return count;
    };

    const handleSubmit = () => {
        const alreadyLogged = activityData.loggedDates?.includes(selectedDate);

        if (alreadyLogged) {
            Alert.alert('Already Logged', 'You have already logged this day.');
            return;
        }

        // Add new date only if not present
        const updatedLoggedDates = [...new Set([...(activityData.loggedDates || []), selectedDate])];

        // Create or update the notes for the specific date with the description
        const notesByDate = {
            ...(activityData.notesByDate || {}),
            [selectedDate]: description,
        };

        const updatedActivity = {
            ...activityData,
            loggedDates: updatedLoggedDates,
            notesByDate: notesByDate,
        };

        // Calculate total sessions and check if the plan is fully done
        const totalSessions = calculateTotalSessions(
            activityData.startDate,
            activityData.endDate,
            activityData.planDates
        );
        const isFullyDone = updatedLoggedDates.length >= totalSessions;
        updatedActivity.status = isFullyDone ? 'Done' : 'Ongoing';

        // IMPORTANT: Call the onLog callback with the current exercise state
        // This preserves which exercises were marked as done when logging
        if (onLog && dailyWorkouts) {
            onLog(updatedActivity, dailyWorkouts);
        }

        // Use navigation.reset to go back to the workout plan with preserved data
        navigation.reset({
            index: 1,
            routes: [
                { name: 'MainApp' },
                {
                    name: 'FCP_WorkoutPlan',
                    params: { 
                        updatedActivity, 
                        initialTab: 'Completed',
                        // Pass the dailyWorkouts to preserve exercise completion state
                        preservedDailyWorkouts: dailyWorkouts 
                    },
                },
            ],
        });
    };

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : undefined}
            style={styles.container}
        >
            <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
                <View style={styles.inner}>
                    {/* Header */}
                    <View style={styles.headerRow}>
                        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
                            <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
                            <Text style={styles.backText}>Log Activity</Text>
                        </TouchableOpacity>
                    </View>

                    {/* Plan Title */}
                    <Text style={styles.sectionTitle}>{planTitle || 'Workout Plan'}</Text>
                    <View style={styles.divider} />

                    {/* Date Display */}
                    <Text style={styles.dateLabel}>
                        <Text style={{ color: colors.main }}>● </Text>
                        {displayDate}
                    </Text>

                    {/* Description Input */}
                    <View style={styles.content}>
                        <TextInput
                            style={[styles.input, styles.textarea]}
                            placeholder="Share more about your activity (optional)"
                            multiline
                            value={description}
                            onChangeText={setDescription}
                        />

                        {/* Photo Upload Placeholder */}
                        <TouchableOpacity style={styles.photoBox}>
                            <Feather name="camera" size={28} color={colors.main} />
                            <Text style={styles.tlphoto}>Take Live Photo</Text>
                        </TouchableOpacity>

                        {/* Submit */}
                        <TouchableOpacity style={styles.submit} onPress={handleSubmit}>
                            <Text style={styles.submit_text}>Log Activity</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </TouchableWithoutFeedback>
        </KeyboardAvoidingView>
    );
};

export default FCP_LogActivity;

const styles = StyleSheet.create({
    container: { 
        flex: 1, 
        backgroundColor: '#fff' 
    },
    headerRow: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 20,
        minHeight: 110,
        backgroundColor: '#fff',
        elevation: 5,
        shadowColor: colors.l_gray,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 3,
        zIndex: 100,
    },
    backButton: { 
        flexDirection: 'row', 
        alignItems: 'center', 
        marginTop: 30 
    },
    backText: { 
        fontSize: 19, 
        marginLeft: 8, 
        color: colors.secondary, 
        fontFamily: 'InterBold', 
        letterSpacing: -0.5 
    },
    content: { 
        flex: 1, 
        padding: 20 
    },
    input: {
        backgroundColor: colors.inp,
        padding: 20,
        borderRadius: 10,
        fontFamily: 'InterRegular',
        fontSize: 13,
        letterSpacing: -.4,
        marginBottom: 15,
    },
    textarea: {
        height: 300, // Back to original size
        textAlignVertical: 'top',
    },
    photoBox: {
        borderWidth: 1,
        borderColor: colors.l_gray,
        borderStyle: 'dashed',
        borderRadius: 8,
        height: 130,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 15,
    },
    tlphoto: { 
        fontFamily: 'InterRegular', 
        fontSize: 13, 
        letterSpacing: -.4, 
        color: colors.l_gray,
    },
    submit: {
        backgroundColor: '#fff',
        padding: 9,
        borderRadius: 30,
        width: '53%',
        height: 42,
        alignSelf: 'center',
        shadowColor: colors.l_gray,
        shadowOpacity: 0.1,
        shadowOffset: { width: 0, height: 2 },
        elevation: 5,
        marginBottom: 30,
    },
    submit_text: { 
        alignSelf: 'center', 
        fontSize: 16, 
        fontFamily: 'InterBold', 
        color: colors.d_gray, 
        letterSpacing: -.4 
    },
    dateLabel: {
        fontFamily: 'InterBold',
        letterSpacing: -.5,
        fontSize: 16,
        color: colors.l_gray,
        marginLeft: 22,
    },
    sectionTitle: {
        fontSize: 25,
        fontFamily: 'InterBold',
        letterSpacing: -.5,
        color: colors.d_gray,
        borderRadius: 500,
        marginLeft: 22,
        marginTop: 10,
    },
    divider: {
        height: 1,
        backgroundColor: colors.inp,
        marginVertical: 8,
        marginHorizontal: 20,
    },
    inner: {
        flex: 1,
    },
});