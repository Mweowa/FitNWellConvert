import React, { useState, useMemo, useCallback } from 'react';
import {
    View,
    Text,
    FlatList,
    StyleSheet,
    SafeAreaView,
    TouchableOpacity,
    KeyboardAvoidingView,
    Platform,
    BackHandler, // <-- ADD BackHandler here
} from 'react-native';
import { colors } from '../../util/colors';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { useNavigation, useRoute, useFocusEffect } from '@react-navigation/native';

import FCP_TabSwitch from '../../../components/FCP_WorkoutPlan/FCP_TabSwitch';
import FCP_ActivityCard from '../../../components/FCP_WorkoutPlan/FCP_ActivityCard';
import FCP_ActivityDetailModal from '../../../components/FCP_WorkoutPlan/FCP_ActivityDetail';
import { INITIAL_ACTIVITIES } from './FCP_ActivityData';

const DAYS_OF_WEEK = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export default function FCP_WorkoutPlan() {
    const navigation = useNavigation();
    const route = useRoute();

    const [selectedActivity, setSelectedActivity] = useState(null);
    const [activeTab, setActiveTab] = useState(route.params?.initialTab || 'Ongoing');
    const [allActivitiesState, setAllActivitiesState] = useState(INITIAL_ACTIVITIES);

    // Sync tab and updated activity when coming back
    useFocusEffect(
        useCallback(() => {
            if (route.params?.updatedActivity) {
                setAllActivitiesState(prev =>
                    prev.map(act =>
                        act.id === route.params.updatedActivity.id
                            ? route.params.updatedActivity
                            : act
                    )
                );
            }
            if (route.params?.initialTab) {
                setActiveTab(route.params.initialTab);
            }
        }, [route.params])
    );

    const calculateTotalSessions = useCallback((startDate, endDate, planDates) => {
        const start = new Date(startDate);
        const end = new Date(endDate);
        let count = 0;
        const currentDay = new Date(start);

        while (currentDay <= end) {
            if (planDates.includes(DAYS_OF_WEEK[currentDay.getDay()])) {
                count++;
            }
            currentDay.setDate(currentDay.getDate() + 1);
        }
        return count;
    }, []);

    const filteredActivities = useMemo(() => {
        if (activeTab === 'Completed') {
            const completedActivities = [];

            allActivitiesState.forEach(activity => {
                activity.loggedDates.forEach(date => {
                    completedActivities.push({
                        ...activity,
                        id: `${activity.id}-${date}`,
                        title: activity.title,
                        status: 'Done',
                        completedDate: date,
                        isCompletedDay: true,
                    });
                });
            });

            const otherDoneOrMissed = allActivitiesState.filter(
                a => (a.status === 'Done' || a.status === 'Missed') && a.loggedDates.length === 0
            );

            // Combine and sort the activities by completion date in descending order
            return [...completedActivities, ...otherDoneOrMissed].sort((a, b) => {
                const dateA = a.completedDate ? new Date(a.completedDate) : new Date(0); // Use epoch for activities without a specific logged date
                const dateB = b.completedDate ? new Date(b.completedDate) : new Date(0);
                return dateB - dateA;
            });
        }

        if (activeTab === 'Ongoing') {
            return allActivitiesState.filter(activity => {
                const totalPlanned = calculateTotalSessions(
                    activity.startDate,
                    activity.endDate,
                    activity.planDates
                );

                return (
                    activity.status === 'Ongoing' &&
                    activity.loggedDates.length < totalPlanned
                );
            });
        }

        return [];
    }, [activeTab, allActivitiesState, calculateTotalSessions]);

    const isEmpty = filteredActivities.length === 0;

    // Updated navigation function to handle preserved daily workouts
    const navigateToWorkoutDetail = useCallback((activity) => {
        navigation.navigate('FCP_WorkoutPlanDetail', {
            activity,
            // Pass along preserved daily workouts if they exist from navigation.reset
            preservedDailyWorkouts: route.params?.preservedDailyWorkouts || null
        });
    }, [navigation, route.params?.preservedDailyWorkouts]);

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : undefined}
            style={styles.container}
        >
            <SafeAreaView style={{ flex: 1 }}>
                {/* Header */}
                <View style={styles.headerRow}>
                    <TouchableOpacity
                        style={styles.backButton}
                        onPress={() => {
                            navigation.reset({
                                index: 0,
                                routes: [
                                    {
                                        name: 'MainApp', // Drawer
                                        state: {
                                            index: 0,
                                            routes: [
                                                {
                                                    name: 'MainTabs', // Tabs
                                                    state: {
                                                        index: 0, // Tab index containing FeatStackNavigator
                                                        routes: [
                                                            {
                                                                name: 'Home', // Stack
                                                                state: {
                                                                    index: 0,
                                                                    routes: [{ name: 'FitnessCoach' }], // Target screen
                                                                },
                                                            },
                                                        ],
                                                    },
                                                },
                                            ],
                                        },
                                    },
                                ],
                            });
                        }}
                    >
                        <FontAwesome6
                            name="circle-chevron-left"
                            size={26}
                            color={colors.l_gray}
                        />
                        <Text style={styles.backText}>Workout Plan</Text>
                    </TouchableOpacity>

                    <View style={styles.headerRightIconPlaceholder} />
                </View>

                {/* Tabs */}
                <FCP_TabSwitch activeTab={activeTab} setActiveTab={setActiveTab} />

                {/* Empty State */}
                {isEmpty ? (
                    <View style={styles.emptyContainer}>
                        <Text style={styles.emptyTitle}>No Active Plan</Text>
                        <View style={styles.descRow}>
                            <View style={styles.greenBar} />
                            <Text style={styles.emptyDesc}>
                                You don't have a current exercise plan.{'\n'}
                                Request a new plan to get started!
                            </Text>
                        </View>
                    </View>
                ) : (
                    <FlatList
                        data={filteredActivities}
                        keyExtractor={item => item.id}
                        renderItem={({ item }) => (
                            <FCP_ActivityCard
                                {...item}
                                isCompletedDay={!!item.completedDate}
                                onPress={() => {
                                    if (item.status === 'Ongoing') {
                                        // Use the updated navigation function
                                        navigateToWorkoutDetail(item);
                                    } else {
                                        setSelectedActivity(item);
                                    }
                                }}
                            />
                        )}
                        contentContainerStyle={{ padding: 15 }}
                    />
                )}

                {/* Activity Detail Modal */}
                <FCP_ActivityDetailModal
                    visible={!!selectedActivity}
                    activity={selectedActivity}
                    onClose={() => setSelectedActivity(null)}
                />
            </SafeAreaView>
        </KeyboardAvoidingView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff'
    },
    headerRow: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 20,
        minHeight: 110,
        backgroundColor: '#fff',
        elevation: 5,
        shadowColor: colors.l_gray,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 3,
    },
    backButton: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 30,
    },
    backText: {
        fontSize: 19,
        marginLeft: 8,
        color: colors.secondary,
        fontFamily: 'InterBold',
        letterSpacing: -0.5,
    },
    emptyContainer: {
        flex: 1,
        alignItems: 'flex-start',
        paddingTop: 50,
        paddingHorizontal: 30,
    },
    emptyTitle: {
        fontSize: 35,
        fontFamily: 'InterBold',
        color: colors.d_gray,
        letterSpacing: -.5,
        marginBottom: 10,
    },
    descRow: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        maxWidth: '90%'
    },
    greenBar: {
        width: 4,
        height: '90%',
        backgroundColor: colors.secondary,
        marginRight: 10,
        borderRadius: 2,
        marginTop: 2,
    },
    emptyDesc: {
        fontSize: 15,
        color: colors.l_gray,
        letterSpacing: -.5,
        fontFamily: 'InterRegular',
    },
});