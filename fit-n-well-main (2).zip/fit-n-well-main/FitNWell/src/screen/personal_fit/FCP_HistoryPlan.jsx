import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  SafeAreaView
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../util/colors';
import FCP_ActivityHistoryCard from '../../../components/FCP_ActivityHistory/FCP_ActivityHistoryCard';
import FCP_ActivityHistoryDetailModal from '../../../components/FCP_ActivityHistory/FCP_ActivityHistoryDetailModel';

// ✅ Import workout plans
import { INITIAL_ACTIVITIES } from './FCP_ActivityData';

const FCP_HistoryPlan = () => {
  const navigation = useNavigation();
  const [selectedActivity, setSelectedActivity] = useState(null);
  const [activities, setActivities] = useState([]);

  // Format date into "Month Day, Year"
  const formatDate = (dateStr) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    });
  };

  useEffect(() => {
    // ✅ Show all activities, no filter
    const mappedActivities = INITIAL_ACTIVITIES.map(plan => ({
      id: plan.id.toString(),
      date: `${formatDate(plan.startDate)} - ${formatDate(plan.endDate)}`,
      title: plan.title,
      ...plan
    }));

    setActivities(mappedActivities);
  }, []);

  const handleChatPress = () => {
    navigation.navigate('FCP_MessageList');
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.headerRow}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
          <Text style={styles.backText}>History Plan</Text>
        </TouchableOpacity>
      </View>

      {/* Activity list */}
      <FlatList
        data={activities}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <FCP_ActivityHistoryCard
            {...item}
            onPress={() => setSelectedActivity(item)}
          />
        )}
        contentContainerStyle={styles.flatListContent}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <Text style={{ textAlign: 'center', marginTop: 20, color: colors.d_gray }}>
            No activities found.
          </Text>
        }
      />

      {/* Modal */}
      <FCP_ActivityHistoryDetailModal
        visible={!!selectedActivity}
        activity={selectedActivity}
        onClose={() => setSelectedActivity(null)}
      />

      {/* Floating Chat Button */}
      <TouchableOpacity style={styles.fab} onPress={handleChatPress}>
        <Ionicons name="chatbubble" size={50} color={colors.secondary} />
      </TouchableOpacity>
    </SafeAreaView>
  );
};

export default FCP_HistoryPlan;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 30,
  },
  backText: {
    fontSize: 19,
    marginLeft: 8,
    color: colors.secondary,
    fontFamily: 'InterBold',
    letterSpacing: -0.5,
  },
  flatListContent: {
    padding: 15,
    paddingBottom: 100,
  },
  fab: {
    position: 'absolute',
    bottom: 50,
    right: 25,
    width: 75,
    height: 70,
    borderRadius: 35,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: colors.d_gray,
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    borderWidth: 2,
    borderColor: colors.inp,
    zIndex: 1,
  },
});
