// FCP_ChatScreen.jsx

import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../util/colors';

// This is your mock data, now with more distinct conversations
const mockChatData = {
  '1': [
    { id: '1', sender: 'user', text: "Hi Coach! I felt a bit tired from yesterday's routine. Can we make it a bit lighter? Thanks!" },
    { id: '2', sender: 'coach', text: "Hi! Got it! I'll adjust your next workout to be lighter. Let me know if there's anything else you need." },
  ],
  '2': [
    { id: '1', sender: 'user', text: "Hello, I need some help with my account." },
    { id: '2', sender: 'support', text: "Hello! A member of our support team will be with you shortly. Thank you for your patience." },
  ],
};

const FCP_ChatScreen = () => {
  const navigation = useNavigation();
  const route = useRoute();
  // Destructure conversationId and participantName from the route params
  const { conversationId, participantName } = route.params || {};

  const [message, setMessage] = useState('');
  // Initialize messages as an empty array
  const [messages, setMessages] = useState([]);

  const scrollViewRef = useRef();

  // useEffect to load messages when the conversationId changes
  useEffect(() => {
    // Check if conversationId exists and load the corresponding data
    if (conversationId && mockChatData[conversationId]) {
      setMessages(mockChatData[conversationId]);
    } else {
      // Handle case where conversationId is not found (e.g., set to empty array)
      setMessages([]);
    }
  }, [conversationId]); // This effect re-runs whenever conversationId changes

  useEffect(() => {
    scrollViewRef.current?.scrollToEnd({ animated: true });
  }, [messages]);

  const handleSendMessage = useCallback(() => {
    const trimmed = message.trim();
    if (!trimmed) return;
    setMessages(prev => [
      ...prev,
      { id: String(prev.length + 1), sender: 'user', text: trimmed },
    ]);
    setMessage('');
  }, [message]);

  const renderMessageBubble = useCallback(({ id, sender, text }) => {
    const isUser = sender === 'user';
    return (
      <View
        key={id}
        style={[
          styles.messageBubble,
          isUser ? styles.userMessageBubble : styles.coachMessageBubble,
        ]}
      >
        <Text
          style={[
            styles.messageText,
            isUser ? styles.userMessageText : styles.coachMessageText,
          ]}
        >
          {text}
        </Text>
      </View>
    );
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.headerRow}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
          {/* Display the participantName from route.params */}
          <Text style={styles.backText}>{participantName || 'Chat'}</Text>
        </TouchableOpacity>
      </View>

      {/* Messages */}
      <KeyboardAvoidingView
        style={styles.keyboardAvoidingView}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
      >
        <ScrollView
          style={styles.messagesContainer}
          contentContainerStyle={styles.messagesContentContainer}
          ref={scrollViewRef}
          onContentSizeChange={() => {
            scrollViewRef.current?.scrollToEnd({ animated: true });
          }}
        >
          {messages.map(renderMessageBubble)}
        </ScrollView>

        {/* Message Input */}
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.messageInput}
            placeholder="Message"
            placeholderTextColor={colors.d_gray}
            value={message}
            onChangeText={setMessage}
            multiline
          />
          <TouchableOpacity style={styles.sendButton} onPress={handleSendMessage}>
            <Ionicons name="send" size={24} color={colors.secondary} />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

export default FCP_ChatScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 30,
  },
  backText: {
    fontSize: 19,
    marginLeft: 8,
    color: colors.secondary,
    fontFamily: 'InterBold',
    letterSpacing: -0.5,
  },
  keyboardAvoidingView: {
    flex: 1,
  },
  messagesContainer: {
    flex: 1,
    paddingHorizontal: 15,
    paddingTop: 10,
  },
  messagesContentContainer: {
    paddingBottom: 20,
  },
  messageBubble: {
    maxWidth: '80%',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 15,
    marginBottom: 10,
  },
  userMessageBubble: {
    alignSelf: 'flex-end',
    backgroundColor: colors.secondary,
    borderBottomRightRadius: 2,
  },
  coachMessageBubble: {
    alignSelf: 'flex-start',
    backgroundColor: colors.inp,
    borderBottomLeftRadius: 2,
  },
  messageText: {
    fontSize: 16,
    fontFamily: 'InterRegular',
  },
  userMessageText: {
    color: colors.white,
  },
  coachMessageText: {
    color: colors.d_gray,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 10,
    backgroundColor: colors.white,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.l_gray,
  },
  messageInput: {
    flex: 1,
    minHeight: 40,
    maxHeight: 120,
    backgroundColor: colors.inp,
    borderRadius: 25,
    paddingHorizontal: 15,
    paddingVertical: Platform.OS === 'ios' ? 10 : 8,
    fontSize: 16,
    fontFamily: 'InterRegular',
    color: colors.d_gray,
    marginRight: 10,
  },
  sendButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

