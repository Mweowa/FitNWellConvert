// FCP_RequestPlan.jsx

import React, { useState } from 'react';
import { View, Text, Modal, StyleSheet, TouchableOpacity, Dimensions, Button, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import { colors } from '../../util/colors';
import AntDesign from '@expo/vector-icons/AntDesign';
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

// --------------------------------------------------
// sa coach page babaguhin kapag gusto makita yung ongoing modal
// --------------------------------------------------
const RequestPlanScreen = () => {
  const navigation = useNavigation();
  const [modalVisible, setModalVisible] = useState(false);
  const [requestModalVisible, setRequestModalVisible] = useState(false);

  // This state determines if the "Ongoing Plan!" modal should show
  const [hasOngoingPlan, setHasOngoingPlan] = useState(true);

  const handleRequestPlan = () => {
    if (hasOngoingPlan) {
      setModalVisible(true);
    } else {
      Alert.alert(
        "Confirm Request",
        "Are you sure you want to request a new plan?",
        [
          { text: "No", style: "cancel" },
          { text: "Yes", onPress: () => setRequestModalVisible(true) }
        ]
      );
    }
  };

  return (
    <View style={screenStyles.container}>
      <Text style={screenStyles.title}>Request Plan</Text>
      <Button title="Tap to Request" onPress={handleRequestPlan} />

      {/* Render the modals here. They are controlled by the screen's state. */}
      <OngoingPlanModal isVisible={modalVisible} onClose={() => setModalVisible(false)} />
      <RequestSubmittedModal isVisible={requestModalVisible} onClose={() => setRequestModalVisible(false)} />
    </View>
  );
};

const screenStyles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
});

export default RequestPlanScreen;

// --------------------------------------------------
// The original modal components
// --------------------------------------------------
const OngoingPlanModal = ({ isVisible, onClose }) => {
  return (
    <Modal animationType="fade" transparent visible={isVisible} onRequestClose={onClose}>
      <View style={modalStyles.blurContainer}>
        <BlurView intensity={100} tint="light" style={StyleSheet.absoluteFill} />
      </View>
      <View style={modalStyles.centeredView}>
        <View style={modalStyles.modalContainer}>
          <TouchableOpacity style={modalStyles.closeButton} onPress={onClose}>
            <AntDesign name="closecircle" size={26} color={colors.l_gray} />
          </TouchableOpacity>
          <AntDesign name="warning" size={90} color={colors.secondary} style={modalStyles.icon} />
          <Text style={modalStyles.title}>Ongoing{"\n"}Plan!</Text>
          <Text style={modalStyles.message}>A new request cannot be{"\n"}processed while a plan{"\n"}is still active.</Text>
        </View>
      </View>
    </Modal>
  );
};

const RequestSubmittedModal = ({ isVisible, onClose }) => {
  return (
    <Modal animationType="fade" transparent visible={isVisible} onRequestClose={onClose}>
      <View style={modalStyles.blurContainer}>
        <BlurView intensity={100} tint="light" style={StyleSheet.absoluteFill} />
      </View>
      <View style={modalStyles.centeredView}>
        <View style={modalStyles.modalContainer}>
          <TouchableOpacity style={modalStyles.closeButton} onPress={onClose}>
            <AntDesign name="closecircle" size={26} color={colors.l_gray} />
          </TouchableOpacity>
          <Ionicons name="checkmark-circle-outline" size={90} color={colors.secondary} style={modalStyles.icon} />
          <Text style={modalStyles.title}>Request{"\n"}Submitted!</Text>
          <Text style={modalStyles.message}>Please proceed to the CHK{"\n"}Fitness Management Center{"\n"}for the assessment.</Text>
        </View>
      </View>
    </Modal>
  );
};

const modalStyles = StyleSheet.create({
  //... your existing modal styles
  blurContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  centeredView: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  modalContainer: {
    width: width * 0.90,
    height: height * 0.50,
    backgroundColor: colors.inp,
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
    paddingVertical: 40,
    paddingHorizontal: 25,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 8,
    elevation: 5,
  },
  closeButton: {
    position: 'absolute',
    top: 15,
    right: 15,
    zIndex: 10,
    backgroundColor: 'transparent',
    padding: 0,
    borderRadius: 0,
  },
  icon: {
    marginBottom: 5,
    marginTop: 20
  },
  title: {
    fontSize: 25,
    fontFamily: 'InterBold',
    letterSpacing: -1,
    color: colors.d_gray,
    textAlign: 'center',
    marginBottom: 10,
    marginTop: 5,
  },
  message: {
    fontSize: 16,
    fontFamily: 'InterRegular',
    letterSpacing: -.3,
    color: colors.d_gray,
    textAlign: 'center',
  },
});

export { OngoingPlanModal, RequestSubmittedModal };