// FitnessCoachPage.jsx
import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Image,
  TouchableOpacity,
  Dimensions,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { colors } from '../../util/colors'; // Make sure this path is correct

// Import both modal components from the FCP_RequestPlan file
import { OngoingPlanModal, RequestSubmittedModal } from './FCP_RequestPlan';

import { useFocusEffect } from '@react-navigation/native';
import { BackHandler } from 'react-native';

const { width } = Dimensions.get('window');

const FitnessCoachPage = () => {
  const navigation = useNavigation();
  const [modalVisible, setModalVisible] = useState(false);
  const [requestModalVisible, setRequestModalVisible] = useState(false);

  const [hasOngoingPlan, setHasOngoingPlan] = useState(false); // ito yung i-cchange kapag ittest yung modal - true - ongoing modal // false - request modal

  const handleRequestPlan = () => {
    if (hasOngoingPlan) {
      // If there's an ongoing plan, show the specific "Ongoing Plan!" modal
      setModalVisible(true);
    } else {
      // If no ongoing plan, show confirmation alert
      Alert.alert(
        "Confirm Request",
        "Are you sure you want to request a plan?",
        [
          {
            text: "No",
            onPress: () => console.log("Request cancelled"),
            style: "cancel"
          },
          {
            text: "Yes",
            onPress: () => {
              // Show the RequestSubmittedModal after confirmation
              setRequestModalVisible(true);
            }
          }
        ]
      );
    }
  };

   useFocusEffect(
        useCallback(() => {
          const backAction = () => {
            navigation.reset({
              index: 0,
              routes: [{ name: 'MainApp' }], // Go back to Home
            });
            return true;
          };
      
          // ✅ Create subscription
          const subscription = BackHandler.addEventListener('hardwareBackPress', backAction);
      
          // ✅ Correct cleanup
          return () => subscription.remove();
        }, [navigation])
      );

  return (
    <View style={styles.container}>
      {/* Backdrop image */}
      <Image
        source={require("../../assets/photos/backdrop.png")}
        style={styles.backgroundImage}
        resizeMode="cover"
      />
      <SafeAreaView style={{ flex: 1 }}>
        <View style={styles.contentWrapper}>
          <Ionicons name="barbell-outline" style={styles.coachIcon} />

          <Text style={styles.heading}>
            <Text style={styles.headingBold}>Personalized{"\n"}</Text>
            <Text style={styles.headingHighlight}>Fitness Coach</Text>
          </Text>

          <View style={styles.paragraphRow}>
            <View style={styles.verticalLine} />
            <Text style={styles.subheading}>
              Tailored plans, progress tracking,{"\n"}and motivation for your goals.
            </Text>
          </View>

          <View style={styles.i_divider} />

          <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('FCP_WorkoutPlan')}
          >
            <Text style={styles.buttonText}>Workout Plan</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={handleRequestPlan} // Call the function that handles the request logic
          >
            <Text style={styles.buttonText}>Request Plan</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('FCP_HistoryPlan')}
          >
            <Text style={styles.buttonText}>History Plan</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>

      {/* Render the "Ongoing Plan!" modal component. It's visible when modalVisible is true. */}
      <OngoingPlanModal
        isVisible={modalVisible}
        onClose={() => setModalVisible(false)}
      />

      {/* Render the "Request Submitted" modal component. It's visible when requestModalVisible is true. */}
      <RequestSubmittedModal
        isVisible={requestModalVisible}
        onClose={() => setRequestModalVisible(false)}
      />
    </View>
  );
};

export default FitnessCoachPage;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  backgroundImage: {
    position: 'absolute',
    width: 550,
    height: 750,
    top: '18%',
    alignSelf: 'center',
    zIndex: 0,
    opacity: 0.6,
  },
  contentWrapper: {
    flex: 1,
    paddingHorizontal: 20,
    justifyContent: 'center',
  },
  coachIcon: {
    fontSize: 50,
    color: colors.d_gray,
    marginBottom: 5,
    marginTop: 40,
    alignSelf: 'flex-start',
  },
  heading: {
    fontSize: 40,
    fontFamily: 'InterBold',
    marginBottom: 10,
    letterSpacing: -1,
    color: colors.d_gray,
  },
  headingBold: {
    color: colors.d_gray,
  },
  headingHighlight: {
    color: colors.secondary,
  },
  paragraphRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 50,
  },
  verticalLine: {
    width: 4,
    backgroundColor: colors.secondary,
    borderRadius: 3,
    marginRight: 10,
    alignSelf: 'stretch',
  },
  subheading: {
    fontFamily: 'InterRegular',
    fontSize: 15,
    color: colors.d_gray,
    lineHeight: 18,
    letterSpacing: -0.3,
  },
  i_divider: {
    height: 0.5,
    backgroundColor: colors.l_gray,
    marginBottom: 40,
  },
  button: {
    backgroundColor: '#fff',
    padding: 9,
    marginBottom: 16,
    borderRadius: 30,
    width: '100%',
    height: 42,
    alignSelf: 'center',
    justifyContent: 'center',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
  },
  buttonText: {
    alignSelf: 'center',
    fontSize: 16,
    fontFamily: 'InterBold',
    color: colors.d_gray,
    letterSpacing: -0.4,
  },
});