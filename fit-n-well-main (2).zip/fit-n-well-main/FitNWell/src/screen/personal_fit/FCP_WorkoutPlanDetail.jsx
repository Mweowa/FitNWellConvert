import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, FlatList } from 'react-native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { colors } from '../../util/colors';

// This component displays the details of a workout plan, allowing the user to
// track daily progress on a per-day basis.
const FCP_WorkoutPlanDetail = ({ route, navigation }) => {
    // `initialActivity` holds the overall plan data (title, plan dates, etc.)
    const initialActivity = route.params?.activity;
    // Get preserved daily workouts if coming from navigation.reset
    const preservedDailyWorkouts = route.params?.preservedDailyWorkouts;

    // `activity` holds the overall plan data, which can be updated.
    const [activity, setActivity] = useState(null);
    // `dailyWorkouts` stores the exercises and their 'isDone' status for each specific date.
    // This is the core state for per-day tracking.
    const [dailyWorkouts, setDailyWorkouts] = useState({});
    const [selectedDay, setSelectedDay] = useState(0);

    // Helper function to generate the array of days between start and end dates.
    const getDaysArray = useCallback((startDateStr, endDateStr) => {
        if (!startDateStr || !endDateStr) return [];
        const startDate = new Date(startDateStr);
        const endDate = new Date(endDateStr);
        // Calculate the total number of days in the range.
        const totalDays = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1;

        return Array.from({ length: totalDays }, (_, i) => {
            const date = new Date(startDate);
            date.setDate(startDate.getDate() + i);
            return {
                day: date.toLocaleDateString('en-US', { weekday: 'long' }),
                date: date.getDate().toString(),
                fullDate: date.toISOString().split('T')[0],
            };
        });
    }, []);

    // This effect initializes the state when the component first loads.
    useEffect(() => {
        if (initialActivity?.startDate && initialActivity?.endDate && initialActivity?.planDates) {
            setActivity(initialActivity);

            // Check if we have preserved daily workouts from navigation.reset
            if (preservedDailyWorkouts && Object.keys(preservedDailyWorkouts).length > 0) {
                console.log('Using preserved daily workouts:', preservedDailyWorkouts);
                setDailyWorkouts(preservedDailyWorkouts);
            } else {
                // Initialize the `dailyWorkouts` state based on the initial plan.
                const days = getDaysArray(initialActivity.startDate, initialActivity.endDate);
                const initialDailyWorkouts = days.reduce((acc, dayObj) => {
                    // The plan only exists for certain days of the week, as defined in `planDates`.
                    // We only initialize the daily workout data for those days.
                    if (initialActivity.planDates.includes(dayObj.day)) {
                        acc[dayObj.fullDate] = {
                            warmUp: initialActivity.warmUp.map(ex => ({ ...ex, isDone: false })),
                            mainExercise: initialActivity.mainExercise.map(ex => ({ ...ex, isDone: false })),
                            coolDown: initialActivity.coolDown.map(ex => ({ ...ex, isDone: false })),
                        };
                    }
                    return acc;
                }, {});
                setDailyWorkouts(initialDailyWorkouts);
            }

            // Auto-select the most recent logged day when component loads, or first unlogged if none logged
            const days = getDaysArray(initialActivity.startDate, initialActivity.endDate);
            
            if (initialActivity.loggedDates && initialActivity.loggedDates.length > 0) {
                // If there are logged dates, go to the most recent one
                const mostRecentLoggedDate = initialActivity.loggedDates[initialActivity.loggedDates.length - 1];
                const mostRecentLoggedDayIndex = days.findIndex(day => day.fullDate === mostRecentLoggedDate);
                
                if (mostRecentLoggedDayIndex !== -1) {
                    setSelectedDay(mostRecentLoggedDayIndex);
                    console.log('Auto-selected most recent logged day on load:', mostRecentLoggedDate);
                } else {
                    setSelectedDay(0);
                }
            } else {
                // If no dates logged yet, go to first unlogged day
                const firstUnloggedDayIndex = days.findIndex(day => {
                    const isDayPlanned = initialActivity.planDates.includes(day.day);
                    const isDateLogged = initialActivity.loggedDates?.includes(day.fullDate);
                    return isDayPlanned && !isDateLogged;
                });
                
                if (firstUnloggedDayIndex !== -1) {
                    setSelectedDay(firstUnloggedDayIndex);
                    console.log('Auto-selected first unlogged day on load:', days[firstUnloggedDayIndex].fullDate);
                } else {
                    setSelectedDay(0);
                }
            }

        } else {
            // Handle cases where the initial data is missing.
            // TODO: Replace with a custom modal UI instead of Alert.
            console.error("Workout plan data not found or incomplete. Please try again.");
            // navigation.goBack(); // Removing this as it's causing the loop on error
        }
    }, [initialActivity, preservedDailyWorkouts, getDaysArray]);

    // This new useEffect hook is added to handle saving data on component unmount.
    // It's a placeholder function to simulate saving data to a database.
    useEffect(() => {
        // A placeholder function to simulate a database save.
        const saveToDatabase = (currentActivity, currentDailyWorkouts) => {
            // In a real application, you would make an API call here.
            // For example:
            // api.saveWorkoutData(currentActivity.id, currentDailyWorkouts);
            console.log('--- Saving data on component unmount ---');
            console.log('Activity saved:', currentActivity);
            console.log('Daily workouts saved:', currentDailyWorkouts);
            console.log('---------------------------------------');
        };

        // The cleanup function is returned by the effect. It runs when the component unmounts.
        return () => {
            if (activity && Object.keys(dailyWorkouts).length > 0) {
                saveToDatabase(activity, dailyWorkouts);
            }
        };
    }, [activity, dailyWorkouts]); // Depend on `activity` and `dailyWorkouts` to ensure the cleanup function has the latest state.


    // NEW: Function to handle updates from the LogActivity screen.
    const handleLogWorkout = useCallback((updatedActivity, updatedDailyWorkouts) => {
        // Update the local state
        setActivity(updatedActivity);
        setDailyWorkouts(updatedDailyWorkouts);

        console.log('Workout logged and state updated:', updatedActivity.loggedDates);
        
        // Find the most recent logged date and navigate back to it
        const days = getDaysArray(updatedActivity.startDate, updatedActivity.endDate);
        
        if (updatedActivity.loggedDates && updatedActivity.loggedDates.length > 0) {
            // Get the most recent logged date (last item in the array)
            const mostRecentLoggedDate = updatedActivity.loggedDates[updatedActivity.loggedDates.length - 1];
            
            // Find the index of this date in the days array
            const mostRecentLoggedDayIndex = days.findIndex(day => day.fullDate === mostRecentLoggedDate);
            
            if (mostRecentLoggedDayIndex !== -1) {
                setSelectedDay(mostRecentLoggedDayIndex);
                console.log('Auto-navigated back to most recent logged date:', mostRecentLoggedDate);
            }
        }
    }, [getDaysArray]);

    // Memoize the array of days for performance.
    const days = useMemo(() => getDaysArray(activity?.startDate, activity?.endDate), [activity, getDaysArray]);

    // Memoize the currently selected day's data.
    const currentDay = useMemo(() => days[selectedDay] || { fullDate: '', day: '', date: '' }, [days, selectedDay]);

    // Memoize the exercises for the current day from our new `dailyWorkouts` state.
    const currentDayExercises = useMemo(() => dailyWorkouts[currentDay.fullDate] || { warmUp: [], mainExercise: [], coolDown: [] }, [dailyWorkouts, currentDay]);

    const hasPlan = useMemo(() => activity?.planDates?.includes(currentDay.day) || false, [activity, currentDay]);
    const isCurrentDayLogged = useMemo(() => activity?.loggedDates?.includes(currentDay.fullDate) || false, [activity, currentDay]);

    // This function returns the exercises for a given section from the per-day state.
    const getExercises = useCallback((section) => {
        switch (section) {
            case 'Warm Up': return currentDayExercises.warmUp;
            case 'Main Exercise': return currentDayExercises.mainExercise;
            case 'Cool Down': return currentDayExercises.coolDown;
            default: return [];
        }
    }, [currentDayExercises]);

    // The core logic for tracking completion is updated here.
    // This function now updates the `dailyWorkouts` state for the current day only.
    const toggleDone = useCallback((section, index) => {
        if (isCurrentDayLogged) return; // Prevent changes after the workout has been logged.

        const sectionKey = {
            'Warm Up': 'warmUp',
            'Main Exercise': 'mainExercise',
            'Cool Down': 'coolDown',
        }[section];

        setDailyWorkouts(prevDailyWorkouts => {
            const updatedWorkouts = { ...prevDailyWorkouts };
            const currentDayData = { ...updatedWorkouts[currentDay.fullDate] };
            if (!currentDayData) return prevDailyWorkouts;

            currentDayData[sectionKey] = currentDayData[sectionKey].map((ex, i) =>
                i === index ? { ...ex, isDone: !ex.isDone } : ex
            );
            updatedWorkouts[currentDay.fullDate] = currentDayData;
            return updatedWorkouts;
        });
    }, [isCurrentDayLogged, currentDay.fullDate]);

    // New function to mark all exercises in a section as done.
    const markAllDone = useCallback((section) => {
        if (isCurrentDayLogged) return;

        const sectionKey = {
            'Warm Up': 'warmUp',
            'Main Exercise': 'mainExercise',
            'Cool Down': 'coolDown',
        }[section];

        setDailyWorkouts(prevDailyWorkouts => {
            const updatedWorkouts = { ...prevDailyWorkouts };
            const currentDayData = { ...updatedWorkouts[currentDay.fullDate] };
            if (!currentDayData) return prevDailyWorkouts;

            const allItemsDone = currentDayData[sectionKey].every(ex => ex.isDone);
            currentDayData[sectionKey] = currentDayData[sectionKey].map(ex => ({
                ...ex,
                isDone: !allItemsDone
            }));

            updatedWorkouts[currentDay.fullDate] = currentDayData;
            return updatedWorkouts;
        });
    }, [isCurrentDayLogged, currentDay.fullDate]);

    // Helper function to get the appropriate icon and color for exercise status
    const getExerciseIcon = useCallback((item) => {
        if (isCurrentDayLogged) {
            // After logging: show checkmark for completed, X for not completed
            return {
                name: item.isDone ? 'check-circle' : 'xmark-circle',
                color: item.isDone ? colors.verified : colors.error || '#ff4444'
            };
        } else {
            // Before logging: show regular circle for unchecked, checkmark for checked
            return {
                name: item.isDone ? 'check-circle' : 'circle',
                color: item.isDone ? colors.verified : colors.pending
            };
        }
    }, [isCurrentDayLogged]);

    // Helper function to get the appropriate icon for section header
    const getSectionIcon = useCallback((items) => {
        if (items.length === 0) {
            return {
                name: 'circle',
                color: colors.pending
            };
        }

        if (isCurrentDayLogged) {
            // After logging: show checkmark if ANY exercises are done, X only if NONE are done
            const completedItems = items.filter(item => item.isDone);
            const noItemsDone = completedItems.length === 0;
            
            if (noItemsDone) {
                return {
                    name: 'xmark-circle',
                    color: colors.error || '#ff4444'
                };
            } else {
                // If any exercises are done, show checkmark
                return {
                    name: 'check-circle',
                    color: colors.verified
                };
            }
        } else {
            // Before logging: show regular behavior
            const allItemsDone = items.every(item => item.isDone);
            return {
                name: allItemsDone ? 'check-circle' : 'circle',
                color: allItemsDone ? colors.verified : colors.pending
            };
        }
    }, [isCurrentDayLogged]);

    // Helper to format the date string.
    const formatDate = dateStr => dateStr ? new Date(dateStr).toLocaleDateString('en-US', {
        month: 'long', day: '2-digit', year: 'numeric'
    }) : '';

    const renderSection = (title) => {
        const items = getExercises(title);
        const sectionIcon = getSectionIcon(items);

        return (
            <View style={styles.section}>
                <View style={styles.sectionHeader}>
                    <TouchableOpacity onPress={() => markAllDone(title)} disabled={isCurrentDayLogged}>
                        <FontAwesome6
                            name={sectionIcon.name}
                            size={20}
                            color={sectionIcon.color}
                        />
                    </TouchableOpacity>
                    <Text style={styles.sectionHeaderText}>{title}</Text>
                </View>
                {items.map((item, index) => {
                    const exerciseIcon = getExerciseIcon(item);
                    return (
                        <View key={item.id || index}>
                            <TouchableOpacity
                                style={styles.item}
                                onPress={() => toggleDone(title, index)}
                                disabled={isCurrentDayLogged}
                            >
                                <FontAwesome6
                                    name={exerciseIcon.name}
                                    size={18}
                                    color={exerciseIcon.color}
                                    style={styles.checkIcon}
                                />
                                <View style={styles.itemTextBlock}>
                                    <Text style={styles.itemName}>{item.name}</Text>
                                    <View style={styles.metaInfoRow}>
                                        {item.time && <Text style={styles.time}>Time: {item.time}</Text>}
                                        {item.sets && <><View style={styles.verticalDivider} /><Text style={styles.time}>Sets: {item.sets}</Text></>}
                                        {item.reps && <><View style={styles.verticalDivider} /><Text style={styles.time}>Reps: {item.reps}</Text></>}
                                    </View>
                                </View>
                            </TouchableOpacity>
                            <View style={styles.itemDivider} />
                        </View>
                    );
                })}
            </View>
        );
    };

    if (!activity) {
        return (
            <View style={styles.container}>
                <View style={styles.headerRow}>
                    <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
                        <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
                        <Text style={styles.backText}>Loading...</Text>
                    </TouchableOpacity>
                </View>
                <View style={styles.loadingContainer}>
                    <Text style={styles.loadingText}>Loading workout plan details...</Text>
                </View>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <View style={styles.headerRow}>
                <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
                    <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
                    <Text style={styles.backText}>{activity.title}</Text>
                </TouchableOpacity>
            </View>

            <View style={styles.daySelectorWrapper}>
                <FlatList
                    data={days}
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    keyExtractor={item => item.fullDate}
                    contentContainerStyle={styles.daySelector}
                    renderItem={({ item, index }) => {
                        const isDateLogged = activity.loggedDates?.includes(item.fullDate);
                        const isDayPlanned = activity.planDates.includes(item.day);
                        return (
                            <View key={item.fullDate} style={styles.dayItemWrapper}>
                                <TouchableOpacity
                                    style={[
                                        styles.dayItem,
                                        selectedDay === index && styles.activeDayItem,
                                        isDateLogged && styles.loggedDayItem,
                                        !isDayPlanned && styles.unplannedDayItem
                                    ]}
                                    onPress={() => setSelectedDay(index)}
                                    disabled={!isDayPlanned}
                                >
                                    <Text style={[
                                        styles.dayText,
                                        selectedDay === index && styles.activeDayText,
                                        isDateLogged && styles.loggedDayText,
                                    ]}>
                                        {item.day.substring(0, 3)}
                                    </Text>
                                    <Text style={[
                                        styles.dateText,
                                        selectedDay === index && styles.activeDayText,
                                        isDateLogged && styles.loggedDateText,
                                    ]}>
                                        {item.date}
                                    </Text>
                                    {isDayPlanned && (
                                        <View style={[
                                            styles.radioCircle,
                                            selectedDay === index && styles.activeRadioCircle,
                                            isDateLogged && styles.loggedRadioCircle
                                        ]} />
                                    )}
                                </TouchableOpacity>
                                <View style={styles.dayDivider} />
                            </View>
                        );
                    }}
                />
            </View>

            <ScrollView contentContainerStyle={styles.contentContainer}>
                <Text style={styles.dateLabel}>
                    <Text style={{ color: colors.main }}>● </Text>
                    <Text>{formatDate(currentDay.fullDate)}</Text>
                </Text>

                <Text style={styles.sectionTitle}>{activity.title}</Text>
                <View style={styles.divider} />

                {hasPlan ? (
                    <>
                        {renderSection('Warm Up')}
                        <View style={styles.divider} />
                        {renderSection('Main Exercise')}
                        <View style={styles.divider} />
                        {renderSection('Cool Down')}
                        <View style={styles.divider} />
                    </>
                ) : (
                    <Text style={styles.noPlanText}>No plans for this day.</Text>
                )}

                {hasPlan && (
                    <TouchableOpacity
                        style={[styles.nextButton, isCurrentDayLogged && styles.nextButtonDisabled]}
                        disabled={isCurrentDayLogged}
                        // The onLog callback is no longer needed here since the parent component
                        // will now handle persistence when the user navigates away.
                        onPress={() => navigation.navigate('FCP_LogActivity', {
                            selectedDate: currentDay.fullDate,
                            planTitle: activity.title,
                            activityData: activity,
                            dailyWorkouts: dailyWorkouts,
                            onLog: handleLogWorkout,
                        })}
                    >
                        <Text style={styles.nextButtonText}>{isCurrentDayLogged ? 'Logged' : 'Log Workout'}</Text>
                    </TouchableOpacity>
                )}
            </ScrollView>
        </View>
    );
};

export default FCP_WorkoutPlanDetail;

const styles = StyleSheet.create({
    container: { 
        flex: 1, 
        backgroundColor: '#fff' 
    },
    headerRow: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 20,
        minHeight: 110,
        backgroundColor: '#fff',
        elevation: 5,
        shadowColor: colors.l_gray,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 3,
        zIndex: 100,
    },
    backButton: { 
        flexDirection: 'row', 
        alignItems: 'center', 
        marginTop: 30 
    },
    backText: { 
        fontSize: 19, 
        marginLeft: 8, 
        color: colors.secondary, 
        fontFamily: 'InterBold', 
        letterSpacing: -0.5 
    },
    daySelectorWrapper: {
        backgroundColor: colors.main,
        paddingVertical: 15,
    },
    daySelector: {
        paddingHorizontal: 10,
    },
    dayItemWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    dayItem: { 
        alignItems: 'center', 
        paddingHorizontal: 10, 
        paddingVertical: 5,
        borderRadius: 5,
        width: 50,
    },
    activeDayItem: {
        backgroundColor: '#fff',
        borderRadius: 5,
        paddingHorizontal: 10,
        paddingVertical: 5,
        width: 50,
    },
    unplannedDayItem: {
        opacity: 0.5,
    },
    dayText: { 
        color: '#fff', 
        fontFamily: 'InterBold',
        letterSpacing: -.5,
        fontSize: 13,
    },
    dateText: { 
        color: '#fff',
        fontFamily: 'InterRegular',
        letterSpacing: -.5, 
        fontSize: 13,
    },
    activeDayText: { 
        color: colors.main,
    },
    radioCircle: {
        width: 8,
        height: 8,
        borderRadius: 4,
        backgroundColor: '#fff',
        marginTop: 4,
    },
    activeRadioCircle: {
        backgroundColor: colors.main,
    },
    loggedDayItem: {
        backgroundColor: colors.secondary,
        borderRadius: 5,
        paddingHorizontal: 10,
        paddingVertical: 5,
        width: 50,
    },
    loggedDayText: {
        color: colors.inp,
        fontFamily: 'InterBold',
        letterSpacing: -.5,
        fontSize: 13 
    },
    loggedDateText: {
        color: colors.inp,
        fontFamily: 'InterRegular',
        letterSpacing: -.5, 
        fontSize: 13
    },
    loggedRadioCircle: {
        backgroundColor: colors.inp,
    },
    contentContainer: {
        paddingHorizontal: 20,
        paddingTop: 10,
        paddingBottom: 40,
    },
    dateLabel: {
        fontFamily: 'InterBold',
        letterSpacing: -.5,
        fontSize: 16,
        color: colors.l_gray,
        marginBottom: 10,
    },
    sectionTitle: {
        fontSize: 24,
        fontFamily: 'InterBold',
        letterSpacing: -.5,
        color: colors.d_gray,
        backgroundColor: colors.inp,
        padding: 10,
        borderRadius: 100,
        marginBottom: 10,
    },
    section: { 
        marginTop: 10, 
    },
    sectionHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 5,
    },
    sectionHeaderText: {
        fontSize: 18,
        fontFamily: 'InterBold',
        letterSpacing: -.5,
        marginLeft: 10,
        color: colors.d_gray,
    },
    item: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        marginLeft: 30,
        marginBottom: 5,
        marginTop: 5,
    },
    itemText: {
        fontSize: 16,
        fontFamily: 'InterBold',
        letterSpacing: -.5,
        marginLeft: 10,
        color: colors.d_gray,
        lineHeight: 22,
    },
    time: {
        fontSize: 14,
        fontFamily: 'InterRegular',
        letterSpacing: -.5,
        color: colors.l_gray,
    },
    divider: {
        height: 1,
        backgroundColor: colors.inp,
        marginTop: 8,
        marginBottom: 6,
    },
    nextButton: {
        marginTop: 20,
        backgroundColor: '#fff',
        padding: 9,
        borderRadius: 30,
        width: '53%',
        height: 42,
        alignSelf: 'center',
        shadowColor: colors.l_gray,
        shadowOpacity: 0.1,
        shadowOffset: { width: 0, height: 2 },
        elevation: 5,
        marginBottom: 30,
    },
    nextButtonDisabled: {
        backgroundColor: colors.l_gray,
    },
    nextButtonText: {
        alignSelf: 'center', 
        fontSize: 16, 
        fontFamily: 'InterBold', 
        color: colors.d_gray, 
        letterSpacing: -.4 
    },
    dayDivider: {
        width: 1,
        height: 45,
        backgroundColor: colors.inp,
        marginHorizontal: 5,
    },
    itemTextBlock: {
        flexDirection: 'column',
        marginLeft: 10,
        marginTop: -3,
        flex: 1,
    },
    itemName: {
        fontSize: 16,
        fontFamily: 'InterBold',
        letterSpacing: -.5,
        color: colors.d_gray,
        marginBottom: 2,
    },
    metaInfoRow: {
        flexDirection: 'row',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: 10,
    },
    verticalDivider: {
        width: 4,
        borderRadius: 10,
        height: '60%',
        backgroundColor: colors.secondary,
        marginHorizontal: 6,
    },
    noPlanText: {
        fontSize: 18,
        color: colors.d_gray,
        textAlign: 'center',
        marginTop: 20,
    },
    loadingContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    loadingText: {
        fontSize: 18,
        color: colors.d_gray,
    },
});