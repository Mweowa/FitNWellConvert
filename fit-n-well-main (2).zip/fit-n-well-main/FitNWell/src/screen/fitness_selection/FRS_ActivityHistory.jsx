import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { colors } from '../../util/colors';
import FRS_TabSwitch from '../../../components/FRS_ActivityHistory/FRS_TabSwitch';
import FRS_ActivityCard from '../../../components/FRS_ActivityHistory/FRS_ActivityCard';
import FRS_ActivityDetailModal from '../../../components/FRS_ActivityHistory/FRS_ActivityDetailModel';


const FRS_ActivityHistory = () => {
  const navigation = useNavigation();
  const [activeTab, setActiveTab] = useState('Awaiting');
  const [selectedActivity, setSelectedActivity] = useState(null);
  
  const route = useRoute();
  const newActivity = route.params?.newActivity;


  const initialActivities = [
];

const [activities, setActivities] = useState(initialActivities);

React.useEffect(() => {
  if (newActivity) {
    setActivities(prev => {
      const exists = prev.find(a => a.id === newActivity.id);
      if (!exists) {
        return [newActivity, ...prev];
      }
      return prev;
    });
  }
}, [newActivity]);



  const filteredData = activities.filter(a =>
  activeTab === 'Awaiting'
    ? a.status === 'Pending' || a.status === 'Incomplete'
    : a.status !== 'Pending' && a.status !== 'Incomplete'
);


  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.headerRow}>
        <TouchableOpacity
        style={styles.backButton}
        onPress={() => {
          navigation.reset({
            index: 0,
            routes: [
              {
                name: 'MainApp',
                state: {
                  index: 0,
                  routes: [
                    {
                      name: 'MainTabs',
                      state: {
                        index: 0,
                        routes: [
                          {
                            name: 'Home',
                            state: {
                              routes: [{ name: 'FitnessSelection' }], // 👈 Make sure this matches your FeatStack route name
                            },
                          },
                        ],
                      },
                    },
                  ],
                },
              },
            ],
          });
        }}
      >
        <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
        <Text style={styles.backText}>Activity History</Text>
      </TouchableOpacity>

      </View>

      {/* Tab Switch */}
      <FRS_TabSwitch activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Activity List */}
      <FlatList
        data={filteredData}
        keyExtractor={item => item.id}
        renderItem={({ item }) => <FRS_ActivityCard{...item} onPress={() => setSelectedActivity(item)} />}
        contentContainerStyle={{ padding: 15 }}
      />
       {/* Modal */}
      <FRS_ActivityDetailModal
        visible={!!selectedActivity} 
        activity={selectedActivity} 
        onClose={() => setSelectedActivity(null)} 
      />
    </View>
  );
};

export default FRS_ActivityHistory;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 30,
  },
  backText: {
    fontSize: 19,
    marginLeft: 8,
    color: colors.secondary,
    fontFamily: 'InterBold',
    letterSpacing: -0.5,
  },
});
