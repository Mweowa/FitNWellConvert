import React, { useState } from 'react';
import { View, Text, TouchableOpacity, FlatList, ScrollView,StyleSheet, } from 'react-native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { useNavigation } from '@react-navigation/native';
import { colors } from '../../util/colors';
import {  Ionicons } from '@expo/vector-icons';

const categories = [
  'Chair Exercises',
  'Balance Exercises',
  'Cardio',
  'Flexibility',
  'Coordination',
  'Strength',
];

const dummyVideos = Array.from({ length: 10 }, (_, i) => ({ id: i.toString() }));

const FRS_BrowseVideos = () => {
  const [expanded, setExpanded] = useState({

  });

  const navigation = useNavigation();

  const toggleExpand = (category) => {
    setExpanded((prev) => ({
      ...prev,
      [category]: !prev[category],
    }));
  };

  return (  
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.headerRow}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
          <Text style={styles.backText}>Browse Videos</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>

        <View style={styles.iconTitleRow}>
          <Ionicons name="fitness-outline" size={35} color={colors.secondary} style={styles.icon} />
          <View>
            <Text style={styles.title}>Browse videos</Text>
            <Text style={styles.title2}>you want to do!</Text>
          </View>
        </View>

        <Text style={styles.subText}>"Paki-isipan ng sub text"</Text>

        <View style={styles.i_divider} />

        {categories.map((category) => {
          const renderVideoPlaceholder = ({ item, index }) => (
            <TouchableOpacity
              onPress={() => navigation.navigate('FRS_VideoPreview', {
                video: {
                  title: `${category} Video ${index + 1}`,
                  category,
                  duration: `${10 + index * 5} Minutes`,
                  thumbnail: null,
                  content: [
                    { title: 'Warm-Up Routine', time: '3 min' },
                    {
                      title: `${category} Workout`,
                      parts: [
                        { title: 'Part 1', time: '5 min' },
                        { title: 'Part 2', time: '5 min' },
                      ],
                    },
                    { title: 'Cool Down Routine', time: '3 min' },
                  ],
                }
              })}
            >
              <View style={styles.thumbnail} />
            </TouchableOpacity>
          );

          return (
            <View key={category} style={styles.categoryContainer}>
              <TouchableOpacity
                style={styles.categoryHeader}
                onPress={() => toggleExpand(category)}
              >
                <Text style={styles.categoryTitle}>{category}</Text>
                <FontAwesome6
                  name={expanded[category] ? 'circle-chevron-down' : 'circle-chevron-right'}
                  size={26}
                  color={colors.main}
                />
              </TouchableOpacity>

              {/* Show divider only if NOT expanded */}
              {!expanded[category] && <View style={styles.divider} />}

              {expanded[category] && (
                <>
                  <FlatList
                    data={dummyVideos}
                    keyExtractor={(item) => item.id}
                    renderItem={renderVideoPlaceholder}
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={styles.videoList}
                  />
                  <View style={styles.divider} />
                </>
              )}
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#fff' 
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    marginBottom:10,
  },
  backButton: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    marginTop: 30 
  },
  backText: { 
    fontSize: 19, 
    marginLeft: 8, 
    color: colors.secondary, 
    fontFamily: 'InterBold', 
    letterSpacing: -0.5 
  },

  scrollContent: {
    flexGrow: 1,
    paddingTop: 30,
    paddingBottom: 40,
    paddingHorizontal:20,
  },

  iconTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4, 
  },
  icon: {
    marginRight: 10, 
  },
  title: { 
    fontSize: 22, 
    fontFamily: 'InterRegular', 
    letterSpacing: -.5,
    color: colors.d_gray, 
    marginBottom: -6,
  },
  title2: { 
    fontSize: 22, 
    fontFamily: 'InterBold', 
    letterSpacing: -.5,
    color: colors.d_gray, 
    marginBottom: 2
  },
  subText: { 
    fontSize: 15, 
    fontFamily: 'InterRegular',
    letterSpacing: -.3,
    color: colors.d_gray, 
    marginBottom: 10, 
  },
  i_divider: {
    height: 1,
    backgroundColor: colors.l_gray,
    marginVertical: 15,
    marginBottom: 15,
  },

  categoryContainer: {
    marginBottom: 10,
  },
  categoryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
  },
    divider: {
    marginTop: 10,
    height: 1,
    backgroundColor: colors.l_gray,
  },
  categoryTitle:{
    fontSize: 16,
    fontFamily: 'InterBold',
    letterSpacing: -.5,
    color: colors.d_gray,
  },
  videoList:{
    paddingTop: 10,
    marginBottom: 15,
  },
  thumbnail: {
    width: 150,
    height: 100,
    backgroundColor: colors.inp,
    borderRadius: 8,
    marginRight: 10,
  },
});

export default FRS_BrowseVideos;
