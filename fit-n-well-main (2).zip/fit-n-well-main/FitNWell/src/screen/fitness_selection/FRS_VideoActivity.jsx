import React, { useState } from 'react';
import { AntDesign, Ionicons, Feather } from '@expo/vector-icons';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Alert, Modal, Dimensions, Image } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { colors } from '../../util/colors';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import * as ImagePicker from 'expo-image-picker';
import { BlurView } from 'expo-blur';

const { width, height } = Dimensions.get('window');

const initialSteps = [
  { id: 1, title: 'Warm-Up Exercise', duration: '6 Minutes', completed: false, videoPlayed: false },
  { id: 2, title: 'Part 1 Exercise', duration: '5 Minutes', completed: false, videoPlayed: false },
  { id: 3, title: 'Part 2 Exercise', duration: '5 Minutes', completed: false, videoPlayed: false },
  { id: 4, title: 'Cool Down Exercise', duration: '3 Minutes', completed: false, videoPlayed: false },
];

const STEP_ROW_HEIGHT = 150;
const verticalLineOffset = STEP_ROW_HEIGHT / 2;

const FRS_VideoActivity = () => {
  const navigation = useNavigation();
  const route = useRoute();
  const { title = 'Chair Basics for Beginners', category = 'Chair Exercise', existingActivities = [] } = route.params || {};

  const [steps, setSteps] = useState(initialSteps);
  const [image, setImage] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);

  const handleMarkComplete = (id) => {
    const updatedSteps = steps.map((step) => {
      if (step.id === id) return { ...step, completed: true };
      return step;
    });
    setSteps(updatedSteps);
  };

  const handlePlayVideo = (id) => {
    Alert.alert(`Play video for step ${id}`);
    setSteps(steps =>
      steps.map(step =>
        step.id === id ? { ...step, videoPlayed: true } : step
      )
    );
  };

  const pickImage = async () => {
    let result = await ImagePicker.launchCameraAsync({
      quality: 0.5,
      allowsEditing: false,
    });

    if (!result.canceled) {
      setImage(result.assets[0].uri);
    }
  };

  const isStepUnlocked = (index) => {
    if (index === 0) return true;
    return steps[index - 1].completed && steps.slice(0, index).every(s => s.completed);
  };

  const allStepsCompleted = steps.every(step => step.completed);

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.headerRow}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
          <Text style={styles.backText}> Workout Activity</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.content}>

        <View style={styles.iconTitleRow}>
          <Ionicons name="fitness-outline" size={35} color={colors.secondary} style={styles.icon} />
          <View>
            <Text style={styles.title}>Let's do</Text>
            <Text style={styles.title2}>{title}</Text>
          </View>
        </View>

        <Text style={styles.subText}>"Paki-isipan ng sub text"</Text>

        <View style={styles.i_divider} />
        

        <View style={{ position: 'relative', minHeight: steps.length * 140 }}>
          {/*vertical line */}
          <View
            style={[
              styles.verticalLine,
              {
                top: verticalLineOffset,
                bottom: verticalLineOffset,
              },
            ]}
          />
          {/* Steps */}
          {steps.map((step, index) => (
            <View key={step.id} style={styles.stepRow}>
              <View style={styles.statusIcon}>
                <TouchableOpacity
                  disabled={!step.videoPlayed || step.completed}
                  onPress={() => handleMarkComplete(step.id)}
                  style={[
                    styles.statusCircle,
                    step.completed ? styles.statusCircleCompleted : styles.statusCircleIncomplete,
                  ]}
                  activeOpacity={1}
                >
                  <Ionicons
                    name={step.completed ? 'checkmark' : ''}
                    size={22}
                    color={step.completed ? colors.inp : 'transparent'}
                  />
                </TouchableOpacity>
              </View>
              <TouchableOpacity
                style={[
                  styles.stepCard,
                  !isStepUnlocked(index) && styles.lockedCard,
                ]}
                disabled={!isStepUnlocked(index)}
                onPress={() => handlePlayVideo(step.id)}
              >
                <Ionicons
                  name="play-circle-outline"
                  size={30}
                  color={isStepUnlocked(index) ? colors.main : colors.l_gray}
                />
                <View style={{ marginLeft: 10 }}>
                  <Text style={styles.stepTitle}>{step.title}</Text>
                  <Text style={styles.stepDuration}>{step.duration}</Text>
                </View>
              </TouchableOpacity>
            </View>
          ))}
        </View>

        {/* Photo Upload */}
        <TouchableOpacity style={styles.photoBox} onPress={pickImage}>
          {image ? (
            <Image source={{ uri: image }} style={styles.uploadedImage} />
          ) : (
            <>
              <Feather name="camera" size={28} color={colors.main} />
              <Text style={styles.tlphoto}>Take Live Photo</Text>
            </>
          )}
        </TouchableOpacity>


        {/* Mark as Complete */}
        <TouchableOpacity
          style={[
            styles.completeButton,
            !allStepsCompleted && { opacity: 0.5 }
          ]}
          disabled={!allStepsCompleted}
          onPress={() => {
            if (allStepsCompleted) {
              setModalVisible(true);
            }
          }}
        >
          <Text style={styles.completeText}>Mark as Complete</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* Completion Modal */}
      <Completed
        isVisible={modalVisible}
        onClose={() => setModalVisible(false)}
        navigation={navigation}
        title={title}
        category={category}
        image={image}
        existingActivities={route.params?.existingActivities || []}
      />
    </View>
  );
};

const Completed = ({ isVisible, onClose, navigation, category, image, existingActivities = [] }) => {
  const getNextActivityNumber = () => {
    const activityTitles = existingActivities.map(a => a.title);
    const numbers = activityTitles.map(t => {
      const match = t.match(/Activity (\d+)/);
      return match ? parseInt(match[1], 10) : 0;
    });
    const maxNum = Math.max(...numbers, 0);
    return maxNum + 1;
  };

  const handleClose = () => {
    onClose();
    const today = new Date();
    const formattedDate = today.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });

    const newActivity = {
      id: Date.now().toString(),
      date: formattedDate,
      title: `Activity ${getNextActivityNumber()}`,
      type: category,
      status: 'Pending',
      image,
    };

    navigation.reset({
      index: 1,
      routes: [
        { name: 'MainApp' },
        {
          name: 'FRS_ActivityHistory',
          params: { newActivity },
        },
      ],
    });
  };

  return (
    <Modal
      animationType="fade"
      transparent
      visible={isVisible}
      onRequestClose={handleClose}
    >
      <View style={modalStyles.blurContainer}>
        <BlurView
          intensity={100}
          tint="light"
          style={StyleSheet.absoluteFill}
        />
      </View>
      <View style={modalStyles.centeredView}>
        <View style={modalStyles.modalContainer}>
          <TouchableOpacity
            style={modalStyles.closeButton}
            onPress={handleClose}
          >
            <AntDesign name="closecircle" size={26} color={colors.l_gray} />
          </TouchableOpacity>
          <Ionicons
            name="checkmark-circle-outline"
            size={90}
            color={colors.secondary}
            style={modalStyles.icon}
          />
          <Text style={modalStyles.title}>Congratulations!</Text>
          <Text style={modalStyles.message}>
            You successfully finished the workout activity.
          </Text>
        </View>
      </View>
    </Modal>
  );
};


const modalStyles = StyleSheet.create({
  blurContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  centeredView: {
    flex: 1,
    justifyContent: 'flex-end', 
    alignItems: 'center',      
  },
  modalContainer: {
    width: width * 0.90,
    height: height * 0.50, // Set height to 50% of screen height
    backgroundColor: colors.inp, // Using colors.inp (#F0F0F0)
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
    paddingVertical: 40,
    paddingHorizontal: 40,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 8,
    elevation: 5,

  },
  closeButton: {
    position: 'absolute',
    top: 15,
    right: 15,
    zIndex: 10,
    backgroundColor: 'transparent',
    padding: 0,
    borderRadius: 0,
  },
  icon: {
    marginBottom: 5,
    marginTop: 20
  },
  title: {
    fontSize: 25,
    fontFamily: 'InterBold',
    letterSpacing: -1,
    color: colors.d_gray,
    textAlign: 'center',
    marginBottom: 10,
    marginTop: 5,
  },
  message: {
    fontSize: 16,
    fontFamily: 'InterRegular',
    letterSpacing: -.3,
    color: colors.d_gray,
    textAlign: 'center',
  },
});

export default FRS_VideoActivity;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  backButton: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    marginTop: 30 
  },
  backText: { 
    fontSize: 19,
    marginLeft: 8, 
    color: colors.secondary,
    fontFamily: 'InterBold', 
    letterSpacing: -0.5  
  },
  content: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingBottom: 80,
    paddingTop: 30,
  },
  iconTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4, 
  },
  icon: {
    marginRight: 10, 
  },
  title: { 
    fontSize: 22, 
    fontFamily: 'InterRegular', 
    letterSpacing: -.5,
    color: colors.d_gray, 
    marginBottom: -6,
  },
  title2: { 
    fontSize: 22, 
    fontFamily: 'InterBold', 
    letterSpacing: -.5,
    color: colors.d_gray, 
    marginBottom: 2
  },
  subText: { 
    fontSize: 15, 
    fontFamily: 'InterRegular',
    letterSpacing: -.3,
    color: colors.d_gray, 
    marginBottom: 10, 
  },
  i_divider: {
    height: 0.2,
    backgroundColor: colors.l_gray,
    marginVertical: 15,
    marginBottom: 20,
  },


  stepRow: {
    flexDirection: 'row',
    marginBottom: 20,
    zIndex: 1,
  },
  statusIcon: {
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
    height: 140,
    width: 50, 
    zIndex: 1,
  },
  statusCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 3,
    position: 'absolute',
    left: 3, 
    backgroundColor: '#fff', 
  },
  statusCircleCompleted: {
    borderColor: colors.main,
    backgroundColor: colors.main,
    alignSelf:  'center',
  },
  statusCircleIncomplete: {
    borderColor: colors.main,
    backgroundColor: '#fff',
  },
  stepCard: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#eee',
    borderRadius: 10,
    padding: 25,
    position: 'relative',
    height: 140,
  },
  lockedCard: {
    opacity: 0.5,
  },
  stepTitle: {
    fontFamily: 'InterBold',
    fontSize: 18,
    letterSpacing: -.5,
    color: colors.d_gray,
  },
  stepDuration: {
    fontFamily: 'InterRegular',
    fontSize: 14,
    letterSpacing: -.5,
    color: colors.l_gray,
  },
  uploadBox: {
    borderWidth: 1,
    borderColor: colors.l_gray,
    borderStyle: 'dashed',
    borderRadius: 8,
    height: 130,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
  },
  uploadText: {
    color: colors.main,
    marginTop: 8,
  },
  uploadedImage: {
    width: '97%',
    height: 120,
    borderRadius: 8,
  },
  completeButton: {
    backgroundColor: '#fff',
    padding: 9,
    borderRadius: 30,
    width: '53%',
    height: 42,
    alignSelf: 'center',
    shadowColor: colors.l_gray,
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    elevation: 5,

  },
  completeText: {
    alignSelf: 'center',
    fontSize: 16,
    fontFamily: 'InterBold',
    color: colors.d_gray,
    letterSpacing: -.4,
  },
    photoBox: {
    borderWidth: 1,
    borderColor: colors.l_gray,
    borderStyle: 'dashed',
    borderRadius: 8,
    height: 130,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 30,
  },
  tlphoto: { 
    fontFamily: 'InterRegular', 
    fontSize: 13, 
    letterSpacing: -.4, 
    color: colors.l_gray 
  },
  verticalLine: {
    position: 'absolute',
    left: 20, 
    borderLeftWidth: 3,
    borderLeftColor: colors.main,
    zIndex: 0,
  },
});

