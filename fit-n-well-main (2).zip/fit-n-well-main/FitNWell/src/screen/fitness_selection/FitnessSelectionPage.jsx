import React, { useCallback } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Entypo from '@expo/vector-icons/Entypo';
import { colors } from '../../util/colors';

import { useFocusEffect } from '@react-navigation/native';
import { BackHandler } from 'react-native';



const FitnessSelectionPage = () => {
  const navigation = useNavigation();

  // ✅ Correct placement: useFocusEffect inside the component
  useFocusEffect(
      useCallback(() => {
        const backAction = () => {
          navigation.reset({
            index: 0,
            routes: [{ name: 'MainApp' }], // Go back to Home
          });
          return true;
        };
    
        // ✅ Create subscription
        const subscription = BackHandler.addEventListener('hardwareBackPress', backAction);
    
        // ✅ Correct cleanup
        return () => subscription.remove();
      }, [navigation])
    );

  return (
    <View style={styles.container}>
      <Image 
        source={require("../../assets/photos/backdrop.png")} 
        style={styles.backgroundImage} 
        resizeMode="cover" 
      />
      <View style={styles.contentWrapper}>
        <Entypo name="folder-video" style={styles.folderIcon} />
        <Text style={styles.heading}>
          <Text style={styles.headingBold}>Fitness Resource{"\n"}</Text>
          <Text style={styles.headingHighlight}>Selection</Text>
        </Text>

        <View style={styles.paragraphRow}>
          <View style={styles.verticalLine} />
          <Text style={styles.subheading}>
            Unlock your potential, unleash a{"\n"}healthier version of you.
          </Text>
        </View>

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('FRS_BrowseVideos')}>
          <Text style={styles.buttonText}>Browse Videos</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('FRS_ActivityHistory')}>
          <Text style={styles.buttonText}>Activity History</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default FitnessSelectionPage;


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  backgroundImage: {
    position: 'absolute',
    width: 550,
    height: 750,
    top: '18%',
    alignSelf: 'center',
    zIndex: 0,
    opacity: 0.6,
  },
  contentWrapper: {
    flex: 1,
    paddingHorizontal: 25,
    justifyContent: 'center',
  },
    folderIcon: {
      fontSize: 50,
      color: colors.d_gray,
      marginBottom: 5, 
  },    
  heading: {
    fontSize: 38,
    fontFamily: 'InterBold',
    marginBottom: 10,
    letterSpacing: -1,
  },
  headingBold: {
    color: colors.d_gray,
  },
  headingHighlight: {
    color: colors.secondary,
  },
  paragraphRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 50,
  },
  verticalLine: {
    width: 4,
    backgroundColor: colors.secondary,
    borderRadius: 3,
    marginRight: 10,
    alignSelf: 'stretch',
  },
  subheading: {
    fontFamily: 'InterRegular',
    fontSize: 15,
    color: colors.d_gray,
    lineHeight: 18,
    letterSpacing: -0.3,
  },
  button: {
    backgroundColor: '#fff',
    padding: 9,
    marginBottom: 16,
    borderRadius: 30,
    width: '100%',
    height: 42,
    alignSelf: 'center',
    justifyContent: 'center',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
  },
  buttonText: {
    alignSelf: 'center',
    fontSize: 16,
    fontFamily: 'InterBold',
    color: colors.d_gray,
    letterSpacing: -0.4,
  },
});