import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView,Image,} from 'react-native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useNavigation, useRoute } from '@react-navigation/native';
import { colors } from '../../util/colors';


const FRS_VideoPreview = () => {
  const navigation = useNavigation();
  const route = useRoute();
  const { video } = route.params || {};
  

  const defaultVideo = {
    title: 'Chair Basics for Beginners',
    category: 'Chair Exercise',
    duration: '15 Minutes',
    thumbnail: null, // Replace with actual URI or require()
    content: [
      { title: 'Warm-Up Routine', time: '3 min' },
      {
        title: 'Chair Basics Workout',
        parts: [
          { title: 'Part 1', time: '5 min' },
          { title: 'Part 2', time: '5 min' },
        ],
      },
      { title: 'Cool Down Routine', time: '3 min' },
    ],
  };

  const videoData = video || defaultVideo;

  return (  
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.headerRow}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
          <Text style={styles.backText}>{videoData.title}</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.contentContainer}>
        {/* Title */}

        <View style={styles.iconTitleRow}>
          <Ionicons name="fitness-outline" size={35} color={colors.secondary} style={styles.icon} />
          <View>
            <Text style={styles.title}>Let's do</Text>
            <Text style={styles.title2}>{videoData.title}</Text>
          </View>
        </View>

        <Text style={styles.subText}>"Paki-isipan ng sub text"</Text>

        <View style={styles.i_divider} />
        
        {/* Thumbnail */}
        <View style={styles.thumbnail}>
          {/* Replace with actual image if available */}
          {videoData.thumbnail ? (
            <Image source={{ uri: videoData.thumbnail }} style={styles.thumbnailImage} />
          ) : null}
        </View>

        {/* Metadata */}
        <View style={styles.metaInfo}>
          <Text style={styles.metaText}>
            <Text style={styles.metaLabel}>Category: </Text>
            {videoData.category}
          </Text>
          <Text style={styles.metaText}>
            <Text style={styles.metaLabel}>Duration: </Text>
            {videoData.duration}
          </Text>
        </View>

        <View style={styles.ii_divider} />

        {/* Content List */}
        <Text style={styles.sectionTitle}>Content</Text>

        {videoData.content.map((item, index) => (
          <View key={index} style={styles.contentItem}>
            <View style={styles.bulletCircle} />
            <View style={{ flex: 1 }}>
              <Text style={styles.contentTitle}>{item.title}</Text>
              {'time' in item && (
                <Text style={styles.mainContentTime}>Time: {item.time}</Text>
              )}
              {'parts' in item &&
                item.parts.map((part, i) => (
                  <View key={i} style={styles.partItemIndented}>
                    <View style={styles.partRow}>
                      <View style={styles.line} />
                      <View>
                        <Text style={styles.partText}>{part.title}</Text>
                        <Text style={styles.contentTime}>Time: {part.time}</Text>
                      </View>
                    </View>
                  </View>
                ))}
            </View>
          </View>
        ))}
        <View style={styles.iii_divider} /> 
        {/* Start Button */}
<TouchableOpacity
  style={styles.startButton}
  onPress={() =>
    navigation.navigate('FRS_VideoActivity', {
      title: videoData.title,
      category: videoData.category,
    })
  }
>
  <Text style={styles.startButtonText}>Start</Text>
</TouchableOpacity>

      </ScrollView>
    </View>
  );
};

export default FRS_VideoPreview;

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#fff' 
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  backButton: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    marginTop: 30 
  },
  backText: { 
    fontSize: 19, 
    marginLeft: 8, 
    color: colors.secondary, 
    fontFamily: 'InterBold', 
    letterSpacing: -0.5   
  },
  contentContainer: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingBottom: 80,
    paddingTop: 30,
  },
 
  iconTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4, 
  },
  icon: {
    marginRight: 10, 
  },
  title: { 
    fontSize: 22, 
    fontFamily: 'InterRegular', 
    letterSpacing: -.5,
    color: colors.d_gray, 
    marginBottom: -6,
  },
  title2: { 
    fontSize: 22, 
    fontFamily: 'InterBold', 
    letterSpacing: -.5,
    color: colors.d_gray, 
    marginBottom: 2
  },
  subText: { 
    fontSize: 15, 
    fontFamily: 'InterRegular',
    letterSpacing: -.3,
    color: colors.d_gray, 
    marginBottom: 10, 
  },
 


  i_divider: {
    height: 0.2,
    backgroundColor: colors.l_gray,
    marginVertical: 15,
  },



  thumbnail: {
    height: 200,
    backgroundColor: '#ddd',
    borderRadius: 10,
    marginBottom: 20,
    alignSelf: 'center', 
    width: '100%',
    marginTop: 10, 
  },

  metaInfo: {
    marginBottom: 10, 
  },
  metaLabel: {
    fontSize:18, 
    fontFamily: 'InterBold',
    letterSpacing: -.5, 
    color: colors.main, 
  },
  metaText: {
    fontSize:18, 
    fontFamily: 'InterRegular',
    letterSpacing: -.5, 
    color: colors.d_gray,   
  },
 
 
  //metaInfo = metaText: info & metaLabel: label (category, duration)


  ii_divider: {
    height: 0.3,
    backgroundColor: colors.l_gray,
    marginVertical: 15,
  },


  sectionTitle: {
    fontFamily: 'InterBold',
    fontSize: 18,
    letterSpacing: -.5, 
    marginBottom: 10,
    marginTop: 10,
    color: colors.d_gray,
  },
  contentItem: {
    marginBottom: 19,
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  bulletCircle: {
    width: 18,
    height: 18,
    borderRadius: 25,
    backgroundColor: colors.main,
    marginTop: 6,
    marginLeft: 20,
  },
  contentTitle: {
    fontFamily: 'InterBold',
    fontSize: 18,
    letterSpacing: -.5,
    color: colors.d_gray,
    marginLeft: 10,
  },
  contentTime: {
    fontFamily: 'InterRegular',
    fontSize: 15,
    letterSpacing: -.5,
    color: colors.l_gray,
  },
  mainContentTime: {
    fontFamily: 'InterRegular',
    fontSize: 15,
    letterSpacing: -.5,
    color: colors.l_gray,
    marginLeft: 10, 
  },
  partItemIndented: {
    marginLeft: 30,
    marginTop: 5, 
  },
  partRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  partText: {
    fontFamily: 'InterBold',
    fontSize: 15,
    letterSpacing: -.5,
    color: colors.d_gray,
  },
  line: {
    width: 4,
    height: 40,
    borderRadius: 30,
    backgroundColor: colors.main,
    marginRight: 8,
    marginLeft: 1,
  },
   iii_divider: {
    height: 0.2,
    backgroundColor: colors.l_gray,
    marginVertical: 15,
  },
  startButton: {
    backgroundColor: '#fff',
    padding: 9,
    borderRadius: 30,
    width: '53%',
    height: 42,
    alignSelf: 'center',
    shadowColor: colors.l_gray,
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    elevation: 5,
    marginTop: 20,
  },
  startButtonText: {
    alignSelf: 'center',
    fontSize: 16,
    fontFamily: 'InterBold',
    color: colors.d_gray,
    letterSpacing: -0.4,
  },
});
