import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, SafeAreaView, FlatList, Dimensions,} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { FontAwesome6 } from '@expo/vector-icons';
import { colors } from './../../../util/colors';


const screenWidth = Dimensions.get('window').width;

export default function HomePage() {
  const navigation = useNavigation();
  const [currentIndex, setCurrentIndex] = useState(0);
  const flatListRef = useRef(null);

  const services = [
    { label: 'Smart Route Planning', onPress: () => navigation.navigate('RoutePlanning') },
    { label: 'Personalized Fitness Coach', onPress: () => navigation.navigate('FitnessCoach') },
    { label: 'Muscle Pain Appointment', onPress: () => navigation.navigate('Appointment') },
    { label: 'Fitness Resource Selection', onPress: () => navigation.navigate('FitnessSelection') },
    { label: 'Fitness Activity Logger', onPress: () => navigation.navigate('ActivityLogger') }, 
    { label: 'Recommended Activity', onPress: () => navigation.navigate('Recommended') },
  ];

  const eventData = [
    { 
      id: '1',
      image: require('../../../assets/photos/sampleEvent.png'),
      title: 'Faculty Wellness Seminar',
      date: 'August 20, 2025',
      time: '3:00 PM - 5:00 PM',
      description: 'An engaging seminar on workplace wellness, featuring guest speakers, health tips, and guided stretching sessions.'
    },
    { 
      id: '2',
      image: require('../../../assets/photos/sampleEvent.png'),
      title: 'Zumba for Beginners',
      date: 'August 22, 2025',
      time: '6:00 PM - 7:00 PM',
      description: 'A fun and energetic Zumba class designed for all fitness levels. Bring your water and dancing shoes!'
    },
    { 
      id: '3',
      image: require('../../../assets/photos/sampleEvent.png'),
      title: 'Nutrition and Meal Prep Workshop',
      date: 'August 25, 2025',
      time: '2:00 PM - 4:00 PM',
      description: 'Learn how to prepare healthy meals in under 30 minutes. Includes live cooking demo and free recipes.'
    },
  ];


  useEffect(() => {
    const interval = setInterval(() => {
      const nextIndex = (currentIndex + 1) % eventData.length;
      flatListRef.current?.scrollToIndex({ index: nextIndex });
      setCurrentIndex(nextIndex);
    }, 3000);

    return () => clearInterval(interval);
  }, [currentIndex]);

  const handlePrev = () => {
    if (currentIndex > 0) {
      flatListRef.current.scrollToIndex({ index: currentIndex - 1 });
      setCurrentIndex(currentIndex - 1);
    }
  };

  const handleNext = () => {
    if (currentIndex < eventData.length - 1) {
      flatListRef.current.scrollToIndex({ index: currentIndex + 1 });
      setCurrentIndex(currentIndex + 1);
    }
  };

  return (
    <SafeAreaView style={styles.container}>

      <ScrollView style={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.i_divider} />

        <Text style={styles.greeting}>Hi, Gracielle</Text>
        <Text style={styles.subGreeting}>Let's get fit!</Text>

        <View style={styles.ii_divider} />

        <View style={styles.sectionHeaderRow}>
          <View style={styles.bulletCircle} />
          <Text style={styles.sectionTitle}>Upcoming Events</Text>
        </View>

        <View style={styles.carousel}>
          <TouchableOpacity
            style={[styles.leftArrow, currentIndex === 0 && { opacity: 0.3 }]}
            onPress={handlePrev}
            disabled={currentIndex === 0}
          >
            <FontAwesome6 name="circle-chevron-left" size={28} color={colors.secondary} />
          </TouchableOpacity>

          <FlatList
            ref={flatListRef}
            data={eventData}
            horizontal
            pagingEnabled
            keyExtractor={(item) => item.id}
            showsHorizontalScrollIndicator={false}
            renderItem={({ item }) => (
              <TouchableOpacity
                style={styles.eventCard}
                onPress={() => navigation.navigate('EventDeets', { event: item })}
              >
                <Image source={item.image} style={styles.eventImage} />
              </TouchableOpacity>
            )}
            onMomentumScrollEnd={(e) => {
              const index = Math.round(e.nativeEvent.contentOffset.x / screenWidth);
              setCurrentIndex(index);
            }}
          />

          <TouchableOpacity
            style={[styles.rightArrow, currentIndex === eventData.length - 1 && { opacity: 0.3 }]}
            onPress={handleNext}
            disabled={currentIndex === eventData.length - 1}
          >
            <FontAwesome6 name="circle-chevron-right" size={28} color={colors.secondary} />
          </TouchableOpacity>
        </View>

        <View style={styles.dotsContainer}>
          {eventData.map((_, index) => (
            <View
              key={index}
              style={[styles.dot, currentIndex === index && styles.activeDot]}
            />
          ))}
        </View>

        <View style={styles.iii_divider} />

        <View style={styles.grid}>
          {services.map((item, index) => (
            <TouchableOpacity key={index} style={styles.card} onPress={item.onPress}>
              <View style={styles.cardContent}>
                <View style={styles.vertLine} />
                <Text style={styles.cardText}>{item.label}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  scrollContent: {
    flex: 1,
    paddingHorizontal: 20,
  },
  i_divider: {
    height: 0.2,
    backgroundColor: colors.l_gray,
    marginVertical: 15,
  },
  greeting: {
    fontFamily: 'InterBold',
    fontSize: 40,
    letterSpacing: -1,
    color: colors.d_gray,
    alignSelf: 'center',
    marginTop: -10,
    marginBottom: -5,
  },
  subGreeting: {
    fontFamily: 'InterRegular',
    fontSize: 14,
    letterSpacing: -0.4,
    color: colors.l_gray,
    marginBottom: 15,
    alignSelf: 'center',
  },
  ii_divider: {
    height: 0.5,
    backgroundColor: colors.l_gray,
    marginBottom: 15,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  sectionTitle: {
    fontFamily: 'InterBold',
    fontSize: 16,
    letterSpacing: -0.4,
    color: colors.d_gray,
  },
  bulletCircle: {
    width: 13,
    height: 13,
    borderRadius: 30,
    backgroundColor: colors.secondary,
    marginRight: 8,
  },
  carousel: {
    marginVertical: 15,
    position: 'relative',
  },
  eventCard: {
    width: screenWidth * 0.85,
    marginHorizontal: 7,
    backgroundColor: colors.inp,
    borderRadius: 10,
    minHeight: 200,
    overflow: 'hidden',
  },
  eventImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
    position: 'absolute',
  },
  leftArrow: {
    position: 'absolute',
    left: 5,
    top: '40%',
    zIndex: 1,
    padding: 10,
  },
  rightArrow: {
    position: 'absolute',
    right: 5,
    top: '40%',
    zIndex: 1,
    padding: 10,
  },
  dotsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 5,
    marginBottom: 10,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.l_gray,
    marginHorizontal: 4,
  },
  activeDot: {
    backgroundColor: colors.secondary,
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  iii_divider: {
    height: 0.2,
    backgroundColor: colors.l_gray,
    marginTop: 10,
    marginBottom: 10,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: 10,
    paddingBottom: 10,
  },
  card: {
    width: '48%',
    backgroundColor: colors.inp,
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
  },
  cardContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  vertLine: {
    width: 4,
    backgroundColor: colors.secondary,
    marginRight: 5,
    borderRadius: 30,
    alignSelf: 'stretch',
  },
  cardText: {
    fontFamily: 'InterBold',
    fontSize: 14,
    letterSpacing: -0.5,
    color: colors.d_gray,
    lineHeight: 18,
    flexShrink: 1,
  },
});
