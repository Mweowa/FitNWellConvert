import React from 'react';
import { StyleSheet, Text, View, Image, TouchableOpacity, ScrollView } from 'react-native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { colors } from '../../../util/colors';
import { Entypo } from '@expo/vector-icons';

const EventDetail = ({ route, navigation }) => {
  const { event } = route.params;

  return (
    <View style={styles.container}>
      {/* Header with back button */}
      <View style={styles.headerRow}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
          <Text style={styles.backText}>Events</Text>
        </TouchableOpacity>
      </View>

      {/* Scrollable content */}
      <ScrollView style={styles.contentWrapper} showsVerticalScrollIndicator={false}>
        <Image source={event.image} style={styles.image} />

        {/* Dynamic Event Details */}
        <Text style={styles.title}>{event.title}</Text>

        <View style={styles.i_divider} />

        <View style={styles.row}>
          <Entypo name="pin" size={23} color={colors.main} style={styles.icon} />
          <Text style={styles.eventdeets}>Event Details</Text>
        </View>

        <Text style={styles.label}>
          Date: <Text style={styles.value}>{event.date}</Text>
        </Text>

        <Text style={styles.label}>
          Time: <Text style={styles.value}>{event.time}</Text>
        </Text>

        <View style={styles.ii_divider} />
        <Text style={styles.label}>Description:</Text>
        <Text style={styles.description}>{event.description}</Text>
      </ScrollView>
    </View>
  );
};

export default EventDetail;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 30,
  },
  backText: {
    fontSize: 19,
    marginLeft: 8,
    color: colors.secondary,
    fontFamily: 'InterBold',
    letterSpacing: -0.5,
  },
  contentWrapper: {
    paddingHorizontal: 20,
  },
  image: {
    width: '100%',
    height: 250,
    borderRadius: 10,
    marginTop: 20,
  },
    row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    marginRight: 5,
  },
  title: {
    fontSize: 25,
    fontFamily: 'InterBold',
    letterSpacing: -.5,
    color: colors.d_gray,
    marginTop: 20,
  },
  i_divider: {
    height: 0.2,
    backgroundColor: colors.d_gray,
    marginVertical: 15,
  },
  eventdeets: {
    fontSize: 18,
    fontFamily: 'InterItalic',
    marginTop: 5,
    color: colors.main,
    letterSpacing: -.5,
  },
   label: {
    fontSize: 18,
    fontFamily: 'InterItalic',
    color: colors.l_gray,
    letterSpacing: -.5,
  },
  value: {
    fontSize: 18,
    fontFamily: 'InterBoldItalic',
    color: colors.d_gray,
    letterSpacing: -.5,
  },
  ii_divider: {
    height: 0.4,
    backgroundColor: colors.d_gray,
    marginVertical: 15,
    marginTop: 20,
    marginBottom: 20,
  },

  description: {
    fontSize: 18,
    fontFamily: 'InterItalic',
    color: colors.d_gray,
    letterSpacing: -.5,
    marginBottom: 20,
  },
});
