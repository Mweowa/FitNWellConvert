import { StyleSheet, Text, View, FlatList, TouchableOpacity } from 'react-native';
import React from 'react';
import { colors } from '../../../util/colors';

const mockNotifications = [
  {
    id: '1',
    title: 'Workout Completed',
    message: 'You have completed your 5K run!',
    time: '2h ago',
    read: false,
  },
  {
    id: '2',
    title: 'New Challenge Available',
    message: 'Join the August Fitness Challenge now!',
    time: '5h ago',
    read: true,
  },
];

const NotifPage = () => {
  const renderItem = ({ item }) => (
    <TouchableOpacity style={[styles.notification, item.read && styles.read]}>
      <Text style={styles.title}>{item.title}</Text>
      <Text style={styles.message}>{item.message}</Text>
      <Text style={styles.time}>{item.time}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={mockNotifications}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
      />
    </View>
  );
};

export default NotifPage;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  notification: {
    padding: 16,
    marginBottom: 10,
    borderRadius: 10,
    backgroundColor: colors.inp,
  },
  read: {
    opacity: 0.5,
  },
  title: {
    fontFamily: 'InterBold',
    fontSize: 20,
    letterSpacing: -.5,
    color: colors.d_gray,
  },
  message: {
    marginTop: 4,
    fontFamily: 'InterRegular',
    fontSize: 15,
    letterSpacing: -.5,
    color: colors.d_gray,
  },
  time: {
    marginTop: 6,
    fontFamily: 'InterRegular',
    fontSize: 13,
    letterSpacing: -.5,
    color: colors.l_gray,
  },
});
