import React, { useState } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, TextInput, Alert, ScrollView, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import * as ImagePicker from 'expo-image-picker';
import { colors } from '../../../../util/colors';

const BasicInfo = () => {
  const navigation = useNavigation();
  const [editMode, setEditMode] = useState(false);
  const [userInfo, setUserInfo] = useState({
    lastName: 'Moribus',
    firstName: 'Gracielle Anne',
    sex: 'Female',
    age: '46',
    userType: 'Academic Staff',
    position: 'Professor',
    department: 'College of Human Kinetics',
    email: 'username@gmail.com',
    photo: null, 
  });

  const fieldLabels = {
    lastName: 'Surname',
    firstName: 'Name',
    sex: 'Sex',
    age: 'Age',
    userType: 'User Type',
    email: 'Email Address',
  };

  const formatLabel = (key) => {
    if (fieldLabels[key]) return fieldLabels[key];
    return key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
  };

  const handleSave = () => {
    Alert.alert(
      "Save Changes",
      "Are you sure you want to save these changes?",
      [
        { text: "Cancel", style: "cancel" },
        { text: "Save", onPress: () => { setEditMode(false); Alert.alert("Profile Saved!"); } }
      ]
    );
  };

  const handleChange = (key, value) => {
    setUserInfo({ ...userInfo, [key]: value });
  };

  const handlePickImage = async () => {
    if (!editMode) return;

    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permissionResult.granted) {
      Alert.alert("Permission Denied", "You need to grant permission to access photos.");
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 1,
      allowsEditing: true,
    });

    if (!result.canceled) {
      setUserInfo({ ...userInfo, photo: result.assets[0].uri });
    }
  };

  return (
    <View style={styles.screen}>
      {/* Header */}
      <View style={styles.headerRow}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
          <Text style={styles.backText}>{editMode ? "Edit Profile" : "Basic Information"}</Text>
        </TouchableOpacity>
      </View>

      {/* Scrollable Content */}
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        
        {/* Avatar */}
        <TouchableOpacity onPress={handlePickImage} activeOpacity={editMode ? 0.7 : 1}>
          {userInfo.photo ? (
            <Image source={{ uri: userInfo.photo }} style={styles.avatar} />
          ) : (
            <View style={styles.avatarPlaceholder}>
              <FontAwesome6 name="user" size={50} color={colors.d_gray} />
              {editMode && <Text style={styles.editPhotoText}>Edit Photo</Text>}
            </View>
          )}
        </TouchableOpacity>

        {/* Fields */}
        {Object.entries(userInfo).filter(([key]) => key !== 'photo').map(([key, value]) => (
          <View key={key} style={styles.fieldContainer}>
            <Text style={styles.label}>{formatLabel(key)}</Text>
            <TextInput
              style={[styles.input, !editMode && styles.inputDisabled]}
              value={value}
              editable={editMode}
              onChangeText={(text) => handleChange(key, text)}
            />
          </View>
        ))}

        {/* Save / Edit Button */}
        <TouchableOpacity
          style={styles.saveBtn}
          onPress={() => (editMode ? handleSave() : setEditMode(true))}
        >
          <Text style={styles.saveBtnText}>{editMode ? "Save Profile" : "Edit Profile"}</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

export default BasicInfo;

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#fff' },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    zIndex: 10,
  },
  backButton: { flexDirection: 'row', alignItems: 'center', marginTop: 30 },
  backText: {
    fontSize: 19,
    marginLeft: 8,
    color: colors.secondary,
    fontFamily: 'InterBold',
    letterSpacing: -0.5,
  },
  scrollContent: { paddingHorizontal: 20, paddingTop: 10, paddingBottom: 100 },
  avatar: {
    width: 130,
    height: 130,
    borderRadius: 65,
    alignSelf: 'center',
    marginVertical: 15,
  },
  avatarPlaceholder: {
    width: 130,
    height: 130,
    backgroundColor: colors.inp,
    borderRadius: 65,
    alignSelf: 'center',
    marginVertical: 15,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 40,
  },
  editPhotoText: {
    position: 'absolute',
    bottom: -23,
    fontSize: 14,
    fontFamily: 'InterRegular',
    letterSpacing: -.5,
    color: colors.l_gray,
  },
  fieldContainer: { marginBottom: 10 },
  label: {
    fontSize: 15,
    color: colors.main,
    fontFamily: 'InterBold',
    letterSpacing: -0.3,
  },
  input: {
    backgroundColor: colors.inp,
    padding: 20,
    borderRadius: 10,
    fontSize: 15,
    fontFamily: 'InterRegular',
    letterSpacing: -0.4,
    marginVertical: 5,
    color: colors.d_gray,
  },
  inputDisabled: { backgroundColor: colors.inp, color: colors.d_gray },
  saveBtn: {
    backgroundColor: '#fff',
    padding: 9,
    borderRadius: 30,
    width: '53%',
    height: 42,
    alignSelf: 'center',
    shadowColor: colors.l_gray,
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    elevation: 5,
    marginTop: 30,
  },
  saveBtnText: {
    alignSelf: 'center',
    fontSize: 16,
    fontFamily: 'InterBold',
    color: colors.d_gray,
    letterSpacing: -0.4,
  },
});
