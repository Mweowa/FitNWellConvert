import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, StyleSheet, ScrollView } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { colors } from '../../../../util/colors';


const MeasurementGuideEdit = () => {
  const navigation = useNavigation();
  const route = useRoute();
  const { measureKey, label, currentValue, unit, } = route.params;

  const [value, setValue] = useState(currentValue || "");

  const handleSave = () => {
  if (!value) {
    Alert.alert("Missing Measurement", `Please input ${label} before saving.`);
    return;
  }
    navigation.reset({
    index: 0, 
    routes: [
      {
        name: 'MainApp',
        state: {
          index: 0,
          routes: [
            {
              name: 'MainTabs',
              state: {
                index: 0,
                routes: [
                  {
                    name: 'Home',
                    state: {
                      routes: [{ name: 'User' }], // 👈 Added User here
                    },
                  },
                ],
              },
            },
          ],
        },
      },
      {
        name: 'AnthroInfo',
        params: {
          updatedKey: measureKey,
          updatedValue: value,
          stayInEdit: true,
        },
      },
    ],
  });
  };
    


  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.headerRow}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
          <Text style={styles.backText}>{label}</Text>
        </TouchableOpacity>
      </View>

      {/* ✅ Fixed ScrollView width */}
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.iconTitleRow}>
          <FontAwesome6 name="ruler" size={35} color={colors.secondary} style={styles.icon} />
          <View>
            <Text style={styles.title}>Let's measure your</Text>
            <Text style={styles.title2}>{label}!</Text>
          </View>
        </View>

        <Text style={styles.subText}>
          Follow the video guide below to make sure you get an accurate measurement.
        </Text>

        {/* Placeholder for video */}
        <View style={styles.videoBox}>
          <Text style={{ color: colors.secondary }}>▶ </Text>
        </View>

        {/* Measurement Input */}
         <Text style={styles.label}>{label}</Text>
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          value={value}
          onChangeText={setValue}
          placeholder={`Enter measurement (${unit || 'cm'})`}   
          placeholderTextColor={colors.l_gray}
        />


        {/* Save Button */}
        <TouchableOpacity style={styles.saveBtn} onPress={handleSave}>
          <Text style={styles.saveText}>Save</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

export default MeasurementGuideEdit;

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#fff' 
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 30
  },
  backText: {
    fontSize: 19,
    marginLeft: 8,
    color: colors.secondary,
    fontFamily: 'InterBold',
    letterSpacing: -0.5
  },

  scrollContent: { 
    paddingHorizontal: 20, 
    paddingTop: 50, 
    paddingBottom: 80 
  },
  iconTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4, 
  },
  icon: {
    marginRight: 10, 
  },
  title: { 
    fontSize: 22, 
    fontFamily: 'InterRegular', 
    letterSpacing: -.5,
    color: colors.d_gray, 
    marginBottom: -6,
  },
  title2: { 
    fontSize: 22, 
    fontFamily: 'InterBold', 
    letterSpacing: -.5,
    color: colors.d_gray, 
    marginBottom: 2
  },
  subText: { 
    fontSize: 15, 
    fontFamily: 'InterRegular',
    letterSpacing: -.3,
    color: colors.d_gray, 
    marginBottom: 20 
  },
  videoBox: { 
    height: 180, 
    backgroundColor: '#eee', 
    justifyContent: 'center', 
    alignItems: 'center', 
    borderRadius: 10, 
    marginBottom: 20 
  },
  label: {
    fontSize: 15,
    color: colors.main,
    fontFamily: 'InterBold',
    letterSpacing: -0.3,
  },
  input: { 
    backgroundColor: colors.inp,
    padding: 20,
    borderRadius: 10,
    fontSize: 15,
    fontFamily: 'InterRegular',
    letterSpacing: -0.4,
    marginVertical: 5,
    color: colors.d_gray,
  },

  saveBtn: { 
    backgroundColor: '#fff',
    padding: 9,
    borderRadius: 30,
    width: '53%',
    height: 42,
    alignSelf: 'center',
    shadowColor: colors.l_gray,
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    elevation: 5,
    marginTop: 30,
  },
  saveText: { 
    alignSelf: 'center',
    fontSize: 16,
    fontFamily: 'InterBold',
    color: colors.d_gray,
    letterSpacing: -0.4, 
  }
});
