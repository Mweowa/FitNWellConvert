import React from 'react';
import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Feather } from '@expo/vector-icons';
import { colors } from './../../../util/colors';

const UserPage = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      {/* Profile Card */}
      <View style={styles.profileCard}>
        <View style={styles.avatar} />
        <Text style={styles.name}>Gracielle Moribus</Text>
        <Text style={styles.role}>Academic Staff</Text>
      </View>

      {/* Grid Menu */}
      <View style={styles.grid}>
        <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('BasicInfo')} >
          <View style={styles.iconWrapper}>
            <Feather name="info" size={35} color={colors.secondary} />
          </View>
          <View style={styles.cardFooter}>
            <View style={styles.vertLine} />
            <Text style={styles.cardTitle}>Basic Information</Text>
          </View>
        </TouchableOpacity>

        <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('AnthroInfo')} >
          <View style={styles.iconWrapper}>
            <Feather name="activity" size={35} color={colors.secondary} />
          </View>
          <View style={styles.cardFooter}>
            <View style={styles.vertLine} />
            <Text style={styles.cardTitle}>Anthropometric Measures</Text>
          </View>
        </TouchableOpacity>

        <TouchableOpacity style={styles.card}>
          <View style={styles.iconWrapper}>
            <Feather name="file-text" size={35} color={colors.secondary} />
          </View>
          <View style={styles.cardFooter}>
            <View style={styles.vertLine} />
            <Text style={styles.cardTitle}>PARQ</Text>
          </View>
        </TouchableOpacity>

        <TouchableOpacity style={styles.card}>
          <View style={styles.iconWrapper}>
            <Feather name="bar-chart-2" size={35} color={colors.secondary} />
          </View>
          <View style={styles.cardFooter}>
            <View style={styles.vertLine} />
            <Text style={styles.cardTitle}>My Activity Reports</Text>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default UserPage;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
    alignItems: 'center',
  },
  profileCard: {
    backgroundColor: colors.secondary,
    height: '50%',
    width: '100%',
    borderBottomLeftRadius: 40,
    borderBottomRightRadius: 40,
    alignItems: 'center',
    paddingVertical: 30,
    marginBottom: 15,
  },
  avatar: {
    width: 130,
    height: 130,
    borderRadius: 65,
    backgroundColor: '#fff',
    marginBottom: 10,
    marginTop: 25,
  },
  name: {
    fontFamily: 'InterBold',
    fontSize: 28,
    color: colors.d_gray,
    letterSpacing: -1,
  },
  role: {
    fontFamily: 'InterRegular',
    fontSize: 18,
    color: colors.d_gray,
    letterSpacing: -0.5,
    marginTop: -9,
  },
  grid: {
    width: '90%',
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  card: {
    width: '48%',
    backgroundColor: colors.inp,
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    height: 125,
    justifyContent: 'flex-end',
  },
  iconWrapper: {
    alignItems: 'flex-start',
    marginBottom: 10, 
  },
  cardFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  vertLine: {
    width: 4,
    height: 32,
    backgroundColor: colors.secondary,
    borderRadius: 30,
  },
  cardTitle: {
    fontFamily: 'InterBold',
    fontSize: 15,
    letterSpacing: -.5,
    color: '#333',
    flexShrink: 1,
    color: colors.d_gray,
  },
});
