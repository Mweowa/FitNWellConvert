import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { colors } from '../../util/colors';
import SRP_TabSwitch from '../../../components/SRP_ActivityHistory/SRP_TabSwitch';
import SRP_ActivityCard from '../../../components/SRP_ActivityHistory/SRP_ActivityCard';
import SRP_ActivityDetailModal from '../../../components/SRP_ActivityHistory/SRP_ActivityDetailModel';


const SRP_ActivityHistory = () => {
  const navigation = useNavigation();
  const [activeTab, setActiveTab] = useState('Awaiting');
  const [selectedActivity, setSelectedActivity] = useState(null);

  const activities = [
    { id: '1', date: 'April 27, 2025', type: 'Running',  status: 'Pending', distance: '5.02 km', duration: '45 mins' },
    { id: '2', date: 'April 15, 2025', type: 'Walking',  status: 'Verified', distance: '12.02 km', duration: '1hr 35mins' },
    { id: '3', date: 'March 25, 2025', type: 'Walking',  status: 'Rejected', distance: '8.5 km', duration: '1hr 15mins' },
    { id: '4', date: 'March 15, 2025', type: 'Running',  status: 'Rejected', distance: '18.02 km', duration: '1hr 10mins' },
  ];

  const filteredData = activities.filter(a =>
    activeTab === 'Awaiting' ? a.status === 'Pending' : a.status !== 'Pending'
  );

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.headerRow}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
          <Text style={styles.backText}>Activity History</Text>
        </TouchableOpacity>
      </View>

      {/* Tab Switch */}
      <SRP_TabSwitch activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Activity List */}
      <FlatList
        data={filteredData}
        keyExtractor={item => item.id}
        renderItem={({ item }) => <SRP_ActivityCard{...item} onPress={() => setSelectedActivity(item)} />}
        contentContainerStyle={{ padding: 15 }}
      />

    <SRP_ActivityDetailModal
            visible={!!selectedActivity} 
            activity={selectedActivity} 
            onClose={() => setSelectedActivity(null)} 
          />      
    </View>
  );
};

export default SRP_ActivityHistory;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 30,
  },
  backText: {
    fontSize: 19,
    marginLeft: 8,
    color: colors.secondary,
    fontFamily: 'InterBold',
    letterSpacing: -0.5,
  },
});
