import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  TextInput, 
  Image, 
  ScrollView, 
  KeyboardAvoidingView, 
  Platform 
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { colors } from '../../util/colors';

const SRP_PlanRoute = () => {
  const navigation = useNavigation();
  const [startPoint, setStartPoint] = useState('');
  const [endPoint, setEndPoint] = useState('');

  return (
    <View style={styles.container}>
      {/* Background image */}
      <Image 
        source={require("../../assets/photos/backdrop.png")} 
        style={styles.backgroundImage} 
        resizeMode="cover" 
      />

      {/* Fixed Header */}
      <View style={styles.headerRow}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
          <Text style={styles.backText}>Plan Route</Text>
        </TouchableOpacity>
      </View>

      {/* Scrollable + KeyboardAvoiding content */}
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView 
          contentContainerStyle={{ flexGrow: 1, paddingHorizontal: 25, paddingBottom: 40 }}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <Text style={styles.mainHeading}>
            <Text style={styles.mainHeadingBold}>Plan{"\n"}</Text>
            <Text style={styles.mainHeadingHighlight}>Your Route</Text>
          </Text>

          <View style={styles.paragraphRow}>
            <View style={styles.verticalLine} />
            <Text style={styles.subheading}>
              To plan your route and track your{"\n"}activity, <Text style={styles.subheadingHighlight}>please enable location services</Text>.
            </Text>
          </View>

          <View style={styles.divider} />

          <View style={styles.inputContainer}>
            <Text style={styles.inputLabel}>Start Point</Text>
            <TextInput
              style={styles.input}
              value={startPoint}
              onChangeText={setStartPoint}
              placeholder="Current location"
              placeholderTextColor="#999"
            />
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.inputLabel}>End Point</Text>
            <TextInput
              style={styles.input}
              value={endPoint}
              onChangeText={setEndPoint}
              placeholder="Enter end point"
              placeholderTextColor="#999"
            />
          </View>

          <TouchableOpacity
            style={styles.confirmButton}
            onPress={() => navigation.navigate('SRP_RoutePreview')}
          >
            <Text style={styles.confirmButtonText}>Confirm</Text>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
};

export default SRP_PlanRoute;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },

  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    zIndex: 10, // ensures it stays above scroll content
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 30,
  },
  backText: {
    fontSize: 19,
    marginLeft: 8,
    color: colors.secondary,
    fontFamily: 'InterBold',
    letterSpacing: -0.5,
  },
  backgroundImage: {
    position: 'absolute',
    width: 400,
    height: 450,
    top: -35,
    left: 50,
    alignSelf: 'center',
    opacity: 0.6,
    zIndex: 0, 
  },

  mainHeading: {
    fontSize: 40,
    fontFamily: 'InterBold',
    marginBottom: 10,
    marginTop: 40, 
    letterSpacing: -1,
  },
  mainHeadingBold: {
    color: colors.d_gray,
  },
  mainHeadingHighlight: {
    color: colors.secondary,
  },
  paragraphRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 30,
  },
  verticalLine: {
    width: 4,
    backgroundColor: colors.secondary,
    borderRadius: 3,
    marginRight: 10,
    alignSelf: 'stretch',
  },
  subheading: {
    fontFamily: 'InterRegular',
    fontSize: 15,
    color: colors.d_gray,
    lineHeight: 18,
    letterSpacing: -.3,
  },
  subheadingHighlight: {
    fontFamily: 'InterBold',
    color: colors.d_gray,
  },
  divider: {
    height: 1,
    backgroundColor: '#E0E0E0',
    marginVertical: 10,
    marginBottom: 50,
  },
  inputContainer: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 15,
    color: colors.main,
    fontFamily: 'InterBold',
    letterSpacing: -0.3,
  },
  input: {
    backgroundColor: colors.inp,
    padding: 20,
    borderRadius: 10,
    fontSize: 15,
    fontFamily: 'InterRegular',
    letterSpacing: -0.4,
    marginVertical: 5,
    color: colors.d_gray,
  },
  confirmButton: {
    backgroundColor: '#fff',
    padding: 9,
    borderRadius: 30,
    width: '53%',
    height: 42,
    alignSelf: 'center',
    shadowColor: colors.l_gray,
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    elevation: 5,
    marginTop: 20,
  },
  confirmButtonText: {
    alignSelf: 'center',
    fontSize: 16,
    fontFamily: 'InterBold',
    color: colors.d_gray,
    letterSpacing: -0.4,
  },
});
