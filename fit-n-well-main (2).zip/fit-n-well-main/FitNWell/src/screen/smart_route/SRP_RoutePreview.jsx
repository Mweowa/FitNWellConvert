import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { colors } from '../../util/colors';

const SRP_RoutePreview = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.headerRow}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
          <Text style={styles.backText}>Plan Route</Text>
        </TouchableOpacity>
      </View>

      {/* Map Preview */}
      <View style={styles.mapContainer}>
        <Image
          source={{ uri: 'https://placehold.co/600x300/e0e0e0/50e586?text=Map+Route+Preview' }}
          style={styles.mapImage}
        />
      </View>

      <View style={styles.divider} />

      {/* Info Section */}
      <View style={styles.infoCard}>
        <View style={styles.infoTopRow}>
          <View>
            <Text style={styles.distanceLabel}>Distance</Text>
            <Text style={styles.distanceValue}>5.02 km</Text>
          </View>

          <Image
            source={require("../../assets/photos/fnw1.png")}
            style={styles.fnLogo}
          />
        </View>

        <View style={styles.metricsRow}>
          <View style={styles.metric}>
            <Text style={styles.metricLabel}>Estimated Duration</Text>
            <Text style={styles.metricValueOneLine}>45 mins</Text>
          </View>
          <View style={styles.metric}>
            <Text style={styles.metricLabel}>Est. Pace</Text>
            <Text style={styles.metricValueUnderlined}>4:30 m/s</Text>
          </View>
          <View style={styles.metric}>
            <Text style={styles.metricLabel}>Est. Elevation</Text>
            <Text style={styles.metricValueUnderlined}>45/km</Text>
          </View>
        </View>
      </View>

      {/* Confirm Button */}
      <TouchableOpacity style={styles.confirmButton}>
        <Text style={styles.confirmText}>Confirm</Text>
      </TouchableOpacity>

      <View style={styles.divider} />
    </View>
  );
};

export default SRP_RoutePreview;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 30,
  },
  backText: {
    fontSize: 19,
    marginLeft: 8,
    color: colors.secondary,
    fontFamily: 'InterBold',
    letterSpacing: -0.5,
  },
  mapContainer: {
    width: '90%',
    alignSelf: 'center',
    height: 250,
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 20,
    marginTop: 20,
    position: 'relative',
    backgroundColor: colors.pending,
  },
  mapImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  fnLogo: {
    width: 130,
    height: 130,
    resizeMode: 'contain',
    marginTop: -30, // pulls it upward into gray box
    marginRight: -10, // pulls it outside right edge a bit
    position: 'absolute',
    marginLeft: 175 // aligns it to the left edge
  },
  infoCard: {
    marginTop: 10,
    borderRadius: 18,
    marginHorizontal: 15,
  },
  infoTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
    padding: 15,
    borderRadius: 12,
    width: '100%',
    backgroundColor: colors.inp,
    overflow: 'visible',
  },
  distanceLabel: {
    fontSize: 15,
    color: colors.d_gray,
    marginRight: 10,
    fontFamily: 'InterMedium',
  },
  distanceValue: {
    fontSize: 24,
    fontFamily: 'InterBold',
    color: colors.d_gray,
  },
  metricsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    paddingBottom: 10,
    marginTop: -10,
  },
  metric: {
    flex: 1,
    alignItems: 'flex-start',
    justifyContent: 'center',
  },
  metricLabel: {
    fontSize: 13,
    color: '#666',
    fontFamily: 'InterRegular',
    marginBottom: 5,
    textAlign: 'left',
    marginLeft: 0,
  },
  metricValue: {
    fontSize: 24,
    fontFamily: 'InterBold',
    color: colors.d_gray,
    includeFontPadding: false,
    textAlign: 'left',
  },
  metricValueOneLine: {
    fontSize: 18,
    fontFamily: 'InterBold',
    color: colors.d_gray,
    includeFontPadding: false,
    textAlign: 'left',
  },
  metricValueUnderlined: {
    fontSize: 16,
    fontFamily: 'InterBold',
    color: colors.d_gray,
    borderBottomWidth: 2,
    borderBottomColor: colors.main,
    paddingBottom: 2,
  },
  confirmButton: {
    backgroundColor: '#fff',
    paddingVertical: 12,
    borderRadius: 25,
    marginTop: 30,
    alignItems: 'center',
    elevation: 5,
    shadowColor: '#aaa',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    marginBottom: 50,
    marginHorizontal: 15,
    width: '50%',
    alignSelf: 'center',
  },
  confirmText: {
    fontSize: 16,
    color: '#333',
    fontFamily: 'InterBold',
  },
  divider: {
    height: 1,
    backgroundColor: '#ccc',
    marginBottom: 20,
    opacity: 0.6,
    width: '90%',
    alignSelf: 'center',
  },
});