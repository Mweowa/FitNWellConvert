import React from 'react'
import { StyleSheet, Text, View, TouchableOpacity, Image } from 'react-native'
import { useNavigation } from '@react-navigation/native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { colors } from '../../util/colors';


const SmartRoutePage = () => {
  const navigation = useNavigation();
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
  return (
    <View style={styles.container}>
      <Image 
        source={require("../../assets/photos/backdrop.png")} 
        style={styles.backgroundImage} 
        resizeMode="cover" 
      />
      <View style={styles.contentWrapper}>
        <FontAwesome6 name="route" style={styles.routeIcon} />
        <Text style={styles.heading}>
          <Text style={styles.headingBold}>Smart Route{"\n"}</Text>
          <Text style={styles.headingHighlight}>Planning</Text>
        </Text>

        <View style={styles.paragraphRow}>
          <View style={styles.verticalLine} />
          <Text style={styles.subheading}>
            Level up your running activity by{"\n"}personalizing your route.
          </Text>
        </View>

        <View style={styles.i_divider} />

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('SRP_PlanRoute')}>
          <Text style={styles.buttonText}>Plan Route</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('SRP_ActHis')}>
          <Text style={styles.buttonText}>Activity History</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default SmartRoutePage;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  backgroundImage: {
    position: 'absolute',
    width: 550,
    height: 750,
    top: '18%',
    alignSelf: 'center',
    zIndex: 0,
    opacity: .6,
  },
  contentWrapper: {
    flex: 1,
    paddingHorizontal: 25,
    justifyContent: 'center',
  },
  routeIcon: {
    fontSize: 50,
    color: colors.d_gray,
    marginBottom: 5, 
  },
  heading: {
    fontSize: 40,
    fontFamily: 'InterBold',
    marginBottom: 10,
    letterSpacing: -1,
  },
  headingBold: {
    color: colors.d_gray,
  },
  headingHighlight: {
    color: colors.secondary,
  },
  paragraphRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 50,
  },
  verticalLine: {
    width: 4,
    backgroundColor: colors.secondary,
    borderRadius: 3,
    marginRight: 10,
    alignSelf: 'stretch',
  },
  subheading: {
    fontFamily: 'InterRegular',
    fontSize: 15,
    color: colors.d_gray,
    lineHeight: 18,
    letterSpacing: -.3,
  },
  i_divider: {
    height: 0.5,
    backgroundColor: colors.l_gray,
    marginBottom: 50,
  },
  button: {
    backgroundColor: '#fff',
    padding: 9,
    marginBottom: 16,
    borderRadius: 30,
    width: "100%",
    height: 42,
    alignSelf: 'center',
    justifyContent: 'center',
    elevation: 5,
    shadowColor: colors.l_gray, 
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
  },
  buttonText: {
    alignSelf: 'center',
    fontSize: 16,
    fontFamily: 'InterBold',
    color: colors.d_gray,
    letterSpacing: -.4, 
  },
});
