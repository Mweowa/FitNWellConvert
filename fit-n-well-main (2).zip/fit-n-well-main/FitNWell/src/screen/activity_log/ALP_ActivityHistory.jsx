import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { colors } from '../../util/colors';
import ALP_TabSwitch from '../../../components/ALP_ActivityHistory/ALP_TabSwitch';
import ALP_ActivityCard from '../../../components/ALP_ActivityHistory/ALP_ActivityCard';
import ALP_ActivityDetailModal from '../../../components/ALP_ActivityHistory/ALP_ActivityDetailModel';

import { useRoute } from '@react-navigation/native';

const ALP_ActivityHistory = () => {
  const navigation = useNavigation();
  const route = useRoute();

  const [activeTab, setActiveTab] = useState('Awaiting');
  const [selectedActivity, setSelectedActivity] = useState(null);

  const [activities, setActivities] = useState([
]);


  // ✅ Check if newActivity is passed and add it to the list
  React.useEffect(() => {
    if (route.params?.newActivity) {
      setActivities(prev => [route.params.newActivity, ...prev]);
    }
  }, [route.params?.newActivity]);

  const filteredData = activities.filter(a =>
    activeTab === 'Awaiting' ? a.status === 'Pending' : a.status !== 'Pending'
  );

  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <TouchableOpacity
        style={styles.backButton}
        onPress={() => {
          navigation.reset({
            index: 0,
            routes: [
              {
                name: 'MainApp',
                state: {
                  index: 0,
                  routes: [
                    {
                      name: 'MainTabs',
                      state: {
                        index: 0,
                        routes: [
                          {
                            name: 'Home',
                            state: {
                              routes: [{ name: 'ActivityLogger' }], 
                            },
                          },
                        ],
                      },
                    },
                  ],
                },
              },
            ],
          });
        }}
      >
        <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
        <Text style={styles.backText}>Activity History</Text>
      </TouchableOpacity>

      </View>


      {/* Tab Switch */}
      <ALP_TabSwitch activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Activity List */}
      <FlatList
        data={filteredData}
        keyExtractor={item => item.id}
        renderItem={({ item }) => <ALP_ActivityCard{...item} onPress={() => setSelectedActivity(item)} />}
        contentContainerStyle={{ padding: 15 }}
      />
       {/* Modal */}
      <ALP_ActivityDetailModal
        visible={!!selectedActivity} 
        activity={selectedActivity} 
        onClose={() => setSelectedActivity(null)} 
      />
    </View>
  );
};

export default ALP_ActivityHistory;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 30,
  },
  backText: {
    fontSize: 19,
    marginLeft: 8,
    color: colors.secondary,
    fontFamily: 'InterBold',
    letterSpacing: -0.5,
  },
});
