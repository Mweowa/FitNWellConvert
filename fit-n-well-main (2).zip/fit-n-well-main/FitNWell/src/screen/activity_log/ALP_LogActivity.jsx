import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, View, TouchableOpacity, Keyboard, TouchableWithoutFeedback, ScrollView, Image, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { useNavigation } from '@react-navigation/native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import Feather from '@expo/vector-icons/Feather';
import DateTimePicker from '@react-native-community/datetimepicker';
import { colors } from '../../util/colors';

import { Modal, Dimensions } from 'react-native';
import { BlurView } from 'expo-blur';
import AntDesign from '@expo/vector-icons/AntDesign';
import Ionicons from '@expo/vector-icons/Ionicons';

const { width, height } = Dimensions.get('window');

const ALP_LogActivity = () => {
  const navigation = useNavigation();

  const [title, setTitle] = useState('');
  const [activityType, setActivityType] = useState('');
  const [description, setDescription] = useState('');

  const [photo, setPhoto] = useState(null);


  // ✅ Date states
  const [date, setDate] = useState(null);
  const [pickerDate, setPickerDate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);

  // ✅ Suggestions state
  const [filteredOptions, setFilteredOptions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);


  const [modalVisible, setModalVisible] = useState(false);

  // ✅ Fitness activity options
  const activityOptions = [
    { label: 'Cycling', value: 'cycling' },
    { label: 'Swimming', value: 'swimming' },
    { label: 'Strength Training', value: 'strength_training' },
    { label: 'Yoga', value: 'yoga' },
    { label: 'Pilates', value: 'pilates' },
    { label: 'CrossFit', value: 'crossfit' },
    { label: 'Basketball', value: 'basketball' },
    { label: 'Football', value: 'football' },
    { label: 'Badminton', value: 'badminton' },
    { label: 'Tennis', value: 'tennis' },
    { label: 'Zumba', value: 'zumba' }
  ];

  const formatFullDate = (dateObj) => {
    if (!dateObj) return '';
    const month = new Intl.DateTimeFormat('en-US', { month: 'long' }).format(dateObj);
    const day = String(dateObj.getDate()).padStart(2, '0');
    const year = dateObj.getFullYear();
    return `${month} ${day}, ${year}`;
  };

  const handleActivityChange = (text) => {
    setActivityType(text);
    const matches = activityOptions.filter((opt) =>
      opt.label.toLowerCase().includes(text.toLowerCase())
    );
    setFilteredOptions(matches);
    setShowSuggestions(text.length > 0);
  };

  const handleSelectActivity = (label) => {
    setActivityType(label);
    setShowSuggestions(false);
    Keyboard.dismiss();
  };

  const dismissKeyboardAndSuggestions = () => {
    Keyboard.dismiss();
    setShowSuggestions(false);
  };

  const openImageOptions = () => {
  Alert.alert(
    'Photo Options',
    'Choose an action:',
    [
      { text: 'Take Photo', onPress: launchCamera },
      { text: 'Choose from Gallery', onPress: launchGallery },
      { text: 'Remove Photo', onPress: () => setPhoto(null), style: 'destructive' },
      { text: 'Cancel', style: 'cancel' },
    ],
    { cancelable: true }
  );
};

const launchCamera = async () => {
  const { granted } = await ImagePicker.requestCameraPermissionsAsync();
  if (!granted) {
    Alert.alert('Permission Denied', 'Camera access is required.');
    return;
  }

  const result = await ImagePicker.launchCameraAsync({
    allowsEditing: false,
    quality: 1,
  });

  if (!result.canceled) {
    setPhoto(result.assets[0].uri);
  }
};

const launchGallery = async () => {
  const { granted } = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!granted) {
    Alert.alert('Permission Denied', 'Media library access is required.');
    return;
  }

  const result = await ImagePicker.launchImageLibraryAsync({
    allowsEditing: false,
    quality: 1,
  });

  if (!result.canceled) {
    setPhoto(result.assets[0].uri);
  }
};


  const handleCloseModal = () => {
  setModalVisible(false);

  const newActivity = {
    id: Date.now().toString(),
    date: date ? formatFullDate(date) : 'Unknown Date',
    title,
    type: activityType,
    description,
    photo, // 👈 add this
    status: 'Pending',
  };


  navigation.reset({
    index: 1,
    routes: [
      { name: 'MainApp' },
      { name: 'ALP_ActHis', params: { newActivity } },
    ],
  });
};


  return (
    <TouchableWithoutFeedback onPress={dismissKeyboardAndSuggestions}>
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.headerRow}>
          <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
            <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
            <Text style={styles.backText}>Log Activity</Text>
          </TouchableOpacity>
        </View>

        {/* ✅ Scrollable Content */}
        <ScrollView contentContainerStyle={styles.scrollContent}>

          <TextInput
            style={styles.input}
            placeholder="Title"
            value={title}
            onChangeText={setTitle}
          />

          {/* ✅ Activity Type Input */}
          <View style={{ marginBottom: 0 }}>
            <TextInput
              style={styles.input}
              placeholder="Type of Activity"
              value={activityType}
              onChangeText={handleActivityChange}
              onSubmitEditing={() => setShowSuggestions(false)}
              returnKeyType="done"
            />

            {/* 🔽 Suggestions Dropdown */}
            {showSuggestions && (
              <View style={styles.suggestionsBox}>
                {filteredOptions.length > 0 ? (
                  filteredOptions.map((item) => (
                    <TouchableOpacity
                      key={item.value}
                      style={styles.suggestionItem}
                      onPress={() => handleSelectActivity(item.label)}
                    >
                      <Text style={styles.suggestionText}>{item.label}</Text>
                    </TouchableOpacity>
                  ))
                ) : (
                  <TouchableOpacity
                    style={styles.suggestionItem}
                    onPress={() => handleSelectActivity(activityType)}
                  >
                    <Text style={[styles.suggestionText, { fontFamily: 'InterItalic', color: colors.l_gray }]}>
                      Add "{activityType}"
                    </Text>
                  </TouchableOpacity>
                )}
              </View>
            )}
          </View>

          {/* ✅ Date Input */}
          <TouchableOpacity style={styles.input} onPress={() => setShowDatePicker(true)}>
            <Text style={{
              fontFamily: 'InterRegular',
              fontSize: 13,
              letterSpacing: -.4,
              color: date ? colors.d_gray : colors.d_gray
            }}>
              {date ? formatFullDate(date) : 'Select Activity Date'}
            </Text>
          </TouchableOpacity>

          {showDatePicker && (
            <DateTimePicker
              value={pickerDate}
              mode="date"
              display="default"
              onChange={(event, selectedDate) => {
                if (event.type === 'set') {
                  setDate(selectedDate);
                  setPickerDate(selectedDate);
                }
                setShowDatePicker(false);
              }}
            />
          )}

          <TextInput
            style={[styles.input, styles.textarea]}
            placeholder="Share more about your activity"
            multiline
            value={description}
            onChangeText={setDescription}
          />

          {/* Photo Upload */}
          <TouchableOpacity style={styles.photoBox} onPress={openImageOptions}>
            {photo ? (
              <Image source={{ uri: photo }} style={styles.uploadedImage} />
            ) : (
              <>
                <Feather name="camera" size={28} color={colors.main} />
                <Text style={styles.tlphoto}>Upload or Take Photo</Text>
              </>
            )}
          </TouchableOpacity>


          {/* Submit Button */}
          <TouchableOpacity 
            style={styles.submit} 
            onPress={() => {
              if (!title.trim()) {
                Alert.alert('Missing Input', 'Please enter a Title.');
              } else if (!activityType.trim()) {
                Alert.alert('Missing Input', 'Please enter the Type of Activity.');
              } else if (!date) {
                Alert.alert('Missing Input', 'Please select an Activity Date.');
              } else if (!photo) {
                Alert.alert('Missing Input', 'Please upload or take a photo.');
              } else {
                setModalVisible(true); // ✅ All fields (including photo) are valid
              }
            }}
          >
            <Text style={styles.submit_text}>Submit</Text>
          </TouchableOpacity>


        </ScrollView>


         <Modal
        animationType="fade"
        transparent
        visible={modalVisible}
        onRequestClose={handleCloseModal}
        >
        <View style={modalStyles.blurContainer}>
            <BlurView intensity={100} tint="light" style={StyleSheet.absoluteFill} />
        </View>

        <View style={modalStyles.centeredView}>
            <View style={modalStyles.modalContainer}>
            <TouchableOpacity style={modalStyles.closeButton} onPress={handleCloseModal}>
                <AntDesign name="closecircle" size={26} color={colors.l_gray} />
            </TouchableOpacity>

            <Ionicons
                name="checkmark-circle-outline"
                size={90}
                color={colors.secondary}
                style={modalStyles.icon}
            />

            <Text style={modalStyles.title}>Activity Submitted</Text>
            <Text style={modalStyles.message}>
                Keep up the{"\n"}momentum.
            </Text>
            </View>
        </View>
        </Modal>


      </View>
    </TouchableWithoutFeedback>
  );
};

export default ALP_LogActivity;

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#fff' 
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    zIndex: 100,
  },
  backButton: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    marginTop: 30 
  },
  backText: { 
    fontSize: 19, 
    marginLeft: 8, 
    color: colors.secondary, 
    fontFamily: 'InterBold', 
    letterSpacing: -0.5 
  },

    scrollContent: {
    flexGrow: 1,
    paddingTop: 30,
    paddingBottom: 40,
    paddingHorizontal:20,
  },
  input: {
    backgroundColor: colors.inp,
    padding: 20,
    borderRadius: 10,
    fontFamily: 'InterRegular',
    fontSize: 13,
    letterSpacing: -.4,
    marginBottom: 15,
  },
  textarea: { height: 200, textAlignVertical: 'top' },

  suggestionsBox: {
    position: 'absolute',
    top: 55,
    left: 0,
    width: '100%',
    backgroundColor: colors.inp,
    borderWidth: 1,
    borderColor: colors.l_gray,
    borderRadius: 10,
    zIndex: 1000,
  },
  suggestionItem: { 
    padding: 12,
  },
  suggestionText: { 
    fontFamily: 'InterRegular', 
    fontSize: 13, 
    color: colors.d_gray,
    letterSpacing: -.4,
  },

  photoBox: {
    borderWidth: 1,
    borderColor: colors.l_gray,
    borderStyle: 'dashed',
    borderRadius: 8,
    height: 130,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 30,
  },
  uploadedImage: {
   width: '97%',
    height: 120,
    borderRadius: 8,
  },

  tlphoto: { 
    fontFamily: 'InterRegular', 
    fontSize: 13, 
    letterSpacing: -.4, 
    color: colors.l_gray,
  },

  submit: {
    backgroundColor: '#fff',
    padding: 9,
    borderRadius: 30,
    width: '53%',
    height: 42,
    alignSelf: 'center',
    shadowColor: colors.l_gray,
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    elevation: 5,
    marginBottom: 30,
  },
  submit_text: { 
    alignSelf: 'center', 
    fontSize: 16, 
    fontFamily: 'InterBold', 
    color: colors.d_gray, 
    letterSpacing: -.4 
  },
});

const modalStyles = StyleSheet.create({
  blurContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  centeredView: {
    flex: 1,
    justifyContent: 'flex-end', // Pushes content to the bottom
    alignItems: 'center',       // Keeps it horizontally centered
  },
  modalContainer: {
    width: width * 0.90,
    height: height * 0.50, // Set height to 50% of screen height
    backgroundColor: colors.inp, // Using colors.inp (#F0F0F0)
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
    paddingVertical: 40,
    paddingHorizontal: 25,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 8,
    elevation: 5,
  },
  closeButton: {
    position: 'absolute',
    top: 15,
    right: 15,
    zIndex: 10,
    backgroundColor: 'transparent',
    padding: 0,
    borderRadius: 0,
  },
  icon: {
    marginBottom: 5,
    marginTop: 60
  },
  title: {
    fontSize: 25,
    fontFamily: 'InterBold',
    letterSpacing: -1,
    color: colors.d_gray,
    textAlign: 'center',
    marginBottom: 10,
    marginTop: 5,
  },
  message: {
    fontSize: 16,
    fontFamily: 'InterRegular',
    letterSpacing: -.3,
    color: colors.d_gray,
    textAlign: 'center',
  },
});
