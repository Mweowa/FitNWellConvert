import React, { useState, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors } from '../util/colors';
import { Octicons } from '@expo/vector-icons';

const CodeVerification = () => {
  const navigation = useNavigation();
  const [otp, setOtp] = useState(['', '', '', '']);
  const inputs = useRef([]);

  const handleChange = (text, index) => {
    const newOtp = [...otp];
    newOtp[index] = text;
    setOtp(newOtp);

    if (text && index < 3) inputs.current[index + 1].focus();
    if (!text && index > 0) inputs.current[index - 1].focus();
  };

  const handleVerify = () => {
    const code = otp.join('');
    if (code === '1234') navigation.navigate('GetStart');
    else alert('Invalid code. Please try again.');
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView
          contentContainerStyle={{ flexGrow: 1 }}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.container}>
            <View style={styles.iconTitleContainer}>
              <Octicons name="verified" size={70} color={colors.secondary} style={styles.icon} />
              <Text style={styles.title}>Verify your{'\n'}account</Text>
            </View>

            <Text style={styles.subtitle}>Enter the 4-digit code sent to your email.</Text>

            {/* ✅ OTP Boxes */}
            <View style={styles.otpContainer}>
              {otp.map((digit, index) => (
                <TextInput
                  key={index}
                  ref={(ref) => (inputs.current[index] = ref)}
                  style={styles.otpBox}
                  keyboardType="numeric"
                  maxLength={1}
                  value={digit}
                  onChangeText={(text) => handleChange(text, index)}
                />
              ))}
            </View>

            <TouchableOpacity style={styles.button} onPress={handleVerify}>
              <Text style={styles.buttonText}>Verify</Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => alert('Code resent!')}>
              <Text style={styles.resend}>Resend Code</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

export default CodeVerification;

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    justifyContent: 'center', 
    alignItems: 'center', 
    padding: 20 
},
 iconTitleContainer: {
    alignItems: 'center',  
    marginBottom: 10,
  },
  icon: {
    marginBottom: 15,      
  },
  title: {
    fontFamily: 'InterBold',
    fontSize: 30,  
    color: colors.main, 
    textAlign: 'center', 
    letterSpacing: -1,
    marginBottom: 10,
  },
  subtitle: { fontSize: 14, fontFamily: 'InterRegular', color: colors.l_gray, marginBottom: 30, textAlign: 'center' }, subtitle: { 
    fontFamily: 'InterRegular',
    fontSize: 15, 
    color: colors.d_gray,
    textAlign: 'center',
    letterSpacing: -.5, 
    marginBottom: 30 
  },  

  otpContainer: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    width: '70%', 
    marginBottom: 30 
},
  otpBox: {
    width: 50,
    height: 55,
    backgroundColor: colors.inp, 
    borderRadius: 10,
    textAlign: 'center',
    fontSize: 20,
    fontFamily: 'InterBold',
    color: colors.d_gray,
  },

  button: { 
    marginTop: 15, 
    backgroundColor: '#fff',
    padding: 9, 
    borderRadius: 30, 
    width: '53%', 
    height: 42, 
    alignSelf: 'center', 
    shadowColor: colors.l_gray, 
    shadowOpacity: 0.1, 
    shadowOffset: { width: 0, height: 2 }, 
    elevation: 5,
},
  buttonText: { 
    alignSelf: 'center', 
    fontSize: 16, 
    fontFamily: 'InterBold', 
    color: colors.d_gray, 
    letterSpacing: -0.4,
},


  resend: { 
    color: colors.l_gray, 
    fontSize: 13, 
    marginTop: 15, 
    fontFamily: 'InterRegular',
    letterSpacing: -0.4
},
});
