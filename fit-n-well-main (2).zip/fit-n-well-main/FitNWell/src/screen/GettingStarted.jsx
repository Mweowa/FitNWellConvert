import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context'; 
import { useNavigation } from '@react-navigation/native';
import { colors } from '../util/colors';

const GettingStarted = () => {
  const navigation = useNavigation();
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}> 
      <View style={styles.container}>
        <Image 
          source={require('../assets/photos/backdrop.png')} 
          style={styles.backgroundImage} 
          resizeMode="cover" 
        />
        <View style={styles.overlay}>
          <Image 
            source={require('../assets/photos/fnw1.png')} 
            style={styles.logo} 
          />
          <Text style={styles.title}>FitNWell</Text>
          <TouchableOpacity 
            style={styles.button} 
            onPress={() => navigation.navigate('Sel_User')}
          >
            <Text style={styles.buttonText}>Get Started</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default GettingStarted;

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    position: 'relative', 
    backgroundColor: '#fff' 
  },
  backgroundImage: {
    position: 'absolute',
    width: 550,
    height: 750,
    top: '25%',
    alignSelf: 'center',
    zIndex: 0,
    opacity: 0.6,
  },
  overlay: { 
    flex: 1,
    alignItems: 'center', 
    justifyContent: 'center',
    zIndex: 1,
    width: '100%',
    height: '100%',
    paddingHorizontal: 20,
  },
  logo: { 
    width: 210, 
    height: 140, 
    marginBottom: 20 
  },
  title: { 
    fontSize: 40, 
    fontFamily: 'InterBoldItalic', 
    letterSpacing: -0.4,
    color: colors.d_gray,
    marginBottom: 50, 
  },
  button: {
    backgroundColor: '#fff', 
    padding: 9, 
    borderRadius: 30, 
    width: '53%',
    height: 42,
    shadowColor: colors.l_gray, 
    shadowOpacity: 0.1, 
    shadowOffset: { width: 0, height: 2 }, 
    elevation: 5,
    marginBottom: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonText: { 
    fontSize: 16,
    letterSpacing: -0.4,
    fontFamily: 'InterBold',
    color: colors.d_gray,
  },
});
