import { StyleSheet, Text, View, Image, FlatList, SafeAreaView, ScrollView, TouchableOpacity } from 'react-native';
import React from 'react';
import { useRoute } from '@react-navigation/native';
import AntDesign from '@expo/vector-icons/AntDesign';
import Ionicons from '@expo/vector-icons/Ionicons';
import { colors } from '../../util/colors';

const RecomPage = () => {
  const route = useRoute();
  const bmiCategory = route.params?.bmiCategory || 'Unknown';

  const recommendations = {
    Underweight: {
      focus: 'Builds cardiovascular fitness and tone without excessive calorie burn; supports muscle and overall strength.',
      activities: [
        { name: 'Yoga', description: 'Enhances flexibility and muscle tone.' },
        { name: 'Strength Training', description: 'Builds muscle and weight.' },
      ],
    },
    Healthy: {
      focus: 'Maintain fitness, improve endurance, and build balanced strength while avoiding overuse injuries.',
      activities: [
        { name: 'Jogging', description: 'Improves cardiovascular health.' },
        { name: 'Cycling', description: 'Boosts leg strength and stamina.' },
      ],
    },
    Overweight: {
      focus: 'Burn calories and improve cardiovascular health without high joint impact.',
      activities: [
        { name: 'Brisk Walking', description: 'Low impact cardio exercise.' },
        { name: 'Low Impact Cardio', description: 'Burns calories safely.' },
      ],
    },
    Obesity: {
      focus: 'Very low-impact options that are safe for joints, adaptable to mobility levels, and help build endurance progressively.',
      activities: [
        { name: 'Water Aerobics', description: 'Gentle on joints.' },
        { name: 'Chair Exercises', description: 'Accessible movement for all.' },
      ],
    },
  };

  const current = recommendations[bmiCategory] || {
    focus: 'general physical activity.',
    activities: [
      { name: 'Walking', description: 'Simple, everyday movement.' },
      { name: 'Jogging', description: 'Good for overall fitness.' },

    ],
  };

  return (
    <SafeAreaView style={styles.container}>
      <Image 
        source={require("../../assets/photos/backdrop.png")} 
        style={styles.backgroundImage} 
        resizeMode="cover" 
      />
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.contentWrapper}>
          <AntDesign name="like2" style={styles.playIcon} />
          <Text style={styles.heading}>
            <Text style={styles.headingBold}>Recommended{"\n"}</Text>
            <Text style={styles.headingHighlight}>Activity</Text>
          </Text>

          <View style={styles.i_divider} />

          <Text style={styles.bmiLabel}>Your BMI classification:</Text>
          <Text style={styles.bold}>{bmiCategory}</Text>
          
          <View style={styles.ii_divider} />

          <Text style={styles.focus}>Goal: </Text>
          <Text style={styles.bold}>{current.focus}</Text>
          
          <View style={styles.iii_divider} />

          <FlatList
          data={current.activities}
          keyExtractor={(item, index) => index.toString()}
          numColumns={2}
          columnWrapperStyle={styles.row}
          scrollEnabled={false}
          renderItem={({ item }) => (
            <TouchableOpacity 
              onPress={() => { 
                // navigation.navigate('YourTargetScreen', { activity: item }) 
              }} 
              style={styles.activityCard}
            >
              <Ionicons 
                name="sparkles-sharp" 
                size={35} 
                color={colors.secondary} 
                style={styles.activityIcon} 
              />
              <Text style={styles.activityTitle}>{item.name}</Text>
              <View style={styles.hortLine} />
              <Text style={styles.activityDesc}>{item.description}</Text>
            </TouchableOpacity>
          )}
        />

        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default RecomPage;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  scrollContent: {
    paddingBottom: 50,
  },
  backgroundImage: {
    position: 'absolute',
    width: 550,
    height: 750,
    top: '18%',
    alignSelf: 'center',
    zIndex: 0,
    opacity: .6,
  },
  contentWrapper: {
    flex: 1,
    padding: 20,
    paddingTop: 40,
  },
  playIcon: {
    fontSize: 50,
    color: colors.d_gray,
    marginBottom: 5,
  },
  heading: {
    fontSize: 40,
    fontFamily: 'InterBold',
    marginBottom: 10,
    letterSpacing: -1,
  },
  headingBold: {
    color: colors.d_gray,
  },
  headingHighlight: {
    color: colors.secondary,
  },
  i_divider: {
    height: 0.5,
    backgroundColor: colors.l_gray,
    marginVertical: 15,
  },
  bmiLabel: {
    fontFamily: 'InterItalic',
    fontSize: 16,
    letterSpacing: -0.5,
    color: colors.d_gray,
    marginTop: 10,
  },
  ii_divider: {
    height: 0.5,
    backgroundColor: colors.l_gray,
    marginVertical: 15,
  },
  focus: {
    fontFamily: 'InterItalic',
    fontSize: 16,
    letterSpacing: -0.5,
    color: colors.d_gray,
    marginTop: 10,
  },
  bold: {
    fontFamily: 'InterBold',
    fontSize: 16,
    letterSpacing: -0.5,
    color: colors.d_gray,
    marginBottom: 10,
  },
  iii_divider: {
    height: 0.5,
    backgroundColor: colors.l_gray,
    marginVertical: 15,
  },
  row: {
  justifyContent: 'space-between',
  marginBottom: 15, 
},
activityCard: {
  width: '48%', 
  backgroundColor: colors.inp,
  padding: 15,
  borderRadius: 10,
  marginTop: 5,
},
activityIcon: {
  marginTop: 10,
  marginBottom: -5,
},
activityTitle: {
  fontFamily: 'InterBold', 
  fontSize: 23, 
  letterSpacing: -.8,
  color: colors.d_gray, 
  marginTop: 10,
},
hortLine: { 
  width: 50, 
  height: 4, 
  backgroundColor: colors.secondary, 
  borderRadius: 30,
  marginTop: 8,
  marginBottom: 10,
},
activityDesc: {
  fontFamily: 'InterItalic',
  fontSize: 14,
  color: colors.d_gray,
  letterSpacing: -.5,
  marginTop: 5,
  marginBottom: 10,
},


});
