import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';  
import Feather from '@expo/vector-icons/Feather';
import AntDesign from '@expo/vector-icons/AntDesign';
import { colors } from '../util/colors';

const CreateAccount = () => {
  const navigation = useNavigation();
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isChecked, setIsChecked] = useState(false);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordRules, setPasswordRules] = useState({
    hasUppercase: false,
    hasNumber: false,
    hasSpecialChar: false,
    noSpaces: true,
    minLength: false,
  });

  const validatePassword = (text) => {
    setPassword(text);
    setPasswordRules({
      hasUppercase: /[A-Z]/.test(text),
      hasNumber: /\d/.test(text),
      hasSpecialChar: /[^A-Za-z0-9]/.test(text),
      noSpaces: !/\s/.test(text),
      minLength: text.length >= 8,
    });
  };

  const isPasswordValid = Object.values(passwordRules).every(Boolean);
  const doPasswordsMatch = password && confirmPassword && password === confirmPassword;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContainer}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.container}>
            
            {/* Header */}
            <View style={styles.headerRow}>
              <Image source={require('../assets/photos/fnw2.png')} style={styles.logo} />
              <View style={styles.textColumn}>
                <Text style={styles.header}>
                  <Text style={styles.gray}>Create an{'\n'}</Text>
                  <Text style={styles.green}>Account</Text>
                </Text>
              </View>
            </View>

            {/* Name Inputs */}
            <View style={styles.row}>
              <TextInput placeholder="First Name" style={[styles.input, { flex: 1, marginRight: 5 }]} />
              <TextInput placeholder="Last Name" style={[styles.input, { flex: 1, marginLeft: 5 }]} />
            </View>

            <TextInput placeholder="Email" style={styles.input} keyboardType="email-address" />

            {/* Password Input */}
            <View style={styles.passwordContainer}>
              <TextInput
                placeholder="Password"
                secureTextEntry={!showPassword}
                style={styles.passwordInput}
                value={password}
                onChangeText={validatePassword}
              />
              <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
                <Feather name={showPassword ? 'eye' : 'eye-off'} size={20} color={colors.l_gray} />
              </TouchableOpacity>
            </View>

            {/* Password Rules */}
            {password.length > 0 && (
              <View style={{ marginBottom: 10 }}>
                {[
                  { rule: 'At least 1 uppercase letter', valid: passwordRules.hasUppercase },
                  { rule: 'At least 1 number', valid: passwordRules.hasNumber },
                  { rule: 'At least 1 special character', valid: passwordRules.hasSpecialChar },
                  { rule: 'No spaces allowed', valid: passwordRules.noSpaces },
                  { rule: 'Minimum 8 characters', valid: passwordRules.minLength },
                ].map((item, index) => (
                  <View key={index} style={styles.ruleRow}>
                    <AntDesign
                      name={item.valid ? 'checkcircle' : 'closecircle'}
                      size={15}
                      color={item.valid ? colors.secondary : colors.l_gray}
                      style={{ marginRight: 6 }}
                    />
                    <Text style={[styles.rule, item.valid && styles.ruleValid]}>{item.rule}</Text>
                  </View>
                ))}
              </View>
            )}

            {/* Confirm Password */}
            <View style={styles.con_passwordContainer}>
              <TextInput
                placeholder="Confirm Password"
                secureTextEntry={!showConfirmPassword}
                style={styles.con_passwordInput}
                value={confirmPassword}
                onChangeText={setConfirmPassword}
              />
              <TouchableOpacity onPress={() => setShowConfirmPassword(!showConfirmPassword)}>
                <Feather name={showConfirmPassword ? 'eye' : 'eye-off'} size={20} color={colors.l_gray} />
              </TouchableOpacity>
            </View>

            {/* Confirm Password Error */}
            {confirmPassword.length > 0 && !doPasswordsMatch && (
              <Text style={{ color: colors.d_gray, fontFamily: 'InterItalic', letterSpacing: -0.4, fontSize: 12, marginBottom: 10, marginLeft: 5 }}>
                Passwords do not match
              </Text>
            )}

            {/* Terms Checkbox */}
            <TouchableOpacity style={styles.checkboxRow} onPress={() => setIsChecked(!isChecked)}>
              <View style={[styles.checkbox, isChecked && styles.checkedBox]}>
                {isChecked && <AntDesign name="check" size={14} color="#fff" />}
              </View>
              <Text style={styles.terms}>I agree to the Terms and Conditions</Text>
            </TouchableOpacity>

            {/* Sign Up Button */}
            <TouchableOpacity
              style={[styles.button, (!isPasswordValid || !doPasswordsMatch || !isChecked) && { opacity: 0.5 }]}
              disabled={!isPasswordValid || !doPasswordsMatch || !isChecked}
              onPress={() => navigation.navigate('CodeVeri')}
            >
              <Text style={styles.buttonText}>Sign up</Text>
            </TouchableOpacity>

            {/* Alternative Sign Up */}
            <Text style={styles.altSignUp}>or sign up with</Text>
            <TouchableOpacity style={styles.googleOnlyButton}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Image source={require('../assets/photos/ggle.png')} style={{ width: 18, height: 18, marginRight: 8 }} />
                <Text style={styles.buttonText}>Google</Text>
              </View>
            </TouchableOpacity>

            {/* Already have an account */}
            <Text style={styles.altText}>
              Already have an account?{' '}
              <Text style={styles.link} onPress={() => navigation.navigate('SignIn')}>
                Sign in
              </Text>
            </Text>

          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

export default CreateAccount;


const styles = StyleSheet.create({
  scrollContainer: { 
    flexGrow: 1, 
    paddingBottom: 20, 
    paddingTop: 20,
  },
  container: { 
    flex: 1, 
    padding: 20, 
    backgroundColor: '#fff' 
  },
  headerRow: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    marginBottom: 18 
  },
  logo: { 
    width: 90, 
    height: 90, 
    marginRight: 15 
  },
  textColumn: { 
    justifyContent: 'center' 
  },
  header: { 
    fontSize: 40, 
    fontFamily: 'Inter-Bold', 
    letterSpacing: -1 
  },
  gray: { 
    color: colors.d_gray 
  },
  green: { 
    color: colors.secondary,
  },
  input: { 
    backgroundColor: colors.inp, 
    padding: 20, 
    borderRadius: 10, 
    fontFamily: 'InterRegular', 
    fontSize: 13, 
    letterSpacing: -0.4,
    marginBottom: 15 
  },
  row: { 
    flexDirection: 'row' 
  },
  passwordContainer: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    backgroundColor: colors.inp, 
    borderRadius: 10, 
    paddingHorizontal: 15, 
    paddingVertical: 5, 
    marginBottom: 15 
  },
  passwordInput: { 
    flex: 1, 
    paddingVertical: 15, 
    fontFamily: 'InterRegular', 
    fontSize: 13, 
    letterSpacing: -0.4 
  },
  con_passwordContainer: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    backgroundColor: colors.inp, 
    borderRadius: 10, 
    paddingHorizontal: 15, 
    paddingVertical: 5, 
    marginBottom: 5 
  },
  con_passwordInput: { 
    flex: 1, 
    paddingVertical: 15, 
    fontFamily: 'InterRegular', 
    fontSize: 13, 
    letterSpacing: -0.4
  },

  ruleRow: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    marginBottom: 4 
  },
  rule: { 
    fontSize: 12, 
    color: colors.l_gray, 
    fontFamily: 'InterItalic',
    letterSpacing: -.3,
  },
  ruleValid: { 
    color: colors.secondary, 
  },

  checkboxRow: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    marginVertical: 10 
  },
  checkbox: { width: 17, height: 17, borderRadius: 5, borderWidth: 1, borderColor: colors.l_gray, marginRight: 10, justifyContent: 'center', alignItems: 'center' },
  checkedBox: { backgroundColor: colors.secondary, borderColor: colors.secondary },
  terms: { fontSize: 12, fontFamily: 'InterRegular', color: colors.l_gray, letterSpacing: -0.4 },
  
  button: { 
    marginTop: 15, 
    backgroundColor: '#fff',
    padding: 9, 
    borderRadius: 30, 
    width: '53%', 
    height: 42, 
    alignSelf: 'center', 
    shadowColor: colors.l_gray, 
    shadowOpacity: 0.1, 
    shadowOffset: { width: 0, height: 2 }, 
    elevation: 5 },
  buttonText: { 
    alignSelf: 'center', 
    fontSize: 16, 
    fontFamily: 'InterBold', 
    color: colors.d_gray, 
    letterSpacing: -0.4 },
    
  altSignUp: { textAlign: 'center', marginTop: 20, fontSize: 13, fontFamily: 'InterRegular', color: colors.l_gray, letterSpacing: -0.4 },
  googleOnlyButton: { alignSelf: 'center', backgroundColor: '#fff', marginTop: 5, borderRadius: 30, width: '53%', height: 42, justifyContent: 'center', alignItems: 'center', shadowColor: colors.l_gray, shadowOpacity: 0.1, shadowOffset: { width: 0, height: 2 }, elevation: 5, marginBottom: 25 },
  altText: { textAlign: 'center', marginTop: 1, fontSize: 13, fontFamily: 'InterRegular', color: colors.l_gray, letterSpacing: -0.4 },
  link: { fontSize: 13, fontFamily: 'InterBold', color: colors.main, letterSpacing: -0.4 },
});
