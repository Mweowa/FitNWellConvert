import React, { useState } from 'react';
import Feather from '@expo/vector-icons/Feather';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context'; 
import { colors } from '../util/colors';

const SignInPage = ({ navigation }) => {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}>
      <View style={styles.container}>
        <Image source={require('../assets/photos/fnw2.png')} style={styles.logo} />
        <Text style={styles.header}>Sign In</Text>
        <Text style={styles.subheader}>Welcome back! We’ve missed you.</Text>

        <TextInput placeholder="Email" style={styles.input} />

        <View style={styles.passwordContainer}>
          <TextInput
            placeholder="Password"
            secureTextEntry={!showPassword}
            style={styles.passwordInput}
          />
          <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
            <Feather name={showPassword ? 'eye' : 'eye-off'} size={20} color={colors.l_gray} />
          </TouchableOpacity>
        </View>

        <TouchableOpacity>
          <Text style={styles.forgot}>Forgot Password?</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('MainApp')}>
          <Text style={styles.buttonText}>Sign in</Text> 
        </TouchableOpacity>

        <Text style={styles.altSignIn}>or sign in with</Text>

        <TouchableOpacity style={styles.googleOnlyButton}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Image
              source={require('../assets/photos/ggle.png')}
              style={{ width: 18, height: 18, marginRight: 8 }}
            />
            <Text style={styles.buttonText}>Google</Text>
          </View>
        </TouchableOpacity>

        <Text style={styles.altText}>
          Don't have an account?{' '}
          <Text style={styles.link} onPress={() => navigation.navigate('CreateAcc')}>
            Sign up
          </Text>
        </Text>
      </View>
    </SafeAreaView>
  );
};

export default SignInPage;


const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    justifyContent: 'center', 
    padding: 20, 
    backgroundColor: '#fff',
  },
  logo: { 
    alignSelf: 'center', 
    width: 80, 
    height: 80,  
  },
  header: { 
    fontSize: 40, 
    fontFamily: 'Inter-Bold',
    letterSpacing: -1,
    color: colors.main, 
    textAlign: 'center' 
  },
  subheader: { 
    textAlign: 'center', 
    fontSize: 13, 
    fontFamily: 'InterRegular', 
    color: colors.d_gray, 
    letterSpacing: -.4,
    marginBottom: 40 
  },
  input: { 
    backgroundColor: colors.inp, 
    padding: 20, 
    borderRadius: 10,
    fontFamily: 'InterRegular',
    fontSize: 13,
    letterSpacing: -.4,
    marginBottom: 15,
  },
  passwordContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.inp,
    borderRadius: 10,
    paddingHorizontal: 15, 
    paddingVertical: 5,   
    marginBottom: 15,     
  },
  passwordInput: {
    flex: 1,
    paddingVertical: 15,
    fontFamily: 'InterRegular',
    fontSize: 13,
    letterSpacing: -.4,
  },
  forgot: { 
    textAlign: 'right', 
    fontSize: 12, 
    fontFamily: 'InterRegular', 
    color: colors.l_gray,
    letterSpacing: -.4,
    marginBottom: 15 
  },
  button: {
    backgroundColor: '#fff', 
    padding: 9, 
    borderRadius: 30, 
    width: "53%",
    height: 42,
    alignSelf: 'center',
    shadowColor: colors.l_gray, 
    shadowOpacity: 0.1, 
    shadowOffset: { width: 0, height: 2 }, 
    elevation: 5,
  },
  buttonText: { 
    alignSelf: 'center',
    fontSize: 16,
    fontFamily: 'InterBold',
    color: colors.d_gray,
    letterSpacing: -.4, 
  },
  altSignIn: { 
    textAlign: 'center',
    marginTop: 20,
    fontSize: 13,
    fontFamily: 'InterRegular',
    color: colors.l_gray, 
    letterSpacing: -.4,
  },
  googleOnlyButton: {
    alignSelf: 'center',
    backgroundColor: '#fff',
    marginTop: 5,
    borderRadius: 30, 
    width: "53%",
    height: 42,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: colors.l_gray, 
    shadowOpacity: 0.1, 
    shadowOffset: { width: 0, height: 2 }, 
    elevation: 5,
    marginBottom: 25,
  },
  googleOnlyLogo: {
    width: 70,
    height: 23,
    resizeMode: 'contain',
  },
  altText: { 
    textAlign: 'center',
    marginTop: 1,
    fontSize: 13,
    fontFamily: 'InterRegular',
    color: colors.l_gray,
    letterSpacing: -.4,
  },
  link: { 
    fontSize: 13,
    fontFamily: 'InterBold',
    color: colors.main,
    letterSpacing: -.4,
  },
});


