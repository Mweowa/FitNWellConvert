import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { colors } from '../../util/colors';
import MP_TabSwitch from '../../../components/MP_Appointments/MP_TabSwitch';
import MP_AppointCard from '../../../components/MP_Appointments/MP_AppointCard';
import MP_AppointDetailModal from '../../../components/MP_Appointments/MP_AppointDetailModal';
import MP_SelectDate from './MP_SelectDate';

const MP_Appointments = () => {
  const navigation = useNavigation();
  const route = useRoute();
  const [activeTab, setActiveTab] = useState('Awaiting');
  const [selectedActivity, setSelectedActivity] = useState(null);

  const [activities, setActivities] = useState([
    { 
      id: '1', 
      date: '2025-08-06', 
      timeLabel: 'Time:', 
      time: '9:30 AM', 
      place: 'CHK Bldg. Room 104',
      status: 'Pending' 
    },
    { 
      id: '2', 
      date: '2025-05-17', 
      timeLabel: 'Time:', 
      time: '6:00 PM - 6:30 PM', 
      place: 'CHK Bldg. Room 104',
      status: 'Approved' 
    },
    { 
      id: '3', 
      date: '2025-04-23', 
      timeLabel: 'Time:', 
      time: '7:30 PM - 8:00 PM', 
      place: 'CHK Bldg. Room 104',
      status: 'Completed' 
    },
    { 
      id: '4', 
      date: '2025-03-15', 
      timeLabel: 'Time:', 
      time: '10:00 AM - 10:30 AM', 
      place: 'CHK Bldg. Room 104',
      status: 'Missed' 
    },
  ]);

  // Handle new appointment from MP_SelectDate
  useEffect(() => {
    if (route.params?.appointmentDate && route.params?.appointmentTime) {
      const dateObj = new Date(route.params.appointmentDate);
      const year = dateObj.getFullYear();
      const month = String(dateObj.getMonth() + 1).padStart(2, '0');
      const day = String(dateObj.getDate()).padStart(2, '0');
      const formattedDate = `${year}-${month}-${day}`;
      
      const newAppointment = {
        id: Date.now().toString(), // Generate unique ID
        date: formattedDate, // Use properly formatted date
        timeLabel: 'Time:',
        time: route.params.appointmentTime,
        place: 'CHK Bldg. Room 104',
        status: 'Pending'
      };
      
      setActivities(prevActivities => [newAppointment, ...prevActivities]);
      
      // Clear the route params to prevent duplicate additions
      navigation.setParams({ appointmentDate: undefined, appointmentTime: undefined });
    }
  }, [route.params?.appointmentDate, route.params?.appointmentTime]);

  const filteredData = activities.filter(a =>
    activeTab === 'Awaiting'
      ? a.status === 'Pending'
      : a.status === 'Completed' || a.status === 'Approved' || a.status === 'Missed'
  );

  const handleConfirmPress = (activity) => {
    if (activity.status === 'Missed') {
      navigation.navigate('MP_SelectDate');
    }
    setSelectedActivity(null);
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.headerRow}>
              <TouchableOpacity
              style={styles.backButton}
              onPress={() => {
                navigation.reset({
                  index: 0,
                  routes: [
                    {
                      name: 'MainApp',
                      state: {
                        index: 0,
                        routes: [
                          {
                            name: 'MainTabs',
                            state: {
                              index: 0,
                              routes: [
                                {
                                  name: 'Home',
                                  state: {
                                    routes: [{ name: 'Appointment' }], // 👈 Make sure this matches your FeatStack route name
                                  },
                                },
                              ],
                            },
                          },
                        ],
                      },
                    },
                  ],
                });
              }}
            >
          <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
          <Text style={styles.backText}>Personal Appointments</Text>
        </TouchableOpacity>
      </View>

      {/* Tab Switch */}
      <MP_TabSwitch activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Activity List */}
      <FlatList
        data={filteredData}
        keyExtractor={item => item.id}
        renderItem={({ item }) => <MP_AppointCard {...item} onPress={() => setSelectedActivity(item)} />}
        contentContainerStyle={{ padding: 15 }}
      />
       {/* Modal */}
       <MP_AppointDetailModal
        visible={!!selectedActivity} 
        activity={selectedActivity} 
        onClose={() => setSelectedActivity(null)}
        onConfirm={handleConfirmPress}
            />
    </View>
  );
};

export default MP_Appointments;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 30,
  },
  backText: {
    fontSize: 19,
    marginLeft: 8,
    color: colors.secondary,
    fontFamily: 'InterBold',
    letterSpacing: -0.5,
  },
});