import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { useNavigation } from '@react-navigation/native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { colors } from '../../util/colors';
import { format, addMonths, subMonths } from 'date-fns';

import { Modal, Dimensions } from 'react-native';
import { BlurView } from 'expo-blur';
import AntDesign from '@expo/vector-icons/AntDesign';
import Ionicons from '@expo/vector-icons/Ionicons';

const { width, height } = Dimensions.get('window');


const MP_SelectDate = () => {
  const navigation = useNavigation();
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedHour, setSelectedHour] = useState(1);
  const [selectedMinute, setSelectedMinute] = useState('00');
  const [meridian, setMeridian] = useState('AM');

  const [modalVisible, setModalVisible] = useState(false);


  const [currentDate, setCurrentDate] = useState(() => {
    const now = new Date();
    return new Date(Math.max(now.getFullYear(), 2025), now.getMonth(), 1);
  });
  const [today] = useState(new Date());

  const timeInput = `${selectedHour}:${selectedMinute}`;

  const generateCalendarDays = (date) => {
    const firstDayOfMonth = new Date(date.getFullYear(), date.getMonth(), 1);
    const lastDayOfMonth = new Date(date.getFullYear(), date.getMonth() + 1, 0);
    const startDay = firstDayOfMonth.getDay();
    const days = [];

    const prevMonthLastDay = new Date(date.getFullYear(), date.getMonth(), 0).getDate();
    for (let i = startDay - 1; i >= 0; i--) days.push({ day: prevMonthLastDay - i, current: false, offset: -1 });
    for (let d = 1; d <= lastDayOfMonth.getDate(); d++) days.push({ day: d, current: true, offset: 0 });
    const remaining = 42 - days.length;
    for (let d = 1; d <= remaining; d++) days.push({ day: d, current: false, offset: 1 });

    return days;
  };

  const calendarDays = generateCalendarDays(currentDate);
  const weekDays = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

  const handleDateSelect = (item) => {
    let date = new Date(currentDate.getFullYear(), currentDate.getMonth() + item.offset, item.day);
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + item.offset, 1));
    setSelectedDate(date);
  };

  const handleNext = () => {
  if (selectedDate && timeInput) {
    setModalVisible(true); // Show the modal
  }
};

const handleCloseModal = () => {
  setModalVisible(false);

  navigation.reset({
    index: 1,
    routes: [
      { name: 'MainApp' },
      { 
        name: 'MP_Appointments',
        params: {
          appointmentDate: selectedDate.toISOString(),
          appointmentTime: `${timeInput} ${meridian}`
        }
      },
    ],
  });
};


  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
          <Text style={styles.backText}>Schedule Appointment</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.iconTitleRow}>
          <MaterialIcons name="schedule" size={35} color={colors.secondary} style={styles.icon} />
          <View>
            <Text style={styles.title}>Schedule</Text>
            <Text style={styles.title2}>Your Session</Text>
          </View>
        </View>

        <Text style={styles.subText}>Pick a date and time that works best for you.</Text>
        <View style={styles.i_divider} />

        <View style={styles.monthNavigation}>
          <TouchableOpacity style={styles.navButton} onPress={() => setCurrentDate(subMonths(currentDate, 1))}>
            <FontAwesome6 name="chevron-left" size={16} color={colors.l_gray} />
          </TouchableOpacity>
          <Text style={styles.monthText}>{format(currentDate, 'MMMM yyyy')}</Text>
          <TouchableOpacity style={styles.navButton} onPress={() => setCurrentDate(addMonths(currentDate, 1))}>
            <FontAwesome6 name="chevron-right" size={16} color={colors.l_gray} />
          </TouchableOpacity>
        </View>

        <View style={styles.calendar}>
          <View style={styles.weekHeader}>
            {weekDays.map((w) => <Text key={w} style={styles.weekDay}>{w}</Text>)}
          </View>
          <View style={styles.calendarGrid}>
            {calendarDays.map((item, idx) => {
              const isToday = today.toDateString() === new Date(currentDate.getFullYear(), currentDate.getMonth() + item.offset, item.day).toDateString();
              const isSelected = selectedDate && selectedDate.getDate() === item.day && item.current;
              return (
                <TouchableOpacity
                  key={idx}
                  style={[
                    styles.dayButton,
                    !item.current && styles.inactiveDay,
                    isToday && styles.currentDay,
                    isSelected && styles.selectedDay
                  ]}
                  onPress={() => handleDateSelect(item)}>
                  <Text style={[styles.dayText, isSelected && styles.selectedDayText]}>
                    {item.day}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
          <View style={styles.ii_divider} />
        </View>

        <View style={styles.row}>
          <View style={[styles.timeInputContainer, { flex: 1, marginRight: 5 }]}>
            <Picker
              selectedValue={selectedHour}
              style={styles.timePicker}
              onValueChange={(itemValue) => setSelectedHour(itemValue)}
            >
              {Array.from({ length: 12 }, (_, i) => i + 1).map((hour) => (
                <Picker.Item key={hour} label={`${hour}`} value={hour} />
              ))}
            </Picker>
          </View>

          <View style={[styles.timeInputContainer, { flex: 1, marginLeft: 5 }]}>
            <Picker
              selectedValue={selectedMinute}
              style={styles.timePicker}
              onValueChange={(itemValue) => setSelectedMinute(itemValue)}
            >
              {Array.from({ length: 60 }, (_, i) => i.toString().padStart(2, '0')).map((minute) => (
                <Picker.Item key={minute} label={minute} value={minute} />
              ))}
            </Picker>
          </View>
        </View>

        <View style={styles.timeInputContainer}>
          <Picker
            selectedValue={meridian}
            style={styles.timePicker}
            onValueChange={(itemValue) => setMeridian(itemValue)}
          >
            <Picker.Item label="AM" value="AM" />
            <Picker.Item label="PM" value="PM" />
          </Picker>
        </View>

           <View style={styles.iii_divider} />

        {selectedDate && (
          <View style={styles.selectedDateContainer}>
            <Text style={styles.selectedDateLabel}>DATE & TIME PICK:</Text>
            <Text style={styles.selectedDateText}>
              {format(selectedDate, 'EEEE | MMMM d, yyyy')} | {timeInput} {meridian}
            </Text>
          </View>
        )}

        <TouchableOpacity
          style={[styles.confirmButton, !selectedDate && { opacity: 0.5 }]}
          disabled={!selectedDate}
          onPress={handleNext}>
          <Text style={styles.confirmButtonText}>Confirm</Text>
        </TouchableOpacity>
      </ScrollView>



      <Modal
        animationType="slide"
        transparent
        visible={modalVisible}
        onRequestClose={handleCloseModal}
        >
        <View style={modalStyles.blurContainer}>
            <BlurView intensity={100} tint="light" style={StyleSheet.absoluteFill} />
        </View>

        <View style={modalStyles.centeredView}>
            <View style={modalStyles.modalContainer}>
            <TouchableOpacity style={modalStyles.closeButton} onPress={handleCloseModal}>
                <AntDesign name="closecircle" size={26} color={colors.l_gray} />
            </TouchableOpacity>

            <Ionicons
                name="checkmark-circle-outline"
                size={90}
                color={colors.secondary}
                style={modalStyles.icon}
            />

            <Text style={modalStyles.title}>Session Scheduled</Text>
            <Text style={modalStyles.message}>
                Please wait for the{"\n"}confirmation.
            </Text>
            </View>
        </View>
        </Modal>

    </View>
    
    
  );
};

export default MP_SelectDate;



const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#fff' 
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  backButton: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    marginTop: 30 
  },
  backText: { 
    fontSize: 19, 
    marginLeft: 8, 
    color: colors.secondary, 
    fontFamily: 'InterBold', 
    letterSpacing: -0.5 
  },
   scrollContent: { 
    paddingHorizontal: 20, 
    paddingTop: 30, 
    paddingBottom: 80 
  },
  iconTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4, 
  },
  icon: {
    marginRight: 10, 
  },
  title: { 
    fontSize: 22, 
    fontFamily: 'InterRegular', 
    letterSpacing: -.5,
    color: colors.d_gray, 
    marginBottom: -6,
  },
  title2: { 
    fontSize: 22, 
    fontFamily: 'InterBold', 
    letterSpacing: -.5,
    color: colors.d_gray, 
    marginBottom: 2
  },
  subText: { 
    fontSize: 15, 
    fontFamily: 'InterRegular',
    letterSpacing: -.3,
    color: colors.d_gray, 
    marginBottom: 15, 
    marginLeft: 48,
  },

  i_divider: {
    height: 0.2,
    backgroundColor: colors.l_gray,
    marginVertical: 15,
  },
  monthNavigation: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'center', 
    marginHorizontal: 30 
},
  navButton: { 
    padding: 10 
},

  monthText: { 
    fontSize: 17, 
    fontFamily: 'InterBold', 
    letterSpacing: -.5,
    color: colors.d_gray,
},
  calendar: { 
    marginTop: 20
},
  weekHeader: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    marginBottom: 10
},
  weekDay: { 
    width: '13%', 
    textAlign: 'center', 
    fontFamily: 'InterRegular', 
    color: colors.l_gray,
},
  calendarGrid: { 
    flexDirection: 'row', 
    flexWrap: 'wrap', 
    justifyContent: 'space-around', 
    marginBottom: -60 
},
  dayButton: { 
    width: '13%', 
    aspectRatio: 1, 
    justifyContent: 'center', 
    alignItems: 'center', 
    marginBottom: 5, 
    borderRadius: 4,
 },
  selectedDay: { 
    backgroundColor: colors.secondary,
    borderRadius: 30 
},
  inactiveDay: { 
    opacity: 0.4 
},
  currentDay: { 
    borderWidth: 1, 
    borderColor: colors.secondary, 
    borderRadius: 30 
},
  dayText: { 
    fontFamily: 'InterRegular', 
    color: colors.d_gray 
},

selectedDayText: { 
    color: '#fff', 
    fontFamily: 'InterBold' 
},

 ii_divider: {
    height: 0.2,
    backgroundColor: colors.l_gray,
    marginVertical: 15,
    marginBottom: 30,
  },
  

row: {
  flexDirection: 'row',
},

timeInputContainer: {
  backgroundColor: colors.inp,
  paddingHorizontal: 10,
  paddingVertical: 2,
  borderRadius: 10,
  marginBottom: 15,
},

timePicker: {
  height: 50,
  width: '100%',
  color: colors.d_gray,
  fontFamily: 'InterRegular',
  fontSize: 13,
  marginTop: -2, 
},

 iii_divider: {
    height: 0.2,
    backgroundColor: colors.l_gray,
    marginVertical: 15,
    marginBottom: 15,
  },

selectedDateContainer: { 
  marginTop: 15, 
  marginBottom: 35,
  alignItems: 'center'
},
selectedDateLabel: { 
  fontFamily: 'InterSemiBold', 
  color: colors.l_gray, 
  fontSize: 14 
},
selectedDateText: { 
  fontFamily: 'InterBold', 
  color: colors.main, 
  fontSize: 16,
  letterSpacing: -.3, 
  marginTop: 2 
},
  confirmButton: { 
    backgroundColor: '#fff',
    padding: 9,
    borderRadius: 30,
    width: '53%',
    height: 42,
    alignSelf: 'center',
    shadowColor: colors.l_gray,
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    elevation: 5,
},
  confirmButtonText: { 
    alignSelf: 'center',
    fontSize: 16,
    fontFamily: 'InterBold',
    color: colors.d_gray,
    letterSpacing: -.4,
},

});

const modalStyles = StyleSheet.create({
  blurContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  centeredView: {
    flex: 1,
    justifyContent: 'flex-end', // Pushes content to the bottom
    alignItems: 'center',       // Keeps it horizontally centered
  },
  modalContainer: {
    width: width * 0.90,
    height: height * 0.50, // Set height to 50% of screen height
    backgroundColor: colors.inp, // Using colors.inp (#F0F0F0)
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
    paddingVertical: 40,
    paddingHorizontal: 25,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 8,
    elevation: 5,
  },
  closeButton: {
    position: 'absolute',
    top: 15,
    right: 15,
    zIndex: 10,
    backgroundColor: 'transparent',
    padding: 0,
    borderRadius: 0,
  },
  icon: {
    marginBottom: 5,
    marginTop: 60
  },
  title: {
    fontSize: 25,
    fontFamily: 'InterBold',
    letterSpacing: -1,
    color: colors.d_gray,
    textAlign: 'center',
    marginBottom: 10,
    marginTop: 5,
  },
  message: {
    fontSize: 16,
    fontFamily: 'InterRegular',
    letterSpacing: -.3,
    color: colors.d_gray,
    textAlign: 'center',
  },
});