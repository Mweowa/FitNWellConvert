import React from 'react'
import { StyleSheet, Text, View,TouchableOpacity, } from 'react-native'
import { useNavigation } from '@react-navigation/native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { colors } from '../util/colors';

const VisitCHK = () => {
  const navigation = useNavigation();
  return (
    <View style={styles.container}>

      <View style={styles.iconTitleContainer}>
        <Ionicons name="sparkles-outline" size={70} color={colors.secondary} style={styles.icon} />
        <Text style={styles.title}>Your preference{'\n'}is set!</Text>
      </View>

      <Text style={styles.subtitle}>
        Please visit CHK to complete your anthropometric measurements.
      </Text>
        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('MainApp')}>
          <Text style={styles.buttonText}>Get Started</Text>
        </TouchableOpacity>
    </View>
  );
};

export default VisitCHK;

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#fff', 
    padding: 50, 
    justifyContent: 'center', 
    alignItems: 'center',  
  },
  iconTitleContainer: {
    alignItems: 'center',  
    marginBottom: 10,
  },
  icon: {
    marginBottom: 15,      
  },
  title: {
    fontFamily: 'InterBold',
    fontSize: 32,  
    color: colors.main, 
    textAlign: 'center', 
    letterSpacing: -1,
    marginBottom: 10,
  },
  subtitle: { 
    fontFamily: 'InterRegular',
    fontSize: 18, 
    color: colors.d_gray,
    textAlign: 'center',
    letterSpacing: -.5, 
    marginBottom: 30 
  },
  button: {
    backgroundColor: '#fff', 
    padding: 9, 
    borderRadius: 30, 
    width: '53%',
    height: 42,
    shadowColor: colors.l_gray, 
    shadowOpacity: 0.1, 
    shadowOffset: { width: 0, height: 2 }, 
    elevation: 5,
    marginBottom: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonText: { 
    fontSize: 16,
    letterSpacing: -0.4,
    fontFamily: 'InterBold',
    color: colors.d_gray,
  },
});
