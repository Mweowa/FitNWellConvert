import React, { useState, useMemo, useRef, useEffect } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, TextInput, ScrollView, Alert } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { colors } from '../util/colors';
import { AntDesign } from '@expo/vector-icons';

const InputAnthro = () => {
  const navigation = useNavigation();
  const route = useRoute();
  const scrollRef = useRef(null);
  const [editMode, setEditMode] = useState(false);
  const [showInfo, setShowInfo] = useState(false);


  const [data, setData] = useState({
    sex: '',
    height: '',
    weight: '',
    chest: '',
    waist: '',
    hip: '',
    upper: '',
    thigh: '',
    calf: '',
    triceps: '',
    abdomen: '',
    suprailiac: '',
    thighSkin: '',
  });

  // ✅ handle input changes
  const handleChange = (key, value) => {
    setData(prev => ({ ...prev, [key]: value }));
  };

  // ✅ Get updated measurement from MeasurementGuide
  useEffect(() => {
    if (route.params?.updatedKey) {
      setData(prev => ({
        ...prev,
        [route.params.updatedKey]: route.params.updatedValue
      }));
    }
  }, [route.params]);

  // ✅ Scroll to top on edit mode
  useEffect(() => {
    if (editMode && scrollRef.current) {
      scrollRef.current.scrollTo({ y: 0, animated: true });
    }
  }, [editMode]);

  // ✅ BMI Calculation
  const bmi = useMemo(() => {
    const h = parseFloat(data.height);
    const w = parseFloat(data.weight);
    if (!h || !w) return 0;
    return parseFloat((w / ((h / 100) ** 2)).toFixed(1));
  }, [data.height, data.weight]);

  const bmiCategories = [
    { label: 'Underweight', range: [0, 18.5] },
    { label: 'Healthy', range: [18.5, 24.9] },
    { label: 'Overweight', range: [25, 29.9] },
    { label: 'Obesity', range: [30, 100] },
  ];

  const currentBMICategory = bmiCategories.find(c => bmi >= c.range[0] && bmi <= c.range[1]);

  // ✅ WHR
  const whr = useMemo(() => {
    const waist = parseFloat(data.waist);
    const hip = parseFloat(data.hip);
    if (!waist || !hip) return '0.00';
    return (waist / hip).toFixed(2);
  }, [data.waist, data.hip]);

  const whrRisk = useMemo(() => {
    const ratio = parseFloat(whr);
    if (data.sex === 'Male') {
      if (ratio < 0.9) return { level: 'Low' };
      if (ratio <= 1.0) return { level: 'Moderate' };
      return { level: 'High' };
    } else {
      if (ratio < 0.8) return { level: 'Low' };
      if (ratio <= 0.85) return { level: 'Moderate' };
      return { level: 'High' };
    }
  }, [whr, data.sex]);

  const measurements = [
    { key: 'chest', label: 'Chest Circumference' },
    { key: 'upper', label: 'Upper Circumference' },
    { key: 'thigh', label: 'Thigh Circumference' },
    { key: 'calf', label: 'Calf Circumference' },
    { key: 'waist', label: 'Waist Circumference' },
    { key: 'hip', label: 'Hip Circumference' },
  ];

  const skinfolds = data.sex === 'Male'
    ? [
        { key: 'chest', label: 'Chest' },
        { key: 'abdomen', label: 'Abdomen' },
        { key: 'thighSkin', label: 'Thigh' },
      ]
    : [
        { key: 'triceps', label: 'Triceps' },
        { key: 'suprailiac', label: 'Suprailiac' },
        { key: 'thighSkin', label: 'Thigh' },
      ];

  // ✅ Save button with Height & Weight validation
  const handleSave = () => {
  if (!data.sex) {
    Alert.alert("Missing Field", "Please select your biological sex.");
    return;
  }

  if (!validateHeightAndWeight(data)) return;

  Alert.alert("Saved", "Measurements have been saved.", [
    {
      text: "OK",
      onPress: () =>
        navigation.navigate("InpComp", {
          bmiCategory: currentBMICategory.label,
        }),
    },
  ]);

  setEditMode(false);
};

const validateHeightAndWeight = (data) => {
  const height = parseFloat(data.height);
  const weight = parseFloat(data.weight);

  if (!data.height || !data.weight) {
    Alert.alert("Required Fields", "Height and Weight are required.");
    return false;
  }

  if (isNaN(height)) {
    Alert.alert("Invalid Height", "Height must be a number between 100 and 250 cm.");
    return false;
  }

  if (isNaN(weight)) {
    Alert.alert("Invalid Weight", "Weight must be a number between 30 and 300 kg.");
    return false;
  }

  if (height < 100 || height > 250) {
    Alert.alert("Invalid Height", "Please enter a height between 100 cm and 250 cm.");
    return false;
  }

  if (weight < 30 || weight > 300) {
    Alert.alert("Invalid Weight", "Please enter a weight between 30 kg and 300 kg.");
    return false;
  }


  const bmi = weight / ((height / 100) ** 2);

  if (bmi < 10 || bmi > 100) {
    Alert.alert(
      "BMI Out of Range",
      "The BMI calculated from height and weight seems unrealistic. Please double-check your inputs."
    );
    return false;
  }

  return true;
};

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.headerRow}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <FontAwesome6 name="circle-chevron-left" size={26} color={colors.l_gray} />
          <Text style={styles.backText}>Input Measurement</Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        ref={scrollRef}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Height & Weight */}
         <Text style={styles.sectionTitle}>Height and Weight</Text>
        <TouchableOpacity 
          onPress={() => setShowInfo(prev => !prev)} 
          style={styles.questionRow}
        >
          <AntDesign
            name={showInfo ? 'infocirlce' : 'infocirlceo'} 
            size={15} 
            color={colors.l_gray} 
            style={{ marginRight: 5 }} 
          />
          <Text style={styles.sub}>Kindly input your height and weight</Text>
        </TouchableOpacity>

       {showInfo && (
          <Text style={styles.sub1}>
          This information is required to calculate your Body Mass Index (BMI).
          </Text>
        )}
        <View style={styles.row}>
          {['height', 'weight'].map(key => (
            <View key={key} style={styles.metricBox}>
              <Text style={styles.metricLabel}>{key === 'height' ? 'Height' : 'Weight'}</Text>
              <View style={styles.hortLine} />
              <View style={styles.valueRow}>
                <TextInput
                    style={[styles.metricValue]}
                    value={data[key]}
                    placeholder={key === 'height' ? "000" : "00"}
                    placeholderTextColor={colors.l_gray} 
                    keyboardType="numeric"
                    onChangeText={t => handleChange(key, t)}
                />
                <Text style={styles.metricUnit}>{key === 'height' ? 'cm' : 'kg'}</Text>
              </View>
            </View>
          ))}
        </View>

        <View style={styles.i_divider} />

        {/* BMI */}
        <Text style={styles.sectionTitle}>Body Mass Index</Text>
        <View style={styles.bmiRow}>
          {bmiCategories.map(cat => {
            const isActive = currentBMICategory?.label === cat.label;
            return (
              <View key={cat.label} style={styles.bmiItem}>
                <View
                  style={[
                    styles.bmiCircle,
                    {
                      borderWidth: 3,
                      borderColor: isActive ? colors.main : colors.l_gray,
                      backgroundColor: isActive ? colors.secondary : 'transparent',
                    },
                  ]}
                />
                <Text style={[styles.bmiLabel, { color: isActive ? colors.main : colors.l_gray }]}>
                  {cat.label}
                </Text>
                <Text style={styles.bmiRange}>
                  {cat.range[0]} - {cat.range[1]}
                </Text>
              </View>
            );
          })}
        </View>

        <View style={styles.ii_divider} />
        <Text
          style={{
            fontSize: 14,
            color: currentBMICategory ? colors.main : colors.d_gray,
            alignSelf: 'center',
          }}
        >
          BMI: <Text style={{ fontWeight: 'bold' }}>{bmi}</Text>
        </Text>
        <View style={styles.iii_divider} />

        {/* Circumference Section */}
        <Text style={styles.sectionTitle}>Circumference Measurements</Text>
        <View style={styles.grid2}>
          {measurements.map(m => (
            <TouchableOpacity
              key={m.key}
              style={styles.card2}
              onPress={() =>
                navigation.navigate("Mea_Guide", {
                  measureKey: m.key,
                  label: m.label,
                  currentValue: data[m.key],
                  unit: "cm"
                })
              }
            >
              <Text style={styles.cardLabel}>{m.label}</Text>
              <View style={styles.hortLine} />
              <View style={styles.valueRow}>
                <Text style={styles.cardValue}>
                    {data[m.key] ? `${data[m.key]}` : "00"}
                </Text>
                <Text style={styles.cardUnit}>cm</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        {/* WHR */}
        <View style={[styles.fullWidthCard, { alignItems: 'center', borderWidth: 1, borderColor: colors.secondary }]}>
          <Text style={styles.cardLabel}>Waist-to-Hip Ratio</Text>
          <View style={styles.hortLine2} />
          <Text style={[styles.cardValue, { color: colors.secondary }]}>{whr}</Text>
          <View style={styles.hortLine3} />
          <Text style={{ fontSize: 13, color: colors.main }}>
            Risk: <Text style={{ fontWeight: 'bold' }}>{whrRisk.level}</Text>
          </Text>
        </View>

        <View style={styles.iv_divider} />

        {/* ✅ Skinfolds now clickable like Circumference */}
        <Text style={styles.sectionTitle}>Skinfold Measurements</Text>
        <TouchableOpacity 
          onPress={() => setShowInfo(prev => !prev)} 
          style={styles.questionRow}
        >
          <AntDesign
            name={showInfo ? 'infocirlce' : 'infocirlceo'} 
            size={15} 
            color={colors.l_gray} 
            style={{ marginRight: 5 }} 
          />
          <Text style={styles.sub}>Kindly select your biological sex?</Text>
        </TouchableOpacity>

       {showInfo && (
          <Text style={styles.sub1}>
            This information is only asked because the skinfold measurement sites differ between males and females. Selecting the correct sex ensures you're guided to measure the proper body areas.
          </Text>
        )}

        <View style={styles.sexToggleRow}>
          {['Male', 'Female'].map((option) => (
            <TouchableOpacity
              key={option}
              style={[
                styles.sexToggleButton,
                data.sex === option && styles.sexToggleSelected
              ]}
              onPress={() => handleChange('sex', option)}
            >
              <Text style={[
                styles.sexToggleText,
                data.sex === option && styles.sexToggleTextSelected
              ]}>
                {option}
              </Text>
            </TouchableOpacity>
          ))}
        </View>


        <View style={styles.grid3}>
          {skinfolds.map(s => (
            <TouchableOpacity
              key={s.key}
              style={styles.card3}
              onPress={() =>
                navigation.navigate("Mea_Guide", {
                  measureKey: s.key,
                  label: s.label,
                  currentValue: data[s.key],
                  unit: "mm"
                })
              }
            >
              <Text style={styles.cardLabel}>{s.label}</Text>
              <View style={styles.hortLine} />
              <View style={styles.valueRow}>
                <Text style={styles.cardValue}>
                {data[s.key] ? `${data[s.key]}` : "00"}
              </Text>
              <Text style={styles.cardUnit}>mm</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        {/* Save Button */}
        <TouchableOpacity 
          style={styles.actionBtn} 
          onPress={handleSave}
        >
          <Text style={styles.actionText}>Save Measurements</Text>
        </TouchableOpacity>

      </ScrollView>
    </View>
  );
};

export default InputAnthro;

const styles = StyleSheet.create({
container: { 
    flex: 1, 
    backgroundColor: '#fff' 
},
headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    minHeight: 110,
    backgroundColor: '#fff',
    elevation: 5,
    shadowColor: colors.l_gray,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
},
backButton: {
    flexDirection: 'row', 
    alignItems: 'center', 
    marginTop: 30 
},
backText: {
    fontSize: 19,
    marginLeft: 8,
    color: colors.secondary,
    fontFamily: 'InterBold',
    letterSpacing: -0.5
},


scrollContent: { 
    paddingHorizontal: 20, 
    paddingTop: 10, 
    paddingBottom: 100 
},
row: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    marginBottom: -5, 

},
metricBox: { 
    width: '48%', 
    height: '92%', 
    backgroundColor: colors.inp, 
    borderRadius: 15, 
    padding: 15 
},
metricLabel: { 
    fontFamily: 'InterRegular', 
    fontSize: 14, 
    letterSpacing: -.5, 
    color: colors.d_gray, 
    marginBottom: 4 
},
hortLine: { 
    width: 42, 
    height: 4, 
    backgroundColor: colors.secondary, 
    borderRadius: 30 
},
valueRow: { 
    flexDirection: 'row', 
    alignItems: 'baseline',
},
metricValue: { 
    fontSize: 25, 
    fontFamily: 'InterBold', 
    letterSpacing: -1,
    color: colors.d_gray, 
},
metricUnit: { 
    fontSize: 18, 
    marginLeft: 5, 
    letterSpacing: -.5, 
    fontFamily: 'InterBold', 
    color: colors.secondary 
},

i_divider: { 
    height: 0.2, 
    backgroundColor: colors.l_gray, 
    marginVertical: 15, 
    marginBottom: 5 
},

sectionTitle: {
    fontSize: 17,
    fontFamily: 'InterBold',
    letterSpacing: -.5,
    color: colors.d_gray,
    marginVertical: 10,
    alignSelf: 'center',
    marginBottom: 15
  },
bmiRow: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    marginBottom: 10 
},
bmiItem: { 
    alignItems: 'center', 
    width: '26%' 
},
bmiCircle: { 
    width: 20, 
    height: 20, 
    borderRadius: 50, 
    marginBottom: 5 
},
bmiLabel: { 
    fontSize: 13, 
    fontFamily: 'InterBold', 
    letterSpacing: -.5 
},
bmiRange: { 
    fontFamily: 'InterRegular', 
    fontSize: 11, 
    letterSpacing: -.3, 
    color: colors.l_gray 
},
ii_divider: { 
    height: 0.5, 
    backgroundColor: 
    colors.l_gray, 
    marginVertical: 15, 
    marginBottom: 10 
},
iii_divider: { 
    height: 0.3, 
    backgroundColor: colors.l_gray, 
    marginVertical: 15, 
    marginBottom: 5 
},

grid2: { 
    flexDirection: 'row', 
    flexWrap: 'wrap', 
    justifyContent: 'space-between' 
},
card2: { 
    width: '48%', 
    height: '28%', 
    backgroundColor: colors.inp, 
    borderRadius: 15, 
    padding: 15, 
    marginBottom: 15 
},
fullWidthCard: {
    width: '100%',
    height: 145,
    backgroundColor: colors.inp,
    borderRadius: 15,
    padding: 15,
    marginVertical: 15,
    marginTop: -8,
    marginBottom: 8,
    alignItems: 'center'
},
hortLine2: { 
    width: 51, 
    height: 4, 
    backgroundColor: colors.secondary, 
    borderRadius: 30, 
    marginTop: 10 },
hortLine3: { 
    width: 51, 
    height: 4, 
    backgroundColor: colors.secondary, 
    borderRadius: 30, 
    marginBottom: 10 
},


iv_divider: { 
    height: 0.3, 
    backgroundColor: colors.l_gray, 
    marginVertical: 15, 
    marginBottom: 5 
},


grid3: { 
    flexDirection: 'row', 
    flexWrap: 'wrap', 
    justifyContent: 'space-between' 
},
card3: { 
    width: '48%', 
    height: '43%', 
    backgroundColor: colors.inp, 
    borderRadius: 15, 
    padding: 15, 
    marginBottom: 15 
},

  sub: {
    fontSize: 14,
    fontFamily: 'InterBoldItalic',
    letterSpacing: -.5,
    color: colors.l_gray,
  },
  questionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  sub1: {
    fontSize: 14,
    fontFamily: 'InterItalic',
    letterSpacing: -.5,
    color: colors.l_gray,
    marginBottom: 10,
  },
  sexToggleRow: {
    flexDirection: 'row', 
    flexWrap: 'wrap', 
    justifyContent: 'space-between' ,
    marginBottom: 15,
  },
  sexToggleButton: {
    borderRadius: 15,
    width: '48%', 
    height: 60, 
    backgroundColor: colors.inp,
    borderWidth: 1,
    borderColor: colors.secondary,
    justifyContent: 'center',     
    alignItems: 'center',         
  },
  sexToggleSelected: {
    backgroundColor: colors.secondary,
  },
  sexToggleText: {
    color: colors.d_gray,
    fontFamily: 'InterBold',
  },
  sexToggleTextSelected: {
    color: '#fff',
  },

  
cardLabel: { 
    fontFamily: 'InterRegular', 
    fontSize: 13, 
    letterSpacing: -.5, 
    color: colors.d_gray, 
    marginBottom: 5 
},
cardValue: { 
    fontSize: 28, 
    fontFamily: 'InterBold', 
    letterSpacing: -1,
    color: colors.l_gray, 
},
cardUnit: { 
    fontSize: 17, 
    letterSpacing: -.5, 
    fontFamily: 'InterBold', 
    color: colors.secondary,
    marginLeft: 8,
},

actionBtn: {
    backgroundColor: '#fff',
    borderRadius: 30,
    paddingVertical: 10,
    paddingHorizontal: 30,
    alignSelf: 'center',
    elevation: 3,
    marginTop: 20
},
  actionText: { 
    fontFamily: 'InterBold', 
    color: colors.d_gray, 
    fontSize: 16 
},
});
