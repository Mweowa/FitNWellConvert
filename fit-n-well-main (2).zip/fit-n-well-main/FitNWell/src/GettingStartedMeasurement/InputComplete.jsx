import React from 'react'
import { StyleSheet, Text, View,TouchableOpacity, } from 'react-native'
import { useNavigation, useRoute } from '@react-navigation/native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { colors } from '../util/colors';

const InputComplete= () => {
  const navigation = useNavigation();

  const route = useRoute();
  const bmiCategory = route.params?.bmiCategory || "Unknown";


  return (
    <View style={styles.container}>
      <View style={styles.i_divider} />

      <View style={styles.iconTitleContainer}>
        <Ionicons name="sparkles-outline" size={70} color={colors.secondary} style={styles.icon} />
        <Text style={styles.title}>You're all set!</Text>
      </View>

      <Text style={styles.subtitle}>
        Great job! Your anthropometric measurements have been saved successfully. You're all set to use the application.
      </Text>
        <TouchableOpacity style={styles.button} onPress={() => {
            navigation.reset({
              index: 0,
              routes: [
                {
                  name: 'MainApp',
                  state: {
                    index: 0,
                    routes: [
                      {
                        name: 'MainTabs',
                        state: {
                          index: 0,
                          routes: [
                            {
                              name: 'Home',
                              state: {
                                routes: [
                                  {
                                    name: 'Recommended',
                                    params: { bmiCategory },
                                  },
                                ],
                              },
                            },
                          ],
                        },
                      },
                    ],
                  },
                },
              ],
            });
          }}
          >
          <Text style={styles.buttonText}>Get Started</Text>
        </TouchableOpacity>
    </View>
  );
};

export default InputComplete;

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#fff', 
    padding: 50, 
    justifyContent: 'center', 
    alignItems: 'center',  
  },
  iconTitleContainer: {
    alignItems: 'center',  
    marginBottom: 10,
  },
  icon: {
    marginBottom: 15,      
  },
  title: {
    fontFamily: 'InterBold',
    fontSize: 32,  
    color: colors.main, 
    textAlign: 'center', 
    letterSpacing: -1,
    marginBottom: 10,
  },
  subtitle: { 
    fontFamily: 'InterRegular',
    fontSize: 18, 
    color: colors.d_gray,
    textAlign: 'center',
    letterSpacing: -.5, 
    marginBottom: 30 
  },
  button: {
    backgroundColor: '#fff', 
    padding: 9, 
    borderRadius: 30, 
    width: '53%',
    height: 42,
    shadowColor: colors.l_gray, 
    shadowOpacity: 0.1, 
    shadowOffset: { width: 0, height: 2 }, 
    elevation: 5,
    marginBottom: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonText: { 
    fontSize: 16,
    letterSpacing: -0.4,
    fontFamily: 'InterBold',
    color: colors.d_gray,
  },
});
