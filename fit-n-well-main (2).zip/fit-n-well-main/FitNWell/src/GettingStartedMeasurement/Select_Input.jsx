import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, SafeAreaView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { colors } from '../util/colors';

const Select_Input = () => {
  const navigation = useNavigation();

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <View style={styles.beforeContainer}>
          <Text style={styles.beforeText}>But before anything else...</Text>
        </View>

        <View style={styles.ii_divider} />

        <Text style={styles.title}>How would you like to provide your measurements?</Text>
        <Text style={styles.subtitle}>
          You can either input them yourself or visit the College of Human Kinetics (CHK) for assistance.
        </Text>

        <View style={styles.optionContainer}>
          {/* Input Option */}
          <TouchableOpacity style={styles.optionBox} onPress={() => navigation.navigate('Inp_Anthro')}>
            <FontAwesome6 name="ruler" size={35} color={colors.secondary} />
            <Text style={styles.optionTitle}>Input</Text>
            <Text style={styles.optionTitle2}>Manually</Text>
            <View style={styles.hortLine} />
            <Text style={styles.optionText}>
              I'll enter my measurements with the help of a quick guide.
            </Text>
          </TouchableOpacity>

          {/* Visit Option */}
          <TouchableOpacity style={styles.optionBox} onPress={() => navigation.navigate('Visit_CHK')}>
            <FontAwesome6 name="person-running" size={35} color={colors.secondary} />
            <Text style={styles.optionTitle}>Visit</Text>
            <Text style={styles.optionTitle2}>CHK</Text>
            <View style={styles.hortLine} />
            <Text style={styles.optionText}>
              I prefer to go to CHK to have my measurements taken.
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default Select_Input;

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#fff',
  },
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  beforeContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },
  beforeText: {
    fontSize: 14,
    color: colors.l_gray,
    fontFamily: 'InterItalic',
    letterSpacing: -0.5,
    textAlign: 'center',
  },
  ii_divider: {
    height: 0.4,
    backgroundColor: colors.l_gray,
    marginVertical: 20,
  },
  title: {
    fontFamily: 'InterBold',
    fontSize: 30,
    color: colors.d_gray,
    letterSpacing: -1,
    marginBottom: 10,
  },
  subtitle: {
    fontFamily: 'InterItalic',
    fontSize: 18,
    color: colors.d_gray,
    letterSpacing: -0.5,
    marginBottom: 30,
  },
  optionContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  optionBox: {
    width: '48%',
    backgroundColor: colors.inp,
    borderRadius: 10,
    padding: 15,
  },
  optionTitle: {
    fontFamily: 'InterBold',
    fontSize: 24,
    letterSpacing: -0.8,
    color: colors.d_gray,
    marginTop: 10,
  },
  optionTitle2: {
    fontFamily: 'InterBold',
    fontSize: 24,
    letterSpacing: -0.8,
    color: colors.secondary,
    marginTop: -10,
  },
  hortLine: {
    width: 50,
    height: 4,
    backgroundColor: colors.secondary,
    borderRadius: 30,
    marginTop: 3,
  },
  optionText: {
    fontFamily: 'InterItalic',
    fontSize: 14,
    color: colors.d_gray,
    letterSpacing: -0.5,
    marginTop: 20,
    marginBottom: 10,
  },
});
