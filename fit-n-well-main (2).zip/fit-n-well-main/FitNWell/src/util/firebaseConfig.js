// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore"; 
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAAKaoN7DN4VYyF5nqFcFKkPDTmX1v2oXo",
  authDomain: "fitnwell-40c00.firebaseapp.com",
  projectId: "fitnwell-40c00",
  storageBucket: "fitnwell-40c00.firebasestorage.app",
  messagingSenderId: "548110521797",
  appId: "1:548110521797:web:396e9bb33dec850d9367ac",
  measurementId: "G-5EGY3KNEXN"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Export Firebase services
export const auth = getAuth(app);
export const db = getFirestore(app);