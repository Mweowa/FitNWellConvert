import React, { useState } from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  TouchableOpacity, 
  Image, 
  ScrollView, 
  SafeAreaView, 
  Alert 
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { colors } from '../util/colors';
import { FontAwesome6 } from '@expo/vector-icons';

const SelectPosition = () => {
  const [selectedPosition, setSelectedPosition] = useState(null);
  const navigation = useNavigation();
  const route = useRoute();
  const { userType } = route.params;

  const academicPositions = [
    { position: 'College Dean' },
    { position: 'Chairperson' },
    { position: 'Professor' },
    { position: 'Assistant Professor' },
  ];

  const nonAcademicPositions = [
    { position: 'Human Resource' },
    { position: 'Administrative Aide' },
    { position: 'Registrar Personnel' },
    { position: 'Staff', description: 'Facility Management Office (FAMO)' },
  ];

  const positions = userType === 'academic' ? academicPositions : nonAcademicPositions;

  const handleNext = () => {
    if (!selectedPosition) {
      Alert.alert("Selection Required", "Please select a position.");
      return;
    }

    if (userType === 'academic') {
      navigation.navigate('Sel_Dep', { userType, selectedPosition });
    } else {
      navigation.navigate('Loading', { userType, selectedPosition });
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        
        {/* Header */}
        <View style={styles.headerRow}>
          <Image source={require('../assets/photos/fnw2.png')} style={styles.logo} />
          <View style={styles.textColumn}>
            <Text style={styles.header}>
              <Text style={styles.gray}>Select{'\n'}</Text>
              <Text style={styles.green}>Position</Text>
            </Text>
          </View>
        </View>

        <ScrollView style={styles.scrollArea} contentContainerStyle={styles.scrollContent}>
          {positions.map((posObj) => {
            const isSelected = selectedPosition === posObj.position;
            return (
              <TouchableOpacity 
                key={posObj.position} 
                style={[styles.card, isSelected && styles.selectedCard]}
                onPress={() => setSelectedPosition(posObj.position)}
              >
                <View style={styles.cardRow}>
                  <FontAwesome6 name="person" size={35} color={colors.secondary} style={{ marginRight: 15 }} />
                  <View style={styles.textColumnInsideCard}>
                    <Text style={styles.optionTitle}>{posObj.position}</Text>
                    {posObj.description && (
                      <Text style={styles.optionDescription}>{posObj.description}</Text>
                    )}
                  </View>
                </View>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        <View style={styles.bottomShadowWrapper}>
          <TouchableOpacity style={styles.button} onPress={handleNext}>
            <Text style={styles.buttonText}>Next</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default SelectPosition;

const styles = StyleSheet.create({
  safeArea: { 
    flex: 1, 
    backgroundColor: '#fff' 
  },
  container: { 
    flex: 1, 
    backgroundColor: '#fff'
  },

  // Header
  headerRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 15,
    paddingTop: 100,
    paddingBottom: 24,
    backgroundColor: '#fff',
    elevation: 3,
    zIndex: 1,
  },
  logo: {
    width: 90,
    height: 90,
    marginRight: 15,
    marginBottom: 7,
  },
  textColumn: {
    justifyContent: 'center',
  },
  header: {
    fontSize: 40,
    fontFamily: 'InterBold',
    letterSpacing: -1,
  },
  gray: {
    color: colors.d_gray,
  },
  green: {
    color: colors.secondary,
  },

  scrollArea: { 
    flex: 1 
  },
  scrollContent: { 
    padding: 20 
  },
  card: {
    backgroundColor: colors.inp,
    padding: 20,
    borderRadius: 10,
    marginBottom: 15,
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
    width: '100%',
    height: 90, 
    alignSelf: 'center',
  },
  selectedCard: {
    borderColor: colors.secondary,
  },
  cardRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  textColumnInsideCard: {
    flex: 1,
    flexShrink: 1,
  },
  optionTitle: {
    fontFamily: 'InterBold',
    fontSize: 20,
    letterSpacing: -0.8,
    color: colors.l_gray,
    flexWrap: 'wrap',
  },
  optionDescription: {
    fontFamily: 'InterItalic',
    fontSize: 13,
    letterSpacing: -0.5,
    color: colors.l_gray,
    marginTop: -3,
    flexWrap: 'wrap',
  },
  bottomShadowWrapper: {
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -3 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
    paddingHorizontal: 20,
    paddingBottom: 80,
    paddingTop: 20,
  },
  button: { 
    backgroundColor: '#fff',
    padding: 9, 
    borderRadius: 30, 
    width: '53%', 
    height: 42, 
    alignSelf: 'center', 
    shadowColor: colors.l_gray, 
    shadowOpacity: 0.1, 
    shadowOffset: { width: 0, height: 2 }, 
    elevation: 5 
  },
  buttonText: { 
    alignSelf: 'center', 
    fontSize: 16, 
    fontFamily: 'InterBold', 
    color: colors.d_gray, 
    letterSpacing: -0.4 
  },
});
