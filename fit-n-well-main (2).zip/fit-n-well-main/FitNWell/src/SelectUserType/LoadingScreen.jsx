import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  SafeAreaView,
  Animated,
  Image,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { colors } from '../util/colors';

const LoadingScreen = () => {
  const navigation = useNavigation();
  const [messageIndex, setMessageIndex] = useState(0);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const messages = [
    "This won't take long.",
    "Are you ready to get fit?",
  ];

  const fadeIn = () => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start(() => {
      setTimeout(() => fadeOut(), 1500); // hold message for 1.5s
    });
  };

  const fadeOut = () => {
    Animated.timing(fadeAnim, {
      toValue: 0,
      duration: 500,
      useNativeDriver: true,
    }).start(() => {
      setMessageIndex((prev) => (prev + 1) % messages.length);
    });
  };

  useEffect(() => {
    const interval = setInterval(() => {
      fadeIn();
    }, 3000); // rotate messages every 3s

    const navTimer = setTimeout(() => {
      clearInterval(interval);
      navigation.replace('SelectInput');
    }, 10000); // navigate after 10 seconds

    fadeIn(); // start first animation

    return () => {
      clearInterval(interval);
      clearTimeout(navTimer);
    };
  }, []);

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {/* Background Image */}
        <Image
          source={require('../assets/photos/backdrop.png')}
          style={styles.backgroundImage}
          resizeMode="cover"
        />

        {/* Foreground content */}
        <ActivityIndicator size="large" color={colors.secondary} />
        <Text style={styles.mainText}>
          Fueling your{"\n"}journey...
        </Text>
        <Animated.Text style={[styles.subText, { opacity: fadeAnim }]}>
          {messages[messageIndex]}
        </Animated.Text>
      </View>
    </SafeAreaView>
  );
};

export default LoadingScreen;

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#fff',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backgroundImage: {
    position: 'absolute',
    width: 550,
    height: 750,
    top: '25%',
    alignSelf: 'center',
    zIndex: 0,
    opacity: 0.6,
  },
  mainText: {
    fontFamily: 'InterBold',
    fontSize: 32,
    color: colors.main,
    textAlign: 'center',
    letterSpacing: -1,
    marginBottom: 10,
    zIndex: 1,
  },
  subText: {
    fontFamily: 'InterRegular',
    fontSize: 18,
    color: colors.d_gray,
    textAlign: 'center',
    letterSpacing: -0.5,
    marginBottom: 30,
    zIndex: 1,
  },
});
