import React, { useState } from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  TouchableOpacity, 
  Image, 
  ScrollView, 
  SafeAreaView, 
  Alert 
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { colors } from '../util/colors';
import { Ionicons } from '@expo/vector-icons';

const SelectDepartment = () => {
  const [selectedDept, setSelectedDept] = useState(null);
  const navigation = useNavigation();
  const route = useRoute();
  const { selectedPosition } = route.params;

  const departments = [
    { college: 'COA', full: 'College of Accountancy' },
    { college: 'CBA', full: 'College of Business Administration' },
    { college: 'COC', full: 'College of Communication' },
    { college: 'COOP', full: 'College of Cooperatives' },
    { college: 'CCMIT', full: 'College of Computer Management and Information Technology' },
    { college: 'CCIS', full: 'College of Computer and Information Sciences' },
    { college: 'COED', full: 'College of Education' },
    { college: 'CE', full: 'College of Engineering' },
    { college: 'CHK', full: 'College of Human Kinetics' },
    { college: 'CLL', full: 'College of Languages and Linguistics' },
    { college: 'LAW', full: 'College of Law' },
    { college: 'CNFS', full: 'College of Nutrition and Food Science' },
    { college: 'CS', full: 'College of Science' },
    { college: 'CT', full: 'College of Technology' },
    { college: 'CTHRM', full: 'College of Tourism, Hotel, and Restaurant Management' },
    { college: 'GS', full: 'Graduate School' },
  ];

  const handleNext = () => {
    if (!selectedDept) {
      Alert.alert("Selection Required", "Please select a department.");
      return;
    }

    navigation.navigate('Loading', { selectedPosition, selectedDept });
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        
        {/* Header */}
        <View style={styles.headerRow}>
          <Image source={require('../assets/photos/fnw2.png')} style={styles.logo} />
          <View style={styles.textColumn}>
            <Text style={styles.header}>
              <Text style={styles.gray}>Select{'\n'}</Text>
              <Text style={styles.green}>Department</Text>
            </Text>
          </View>
        </View>

        <ScrollView style={styles.scrollArea} contentContainerStyle={styles.scrollContent}>
          {departments.map((dept) => (
            <TouchableOpacity 
              key={dept.college} 
              style={[styles.card, selectedDept?.college === dept.college && styles.selectedCard]}
              onPress={() => setSelectedDept(dept)}
            >
              <View style={styles.cardRow}>
                <Ionicons name="business" size={35} color={colors.secondary} style={{ marginRight: 15 }} />
                <View style={styles.textColumnInsideCard}>
                  <Text style={styles.optionTitle}>{dept.college}</Text>
                  <Text style={styles.optionDescription}>{dept.full}</Text>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <View style={styles.bottomShadowWrapper}>
          <TouchableOpacity style={styles.button} onPress={handleNext}>
            <Text style={styles.buttonText}>Next</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default SelectDepartment;

const styles = StyleSheet.create({
  safeArea: { 
    flex: 1, 
    backgroundColor: '#fff' 
  },
  container: { 
    flex: 1, 
    backgroundColor: '#fff' 
  },

  // Header
  headerRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 15,
    paddingTop: 100,
    paddingBottom: 24,
    backgroundColor: '#fff',
    elevation: 3,
    zIndex: 1,
  },
  logo: {
    width: 90,
    height: 90,
    marginRight: 15,
    marginBottom: 7,
  },
  textColumn: {
    justifyContent: 'center',
  },
  header: {
    fontSize: 40,
    fontFamily: 'InterBold',
    letterSpacing: -1,
  },
  gray: {
    color: colors.d_gray,
  },
  green: {
    color: colors.secondary,
  },

  scrollArea: { 
    flex: 1 
  },
  scrollContent: { 
    padding: 20 
  },
  card: {
    backgroundColor: colors.inp,
    padding: 20,
    borderRadius: 10,
    marginBottom: 15,
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
    width: '100%',
    height: 90, 
    alignSelf: 'center',
  },
  selectedCard: {
    borderColor: colors.secondary,
  },
  cardRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  textColumnInsideCard: {
    flex: 1,
    flexShrink: 1,
  },
  optionTitle: {
    fontFamily: 'InterBold',
    fontSize: 22,
    letterSpacing: -0.8,
    color: colors.l_gray,
    flexWrap: 'wrap',
  },
  optionDescription: {
    fontFamily: 'InterItalic',
    fontSize: 13,
    letterSpacing: -0.5,
    color: colors.l_gray,
    marginTop: -3,
    flexWrap: 'wrap',
  },
  bottomShadowWrapper: {
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -3 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
    paddingHorizontal: 20,
    paddingBottom: 80,
    paddingTop: 20,
  },
  button: { 
    backgroundColor: '#fff',
    padding: 9, 
    borderRadius: 30, 
    width: '53%', 
    height: 42, 
    alignSelf: 'center', 
    shadowColor: colors.l_gray, 
    shadowOpacity: 0.1, 
    shadowOffset: { width: 0, height: 2 }, 
    elevation: 5 
  },
  buttonText: { 
    alignSelf: 'center', 
    fontSize: 16, 
    fontFamily: 'InterBold', 
    color: colors.d_gray, 
    letterSpacing: -0.4 
  },
});
