import React, { useState } from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  TouchableOpacity, 
  Image, 
  ScrollView, 
  SafeAreaView, 
  Alert 
} from 'react-native';
import { colors } from '../util/colors';
import { FontAwesome6, Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

const SelectUser = () => {
  const [selectedType, setSelectedType] = useState(null);
  const navigation = useNavigation();

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        
        {/* Header */}
        <View style={styles.headerRow}>
          <Image source={require('../assets/photos/fnw2.png')} style={styles.logo} />
          <View style={styles.textColumn}>
            <Text style={styles.header}>
              <Text style={styles.gray}>Select{'\n'}</Text>
              <Text style={styles.green}>User Type</Text>
            </Text>
          </View>
        </View>

        {/* Scrollable Cards */}
        <ScrollView
          style={styles.scrollArea}
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Academic Card */}
          <TouchableOpacity 
            style={[styles.card, selectedType === 'academic' && styles.selectedCard]} 
            onPress={() => setSelectedType('academic')}
          >
            <View style={styles.cardRow}>
              <FontAwesome6
                name="book-bookmark" 
                size={40} 
                color={colors.secondary} 
                style={{ marginBottom: 23, marginRight: 15 }}   
              />
              <View style={styles.textColumnInsideCard}>
                <Text style={styles.optionTitle}>Academic</Text>
                <Text style={styles.optionTitle2}>Staff</Text>
                <Text style={styles.optionText}>Info here.</Text>
              </View>
            </View>
          </TouchableOpacity>

          {/* Non-Academic Card */}
          <TouchableOpacity 
            style={[styles.card, selectedType === 'non-academic' && styles.selectedCard]} 
            onPress={() => setSelectedType('non-academic')}
          >
            <View style={styles.cardRow}>
              <Ionicons
                name="settings-sharp" 
                size={40} 
                color={colors.secondary} 
                style={{ marginBottom: 23, marginRight: 10 }}   
              />
              <View style={styles.textColumnInsideCard}>
                <Text style={styles.optionTitle}>Non-Academic</Text>
                <Text style={styles.optionTitle2}>Staff</Text>
                <Text style={styles.optionText}>Info here.</Text>
              </View>
            </View>
          </TouchableOpacity>
        </ScrollView>

        {/* Bottom Button */}
        <View style={styles.bottomShadowWrapper}>
          <TouchableOpacity 
            style={styles.button} 
            onPress={() => {
              if (selectedType === 'academic') {
                navigation.navigate('Sel_Pos', { userType: 'academic' });
              } else if (selectedType === 'non-academic') {
                navigation.navigate('Sel_Pos', { userType: 'non-academic' });
              } else {
                Alert.alert("Selection Required", "Please select a user type.");
              }
            }}
          >
            <Text style={styles.buttonText}>Next</Text>
          </TouchableOpacity>
        </View>

      </View>
    </SafeAreaView>
  );
};

export default SelectUser;

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#fff',
  },
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },

  // Header
  headerRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 15,
    paddingTop: 100,
    paddingBottom: 24,
    backgroundColor: '#fff',
    elevation: 3,
    zIndex: 1,
  },
  logo: {
    width: 90,
    height: 90,
    marginRight: 15,
    marginBottom: 7,
  },
  textColumn: {
    justifyContent: 'center',
  },
  header: {
    fontSize: 40,
    fontFamily: 'InterBold',
    letterSpacing: -1,
  },
  gray: {
    color: colors.d_gray,
  },
  green: {
    color: colors.secondary,
  },

  // Scrollable Cards
  scrollArea: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  card: {
    backgroundColor: colors.inp,
    padding: 20,
    borderRadius: 10,
    marginBottom: 15,
    justifyContent: 'center',
    borderWidth: 2, 
    borderColor: 'transparent', 
    width: '100%',           
    height: 185,             
    alignSelf: 'center',     
  },
  selectedCard: {
    borderColor: colors.secondary, 
  },
  cardRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  textColumnInsideCard: {
    flex: 1,
    flexShrink: 1,
  },
  optionTitle: {
    fontFamily: 'InterBold',
    fontSize: 25,
    letterSpacing: -0.8,
    color: colors.l_gray,
  },
  optionTitle2: {
    fontFamily: 'InterBold',
    fontSize: 25,
    letterSpacing: -0.8,
    color: colors.secondary,
    marginTop: -5,
  },
  optionText: {
    fontFamily: 'InterItalic',
    fontSize: 15,
    letterSpacing: -0.5,
    color: colors.d_gray,
  },

  // Bottom Button
  bottomShadowWrapper: {
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -3 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
    paddingHorizontal: 20,
    paddingBottom: 80,
    paddingTop: 20,
  },
  button: { 
    marginTop: 15, 
    backgroundColor: '#fff',
    padding: 9, 
    borderRadius: 30, 
    width: '53%', 
    height: 42, 
    alignSelf: 'center', 
    shadowColor: colors.l_gray, 
    shadowOpacity: 0.1, 
    shadowOffset: { width: 0, height: 2 }, 
    elevation: 5 
  },
  buttonText: { 
    alignSelf: 'center', 
    fontSize: 16, 
    fontFamily: 'InterBold', 
    color: colors.d_gray, 
    letterSpacing: -0.4 
  },
});
