import React from 'react';
import 'react-native-gesture-handler';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// Expo & Fonts
import { useFonts } from 'expo-font';

// Navigators
import DrawerNavigator from './navigation/drawer_navigator';

// No Account Screens
import FrontSplash from './no_acc/FrontSplash';
import FrontScreenNav from './no_acc/FrontScreenNav';
import FSEventDeets from './no_acc/FSEventDeets';

// Authentication & Onboarding
import CodeVerification from './src/screen/CodeVerification';
import CreateAccount from './src/screen/CreateAccount';
import GettingStarted from './src/screen/GettingStarted';
import SignInPage from './src/screen/SignInPage';
import StartingPage from './src/screen/StartingPage';

// User Type Selection
import LoadingScreen from './src/SelectUserType/LoadingScreen';
import SelectDepartment from './src/SelectUserType/SelectDepartment';
import SelectPosition from './src/SelectUserType/SelectPosition';
import SelectUser from './src/SelectUserType/SelectUser';

// Measurement & Anthropometrics
import InputAnthro from './src/GettingStartedMeasurement/InputAnthro';
import InputComplete from './src/GettingStartedMeasurement/InputComplete';
import MeasurementGuide from './src/GettingStartedMeasurement/MeasurementGuide';
import Select_Input from './src/GettingStartedMeasurement/Select_Input';
import VisitCHK from './src/GettingStartedMeasurement/VisitCHK';

// User Profile Pages
import AnthroInfo from './src/screen/homepage/user/UserPageContent/AnthroInfo';
import BasicInfo from './src/screen/homepage/user/UserPageContent/BasicInfo';
import MeasurementGuideEdit from './src/screen/homepage/user/UserPageContent/MeasurementGuideEdit';

// Events
import EventDetail from './src/screen/homepage/home/EventDetail';

// Smart Route Planning
import SRP_ActivityHistory from './src/screen/smart_route/SRP_ActivityHistory';
import SRP_PlanRoute from './src/screen/smart_route/SRP_PlanRoute';
import SRP_RoutePreview from './src/screen/smart_route/SRP_RoutePreview';

// Muscle Pain Management Scheduling
import MP_Appointments from './src/screen/muscle_pain/MP_Appointments';
import MP_SelectDate from './src/screen/muscle_pain/MP_SelectDate';

// Fitness Activity Logger
import ALP_ActivityHistory from './src/screen/activity_log/ALP_ActivityHistory';
import ALP_LogActivity from './src/screen/activity_log/ALP_LogActivity';

// Personalized Fitness Coaching
import FCP_ChatScreen from './src/screen/personal_fit/FCP_ChatScreen';
import FCP_HistoryPlan from './src/screen/personal_fit/FCP_HistoryPlan';
import FCP_LogActivity from './src/screen/personal_fit/FCP_LogActivity';
import FCP_MessageList from './src/screen/personal_fit/FCP_MessageList';
import FCP_RequestPlan from './src/screen/personal_fit/FCP_RequestPlan';
import FCP_WorkoutPlan from './src/screen/personal_fit/FCP_WorkoutPlan';
import FCP_WorkoutPlanDetail from './src/screen/personal_fit/FCP_WorkoutPlanDetail';
import FitnessCoachPage from './src/screen/personal_fit/FitnessCoachPage';

// Fitness Resource Selection
import FRS_ActivityHistory from './src/screen/fitness_selection/FRS_ActivityHistory';
import FRS_BrowseVideos from './src/screen/fitness_selection/FRS_BrowseVideos';
import FRS_VideoActivity from './src/screen/fitness_selection/FRS_VideoActivity';
import FRS_VideoPreview from './src/screen/fitness_selection/FRS_VideoPreview';
import FitnessSelectionPage from './src/screen/fitness_selection/FitnessSelectionPage';

const RootStack = createNativeStackNavigator();

const App = () => {
  const [fontsLoaded] = useFonts({
    InterRegular: require('./src/assets/fonts/Inter-Regular.ttf'),
    InterItalic: require('./src/assets/fonts/Inter-Italic.otf'),
    InterBold: require('./src/assets/fonts/Inter-Bold.ttf'),
    InterBoldItalic: require('./src/assets/fonts/Inter-BoldItalic.otf'),
  });

  if (!fontsLoaded) return null;

  return (
    <NavigationContainer>
      <RootStack.Navigator
        screenOptions={{
          headerShown: false,
          animation: 'none',
        }}
      >
        {/* ================= NO ACCOUNT SCREENS ================= */}
        <RootStack.Screen name="Splash" component={FrontSplash} />
        <RootStack.Screen name="Front" component={FrontScreenNav} />
        <RootStack.Screen name="FrontEventDeets" component={FSEventDeets} />

        {/* ================= AUTHENTICATION & ONBOARDING ================= */}
        <RootStack.Screen name="Start" component={StartingPage} />
        <RootStack.Screen name="SignIn" component={SignInPage} />
        <RootStack.Screen name="CreateAcc" component={CreateAccount} />
        <RootStack.Screen name="CodeVeri" component={CodeVerification} />
        <RootStack.Screen name="GetStart" component={GettingStarted} />

        {/* ================= USER TYPE SELECTION ================= */}
        <RootStack.Screen name="Sel_User" component={SelectUser} />
        <RootStack.Screen name="Sel_Pos" component={SelectPosition} />
        <RootStack.Screen name="Sel_Dep" component={SelectDepartment} />
        <RootStack.Screen name="Loading" component={LoadingScreen} />

        {/* ================= MEASUREMENT & ANTHROPOMETRICS ================= */}
        <RootStack.Screen name="SelectInput" component={Select_Input} />
        <RootStack.Screen name="Inp_Anthro" component={InputAnthro} />
        <RootStack.Screen name="Mea_Guide" component={MeasurementGuide} />
        <RootStack.Screen name="Visit_CHK" component={VisitCHK} />
        <RootStack.Screen name="InpComp" component={InputComplete} />

        {/* ================= MAIN APP (DRAWER) ================= */}
        <RootStack.Screen name="MainApp" component={DrawerNavigator} />

        {/* ================= USER PROFILE PAGES ================= */}
        <RootStack.Screen name="BasicInfo" component={BasicInfo} />
        <RootStack.Screen name="AnthroInfo" component={AnthroInfo} />
        <RootStack.Screen name="Mea_Guide2" component={MeasurementGuideEdit} />

        {/* ================= EVENTS ================= */}
        <RootStack.Screen name="EventDeets" component={EventDetail} />

        {/* ================= SMART ROUTE PLANNING ================= */}
        <RootStack.Screen name="SRP_PlanRoute" component={SRP_PlanRoute} />
        <RootStack.Screen name="SRP_ActHis" component={SRP_ActivityHistory} />
        <RootStack.Screen name="SRP_RoutePreview" component={SRP_RoutePreview} />

        {/* ================= MUSCLE PAIN MANAGEMENT ================= */}
        <RootStack.Screen name="MP_SelectDate" component={MP_SelectDate} />
        <RootStack.Screen name="MP_Appointments" component={MP_Appointments} />

        {/* ================= FITNESS ACTIVITY LOGGER ================= */}
        <RootStack.Screen name="ALP_LogAct" component={ALP_LogActivity} />
        <RootStack.Screen name="ALP_ActHis" component={ALP_ActivityHistory} />

        {/* ================= PERSONALIZED FITNESS COACHING ================= */}
        <RootStack.Screen name="FitnessCoachPage" component={FitnessCoachPage} />
        <RootStack.Screen name="FCP_WorkoutPlan" component={FCP_WorkoutPlan} />
        <RootStack.Screen name="FCP_WorkoutPlanDetail" component={FCP_WorkoutPlanDetail} />
        <RootStack.Screen name="FCP_LogActivity" component={FCP_LogActivity} />
        <RootStack.Screen name="FCP_RequestPlan" component={FCP_RequestPlan} />
        <RootStack.Screen name="FCP_HistoryPlan" component={FCP_HistoryPlan} />
        <RootStack.Screen name="FCP_ChatScreen" component={FCP_ChatScreen} />
        <RootStack.Screen name="FCP_MessageList" component={FCP_MessageList} />

        {/* ================= FITNESS RESOURCE SELECTION ================= */}
        <RootStack.Screen name="FitnessSelectionPage" component={FitnessSelectionPage} />
        <RootStack.Screen name="FRS_BrowseVideos" component={FRS_BrowseVideos} />
        <RootStack.Screen name="FRS_ActivityHistory" component={FRS_ActivityHistory} />
        <RootStack.Screen name="FRS_VideoPreview" component={FRS_VideoPreview} />
        <RootStack.Screen name="FRS_VideoActivity" component={FRS_VideoActivity} />
      </RootStack.Navigator>
    </NavigationContainer>
  );
};

export default App;
