import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, Pressable } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { colors } from '../src/util/colors';
import FeatStackNavigator from './FeatStackNavigator';
import { getFocusedRouteNameFromRoute } from '@react-navigation/native';

const Tab = createBottomTabNavigator();

export default function TabNavigator() {
  const getTabIconColor = (route, focused, defaultColor) => {
    const routeName = getFocusedRouteNameFromRoute(route) ?? 'HomeMain';
    if (route.name === 'Home' && routeName !== 'HomeMain') {
      return colors.l_gray; 
    }
    return focused ? colors.secondary : defaultColor;
  };

  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: false,
        tabBarStyle: { height: 100 },
        tabBarButton: (props) => (
          <Pressable
            {...props}
            android_ripple={{ color: 'transparent' }}
            style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}
          >
            {props.children}
          </Pressable>
        ),
      }}
    >
      <Tab.Screen
        name="Home"
        children={() => <FeatStackNavigator initialRouteName="HomeMain" />}
        listeners={({ navigation }) => ({
          tabPress: (e) => {
            e.preventDefault();
            navigation.reset({
              index: 0,
              routes: [{ name: 'MainApp' }],
            });
          },
        })}
        options={({ route }) => ({
          tabBarIcon: ({ focused }) => (
            <Feather name="home" color={getTabIconColor(route, focused, colors.l_gray)} size={22} />
          ),
        })}
      />


      <Tab.Screen
        name="UserTab"
        children={() => <FeatStackNavigator initialRouteName="User" />}
        options={{
          tabBarIcon: ({ focused }) => (
            <Feather
              name="user"
              color={focused ? colors.secondary : colors.l_gray}
              size={23}
            />
          ),
        }}
      />

      <Tab.Screen
        name="NotifTab"
        children={() => <FeatStackNavigator initialRouteName="Notif" />}
        options={{
          tabBarIcon: ({ focused }) => (
            <Feather
              name="bell"
              color={focused ? colors.secondary : colors.l_gray}
              size={22}
            />
          ),
        }}
      />
    </Tab.Navigator>
  );
}
