import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HeaderContent from '../components/HeaderContent';
import HomePage from '../src/screen/homepage/home/HomePage';
import UserPage from '../src/screen/homepage/user/UserPage';
import NotifPage from '../src/screen/homepage/notification/NotifPage';
import SmartRoutePage from '../src/screen/smart_route/SmartRoutePage';
import FitnessCoachPage from '../src/screen/personal_fit/FitnessCoachPage';
import MusclePainPage from '../src/screen/muscle_pain/MusclePainPage';
import FitnessSelectionPage from '../src/screen/fitness_selection/FitnessSelectionPage';
import ActivityLogPage from '../src/screen/activity_log/ActivityLogPage';
import RecomPage from '../src/screen/recco/RecomPage';

const Stack = createNativeStackNavigator();

export default function FeatStackNavigator({ initialRouteName }) {
  return (
    <Stack.Navigator
      initialRouteName={initialRouteName}
      screenOptions={{
        header: () => <HeaderContent />,
        animation: 'none',
      }}
    >
      <Stack.Screen name="HomeMain" component={HomePage} />
      <Stack.Screen name="User" component={UserPage} />
      <Stack.Screen name="Notif" component={NotifPage} />
      <Stack.Screen name="RoutePlanning" component={SmartRoutePage} />
      <Stack.Screen name="FitnessCoach" component={FitnessCoachPage} />
      <Stack.Screen name="Appointment" component={MusclePainPage} />
      <Stack.Screen name="FitnessSelection" component={FitnessSelectionPage} />
      <Stack.Screen name="ActivityLogger" component={ActivityLogPage} />
      <Stack.Screen name="Recommended" component={RecomPage} />
    </Stack.Navigator>
  );
}
