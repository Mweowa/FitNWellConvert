# FitNWell Admin Dashboard

A modern React Native Web-based admin for managing the FitNWell application.

## Features

- 📊 **Dashboard Overview** - Key metrics and statistics
- 📅 **Appointment Management** - View and manage appointments
- 👥 **User Management** - Manage user accounts and profiles
- 📈 **Analytics** - Detailed reports and insights
- ⚙️ **Settings** - System configuration and preferences
- 📱 **Responsive Design** - Works on desktop and mobile devices
- 🌐 **React Native Web** - Cross-platform compatibility

## Tech Stack

- **React Native Web** - Cross-platform development
- **Expo** - Development platform and tools
- **React Navigation** - Navigation between screens
- **Lucide React Native** - Beautiful icons
- **StyleSheet** - Native styling system

## Getting Started

### Prerequisites

- Node.js (version 16 or higher)
- npm or yarn package manager
- Expo CLI (optional but recommended)

### Installation

1. Navigate to the project directory:
   ```bash
   cd fit-n-well/FitNWell/FitNWell_Admin
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run web
   ```

4. Open your browser and visit:
   ```
   http://localhost:8081
   ```

## Available Scripts

- `npm run web` - Runs the app in web browser
- `npm run android` - Runs the app on Android device/emulator
- `npm run ios` - Runs the app on iOS device/simulator
- `npm start` - Starts the Expo development server
- `npm run build` - Builds the app for production

## Project Structure

```
FitNWell_Admin/
├── App.js                 # Main app component
├── src/
│   ├── components/
│   │   └── Sidebar.js     # Navigation sidebar
│   ├── screens/
│   │   └── Dashboard.js   # Main dashboard screen
│   ├── styles/
│   └── utils/
├── package.json
└── README.md
```

## Color Scheme

The admin dashboard uses the FitNWell brand colors:

- **Primary Green**: `#9FC03B`
- **Secondary Green**: `#C0D72F`
- **Dark Gray**: `#5B5B5B`
- **Light Gray**: `#8E8B8B`
- **Input Background**: `#F0F0F0`

## Features to Implement

- [ ] Real-time appointment notifications
- [ ] User authentication and authorization
- [ ] Data visualization with charts
- [ ] Appointment scheduling system
- [ ] User profile management
- [ ] Export functionality for reports
- [ ] Mobile-responsive navigation
- [ ] Push notifications

## Development

### Adding New Screens

1. Create a new screen component in `src/screens/`
2. Add the screen to the navigation stack in `App.js`
3. Add navigation item to the sidebar in `src/components/Sidebar.js`

### Styling

The app uses React Native's StyleSheet for consistent styling across platforms. All styles are defined using the native styling system.

### Icons

Icons are imported from `lucide-react-native` for consistency and cross-platform compatibility.

## Troubleshooting

### Common Issues

1. **Port conflicts**: If port 8081 is in use, Expo will automatically use the next available port
2. **Dependency issues**: Run `npm install --legacy-peer-deps` if you encounter peer dependency conflicts
3. **Web build issues**: Clear browser cache and restart the development server

### Performance

- The app is optimized for web performance
- Uses React Native Web for efficient rendering
- Implements proper component optimization

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly on web and mobile
5. Submit a pull request

## License

This project is part of the FitNWell application suite. 