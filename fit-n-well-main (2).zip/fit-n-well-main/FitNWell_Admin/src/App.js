import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
import Landing from './screens/Landing';
import Login from './screens/Login';
import CHK_Dashboard from './screens/CHK/CHK_Dashboard';
import CHK_UserManagement from './screens/CHK/CHK_UserManagement';
import CHK_UMPending from './screens/CHK/CHK_UMPending';
import CHK_ActivityLogs from './screens/CHK/CHK_ActivityLogs';
import CHK_FitnessPlans from './screens/CHK/CHK_FitnessPlans';
import CHK_FPHistory from './screens/CHK/CHK_FPHistory';
import CHK_Measurements from './screens/CHK/CHK_Measurements';
import CHK_AdminManagement from './screens/CHK/CHK_AdminManagement';
import CHK_Appointments from './screens/CHK/CHK_Appointments';
import CHK_MPPending from './screens/CHK/CHK_MPPending';
import CHK_EventsDisplay from './screens/CHK/CHK_EventsDisplay';
import CHK_UserProfile from './screens/CHK/CHK_UserProfile';
import CHK_WorkoutVideos from './screens/CHK/CHK_WorkoutVideos';
import Coach_ActivityLogs from './screens/Coach/Coach_ActivityLogs';
import Coach_ALView from './screens/Coach/Coach_ALView'; 
import Coach_Dashboard from './screens/Coach/Coach_Dashboard';
import Coach_FitnessAssessment from './screens/Coach/Coach_FitnessAssessment';
import Coach_PlanRequests from './screens/Coach/Coach_PlanRequests';
import Coach_FitnessPlans from './screens/Coach/Coach_FitnessPlans'; 
import Coach_FPHistory from './screens/Coach/Coach_FPHistory';
import Coach_Messages from './screens/Coach/Coach_Messages';
import Coach_Measurements from './screens/Coach/Coach_Measurements';
import Coach_UserProfile from './screens/Coach/Coach_UserProfile';
import MP_UserProfile from './screens/MP/MP_UserProfile';
import MP_Dashboard from './screens/MP/MP_Dashboard';
import MP_Appointments from './screens/MP/MP_Appointments';
import MP_Requests from './screens/MP/MP_Requests';
import './App.css';

function useDisableBackOnDashboard() {
  const location = useLocation();
  useEffect(() => {
    const handlePopState = (event) => {
      if (location.pathname === '/chk-dashboard' || location.pathname === '/mp-dashboard'|| location.pathname === '/coach-dashboard') {
        event.preventDefault();
        window.history.pushState(null, '', location.pathname);
      }
    };
    window.addEventListener('popstate', handlePopState);
    if (location.pathname === '/chk-dashboard' || location.pathname === '/mp-dashboard' || location.pathname === '/coach-dashboard') {
      window.history.pushState(null, '', location.pathname);
    }
    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, [location.pathname]);
}

function AppContent() {
  const [selectedRole, setSelectedRole] = useState('');
  const navigate = useNavigate();

  const handleLandingButtonClick = (role) => {
    setSelectedRole(role);
  };

  const handleLoginSuccess = () => {
    // Navigation handled in Login component
  };

  const handleLogout = () => {
    setSelectedRole('');
  };

  const handleMPNavigation = (route) => {
    if (route === 'appointments') {
      navigate('/mp-appointments');
    } else if (route === 'appointment-requests') {
      navigate('/mp-requests');
    }
  };

    const handleCoachNavigation = (route) => {
    if (route === 'dashboard') {
      navigate('/coach-dashboard');
    } else if (route === 'plan-requests') {
      navigate('/coach-plan-requests');
    } else if (route === 'fitness-plans') {
      navigate('/coach-fitness-plans');
    } else if (route === 'activity-logs') {
      navigate('/coach-activity-logs');
    } else if (route === 'fitness-assessments') {
      navigate('/coach-fitness-assessments');
    } else if (route === 'measurements') {
      navigate('/coach-measurements');
    } else if (route === 'messages') {
      navigate('/coach-messages');
    }
  };

  useDisableBackOnDashboard();

  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Landing onButtonClick={handleLandingButtonClick} />} />
        <Route 
          path="/login" 
          element={
            selectedRole ? (
              <Login selectedRole={selectedRole} onLoginSuccess={handleLoginSuccess} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/chk-dashboard" 
          element={
            selectedRole === 'College of Human Kinetics' ? (
              <CHK_Dashboard onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/user-management" 
          element={
            selectedRole === 'College of Human Kinetics' ? (
              <CHK_UserManagement onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/um-pending" 
          element={
            selectedRole === 'College of Human Kinetics' ? (
              <CHK_UMPending onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/admin-management" 
          element={
            selectedRole === 'College of Human Kinetics' ? (
              <CHK_AdminManagement onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/workout-videos" 
          element={
            selectedRole === 'College of Human Kinetics' ? (
              <CHK_WorkoutVideos onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/events-display" 
          element={
            selectedRole === 'College of Human Kinetics' ? (
              <CHK_EventsDisplay />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/activity-logs" 
          element={
            selectedRole === 'College of Human Kinetics' ? (
              <CHK_ActivityLogs onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/user-profile" 
          element={
            selectedRole === 'College of Human Kinetics' ? (
              <CHK_UserProfile onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/appointments" 
          element={
            selectedRole === 'College of Human Kinetics' ? (
              <CHK_Appointments onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
          <Route 
          path="/mp-pending" 
          element={
            selectedRole === 'College of Human Kinetics' ? (
              <CHK_MPPending onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/fitness-plans" 
          element={
            selectedRole === 'College of Human Kinetics' ? (
              <CHK_FitnessPlans onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/fp-history" 
          element={
            selectedRole === 'College of Human Kinetics' ? (
              <CHK_FPHistory onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/measurements" 
          element={
            selectedRole === 'College of Human Kinetics' ? (
              <CHK_Measurements onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/coach-user-profile" 
          element={
            selectedRole === 'Coach' ? (
              <Coach_UserProfile onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/coach-activity-logs" 
          element={
            selectedRole === 'Coach' ? (
              <Coach_ActivityLogs onLogout={handleLogout} onNavigate={handleCoachNavigation}/>
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />  
        <Route 
          path="/coach-activity-logs-view/:clientName" 
          element={
            selectedRole === 'Coach' ? (
              <Coach_ALView onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/coach-dashboard" 
          element={
            selectedRole === 'Coach' ? (
              <Coach_Dashboard onLogout={handleLogout} onNavigate={handleCoachNavigation}/>
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />  
        <Route 
          path="/coach-fitness-assessments" 
          element={
            selectedRole === 'Coach' ? (
              <Coach_FitnessAssessment onLogout={handleLogout} onNavigate={handleCoachNavigation}/>
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />  
        <Route 
          path="/coach-plan-requests" 
          element={
            selectedRole === 'Coach' ? (
              <Coach_PlanRequests onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
          <Route 
          path="/coach-fitness-plans" 
          element={
            selectedRole === 'Coach' ? (
              <Coach_FitnessPlans onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        /> 
        <Route 
          path="/coach-fp-history" 
          element={
            selectedRole === 'Coach' ? (
              <Coach_FPHistory onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/coach-measurements" 
          element={
            selectedRole === 'Coach' ? (
              <Coach_Measurements onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/coach-messages" 
          element={
            selectedRole === 'Coach' ? (
              <Coach_Messages onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />    
        <Route 
          path="/mp-user-profile" 
          element={
            selectedRole === 'Muscle Pain Management' ? (
              <MP_UserProfile onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/mp-dashboard" 
          element={
            selectedRole === 'Muscle Pain Management' ? (
              <MP_Dashboard onLogout={handleLogout} onNavigate={handleMPNavigation} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/mp-appointments" 
          element={
            selectedRole === 'Muscle Pain Management' ? (
              <MP_Appointments onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route 
          path="/mp-requests" 
          element={
            selectedRole === 'Muscle Pain Management' ? (
              <MP_Requests onLogout={handleLogout} />
            ) : (
              <Navigate to="/" replace />
            )
          } 
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </div>
  );
}

function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

export default App; 