import React, { useState, useEffect } from 'react';
import { colors } from '../utils/colors';

const EditMeasurements = ({ visible, onClose, measurementData, onSave }) => {
  const [formData, setFormData] = useState({
    basicMeasurements: {
      height: '',
      weight: '',
      bmi: ''
    },
    circumferences: {
      chest: '',
      waist: '',
      upperArm: '',
      thigh: '',
      calf: '',
      waistToHipRatio: ''
    },
    skinFold: {
      chest: '',
      abdomen: '',
      thigh: ''
    }
  });

  useEffect(() => {
    if (measurementData && visible) {
      setFormData({
        basicMeasurements: {
          height: measurementData.basicMeasurements?.height || '',
          weight: measurementData.basicMeasurements?.weight || '',
          bmi: measurementData.basicMeasurements?.bmi || ''
        },
        circumferences: {
          chest: measurementData.circumferences?.chest || '',
          waist: measurementData.circumferences?.waist || '',
          upperArm: measurementData.circumferences?.upperArm || '',
          thigh: measurementData.circumferences?.thigh || '',
          calf: measurementData.circumferences?.calf || '',
          waistToHipRatio: measurementData.circumferences?.waistToHipRatio || ''
        },
        skinFold: {
          chest: measurementData.skinFold?.chest || '',
          abdomen: measurementData.skinFold?.abdomen || '',
          thigh: measurementData.skinFold?.thigh || ''
        }
      });
    }
  }, [measurementData, visible]);

  if (!visible) return null;

  const handleInputChange = (section, field, value) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value
      }
    }));
  };

  const handleSave = () => {
    if (onSave) {
      onSave(formData);
    }
    onClose();
  };

  const handleClear = () => {
    setFormData({
      basicMeasurements: { height: '', weight: '', bmi: '' },
      circumferences: { chest: '', waist: '', upperArm: '', thigh: '', calf: '', waistToHipRatio: '' },
      skinFold: { chest: '', abdomen: '', thigh: '' }
    });
  };

  const styles = {
    overlay: {
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      zIndex: 1000,
    },
    modal: {
      backgroundColor: '#fff',
      borderRadius: '8px',
      padding: '0',
      width: '600px',
      maxWidth: '90vw',
      maxHeight: '90vh',
      boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
      display: 'flex',
      flexDirection: 'column',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '20px 24px',
      borderBottom: '1px solid #e0e0e0',
      flexShrink: 0,
    },
    title: {
      margin: 0,
      fontSize: '20px',
      fontWeight: 'bold',
      color: colors.main,
    },
    closeButton: {
      background: 'none',
      border: 'none',
      fontSize: '18px',
      cursor: 'pointer',
      color: '#333',
      padding: '4px',
      borderRadius: '4px',
      transition: 'color 0.2s ease',
    },
    content: {
      padding: '24px',
      overflowY: 'auto',
      flex: 1,
      maxHeight: 'calc(90vh - 80px)',
    },
    section: {
      marginBottom: '24px',
    },
    sectionTitle: {
      fontWeight: '600',
      color: colors.main,
      marginBottom: '16px',
      fontSize: '16px',
    },
    formGrid: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: '16px',
    },
    inputGroup: {
      display: 'flex',
      flexDirection: 'column',
    },
    inputLabel: {
      fontSize: '14px',
      fontWeight: '500',
      color: '#333',
      marginBottom: '6px',
    },
    input: {
      padding: '8px 12px',
      border: '1px solid #e0e0e0',
      borderRadius: '4px',
      fontSize: '14px',
      backgroundColor: '#f8f9fa',
      outline: 'none',
      transition: 'border-color 0.2s ease',
    },
    buttonContainer: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: '12px',
      marginTop: '24px',
    },
    saveButton: {
      backgroundColor: colors.main,
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '10px 20px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '500',
      transition: 'background-color 0.2s ease',
    },
    clearButton: {
      backgroundColor: '#fff',
      color: colors.d_gray,
      border: '1px solid colors.inp',
      borderRadius: '4px',
      padding: '10px 20px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '500',
      transition: 'all 0.2s ease',
    },
  };

  return (
    <div style={styles.overlay}>
      <div style={styles.modal}>
        <div style={styles.header}>
          <h3 style={styles.title}>Edit Measurements</h3>
          <button 
            style={styles.closeButton}
            onClick={onClose}
            onMouseEnter={(e) => {
              e.target.style.color = '#666';
            }}
            onMouseLeave={(e) => {
              e.target.style.color = '#333';
            }}
          >
            ✕
          </button>
        </div>
        <div style={styles.content}>
          {/* Basic Measurements */}
          <div style={styles.section}>
            <div style={styles.sectionTitle}>Basic Measurements</div>
            <div style={styles.formGrid}>
              <div style={styles.inputGroup}>
                <label style={styles.inputLabel}>Height</label>
                <input
                  type="number"
                  style={styles.input}
                  value={formData.basicMeasurements.height}
                  onChange={(e) => handleInputChange('basicMeasurements', 'height', e.target.value)}
                  placeholder="cm"
                />
              </div>
              <div style={styles.inputGroup}>
                <label style={styles.inputLabel}>Weight</label>
                <input
                  type="number"
                  style={styles.input}
                  value={formData.basicMeasurements.weight}
                  onChange={(e) => handleInputChange('basicMeasurements', 'weight', e.target.value)}
                  placeholder="kg"
                />
              </div>
              <div style={styles.inputGroup}>
                <label style={styles.inputLabel}>BMI</label>
                <input
                  type="number"
                  style={styles.input}
                  value={formData.basicMeasurements.bmi}
                  onChange={(e) => handleInputChange('basicMeasurements', 'bmi', e.target.value)}
                  placeholder="BMI"
                />
              </div>
            </div>
          </div>

          {/* Circumferences */}
          <div style={styles.section}>
            <div style={styles.sectionTitle}>Circumferences (cm)</div>
            <div style={styles.formGrid}>
              <div style={styles.inputGroup}>
                <label style={styles.inputLabel}>Chest</label>
                <input
                  type="number"
                  style={styles.input}
                  value={formData.circumferences.chest}
                  onChange={(e) => handleInputChange('circumferences', 'chest', e.target.value)}
                  placeholder="cm"
                />
              </div>
              <div style={styles.inputGroup}>
                <label style={styles.inputLabel}>Waist</label>
                <input
                  type="number"
                  style={styles.input}
                  value={formData.circumferences.waist}
                  onChange={(e) => handleInputChange('circumferences', 'waist', e.target.value)}
                  placeholder="cm"
                />
              </div>
              <div style={styles.inputGroup}>
                <label style={styles.inputLabel}>Upper Arm</label>
                <input
                  type="number"
                  style={styles.input}
                  value={formData.circumferences.upperArm}
                  onChange={(e) => handleInputChange('circumferences', 'upperArm', e.target.value)}
                  placeholder="cm"
                />
              </div>
              <div style={styles.inputGroup}>
                <label style={styles.inputLabel}>Thigh</label>
                <input
                  type="number"
                  style={styles.input}
                  value={formData.circumferences.thigh}
                  onChange={(e) => handleInputChange('circumferences', 'thigh', e.target.value)}
                  placeholder="cm"
                />
              </div>
              <div style={styles.inputGroup}>
                <label style={styles.inputLabel}>Calf</label>
                <input
                  type="number"
                  style={styles.input}
                  value={formData.circumferences.calf}
                  onChange={(e) => handleInputChange('circumferences', 'calf', e.target.value)}
                  placeholder="cm"
                />
              </div>
              <div style={styles.inputGroup}>
                <label style={styles.inputLabel}>Waist-to-hip Ratio</label>
                <input
                  type="number"
                  style={styles.input}
                  value={formData.circumferences.waistToHipRatio}
                  onChange={(e) => handleInputChange('circumferences', 'waistToHipRatio', e.target.value)}
                  placeholder="ratio"
                />
              </div>
            </div>
          </div>

          {/* Skin Fold */}
          <div style={styles.section}>
            <div style={styles.sectionTitle}>Skin Fold (mm)</div>
            <div style={styles.formGrid}>
              <div style={styles.inputGroup}>
                <label style={styles.inputLabel}>Chest</label>
                <input
                  type="number"
                  style={styles.input}
                  value={formData.skinFold.chest}
                  onChange={(e) => handleInputChange('skinFold', 'chest', e.target.value)}
                  placeholder="mm"
                />
              </div>
              <div style={styles.inputGroup}>
                <label style={styles.inputLabel}>Abdomen / Suprailiac</label>
                <input
                  type="number"
                  style={styles.input}
                  value={formData.skinFold.abdomen}
                  onChange={(e) => handleInputChange('skinFold', 'abdomen', e.target.value)}
                  placeholder="mm"
                />
              </div>
              <div style={styles.inputGroup}>
                <label style={styles.inputLabel}>Thigh</label>
                <input
                  type="number"
                  style={styles.input}
                  value={formData.skinFold.thigh}
                  onChange={(e) => handleInputChange('skinFold', 'thigh', e.target.value)}
                  placeholder="mm"
                />
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div style={styles.buttonContainer}>
            <button
              style={styles.clearButton}
              onClick={handleClear}
              onMouseEnter={(e) => {
                e.target.style.backgroundColor = '#f8f9fa';
              }}
              onMouseLeave={(e) => {
                e.target.style.backgroundColor = '#fff';
              }}
            >
              Clear
            </button>
            <button
              style={styles.saveButton}
              onClick={handleSave}
              onMouseEnter={(e) => {
                e.target.style.backgroundColor = colors.secondary;
              }}
              onMouseLeave={(e) => {
                e.target.style.backgroundColor = colors.main;
              }}
            >
              Save Changes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditMeasurements; 