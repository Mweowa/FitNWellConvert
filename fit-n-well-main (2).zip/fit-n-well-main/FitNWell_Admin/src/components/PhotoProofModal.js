import React, { useState } from 'react';
import { colors } from '../utils/colors';
import PhotoRejection from './PhotoRejection';

const PhotoProofModal = ({ 
  visible, 
  onClose, 
  onApprove, 
  onReject,
  photoUrl = null,
  title = "Photo Proof"
}) => {
  const [showRejectionModal, setShowRejectionModal] = useState(false);

  if (!visible) return null;

  const handleRejectClick = () => {
    setShowRejectionModal(true);
  };

  const handleRejectionSubmit = (reason) => {
    onReject(reason);
    setShowRejectionModal(false);
  };

  const handleRejectionClose = () => {
    setShowRejectionModal(false);
  };

  return (
    <>
      <div style={styles.overlay}>
        <div style={styles.modalContainer}>
          {/* Close button */}
          <button style={styles.closeButton} onClick={onClose}>
            <span style={styles.closeButtonText}>×</span>
          </button>
          
          {/* Modal content */}
          <div style={styles.content}>
            <h3 style={styles.title}>{title}</h3>
            
            {/* Photo display area */}
            <div style={styles.photoContainer}>
              {photoUrl ? (
                <img 
                  src={photoUrl} 
                  alt="Photo Proof" 
                  style={styles.photo}
                  onError={(e) => {
                    e.target.style.display = 'none';
                    e.target.nextSibling.style.display = 'flex';
                  }}
                />
              ) : null}
              <div style={styles.photoPlaceholder}>
                <div style={styles.placeholderIcon}>
                  <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM19 19H5V5H19V19Z" fill="#666"/>
                    <path d="M14.14 11.86L11 15L9 13L6 16H18L14.14 11.86Z" fill="#666"/>
                  </svg>
                </div>
              </div>
            </div>
            
            {/* Action buttons */}
            <div style={styles.buttonContainer}>
              <button style={styles.rejectButton} onClick={handleRejectClick}>
                Reject
              </button>
              
              <button style={styles.approveButton} onClick={onApprove}>
                Approve
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Photo Rejection Modal */}
      <PhotoRejection
        visible={showRejectionModal}
        onClose={handleRejectionClose}
        onReject={handleRejectionSubmit}
        photoUrl={photoUrl}
        title={`Photo Rejection - ${title}`}
      />
    </>
  );
};

const styles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  modalContainer: {
    backgroundColor: 'white',
    borderRadius: '10px',
    padding: '20px',
    margin: '20px',
    width: '500px',
    maxWidth: '90vw',
    position: 'relative',
    border: '1px solid #e0e0e0',
    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
  },
  closeButton: {
    position: 'absolute',
    top: '10px',
    right: '10px',
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontSize: '24px',
    color: colors.d_gray,
    fontWeight: 'bold',
    padding: '0',
    width: '30px',
    height: '30px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeButtonText: {
    lineHeight: '1',
  },
  content: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    width: '100%',
  },
  title: {
    fontSize: '18px',
    color: colors.d_gray,
    textAlign: 'left',
    marginBottom: '20px',
    fontWeight: '500',
    margin: '0 0 20px 0',
    alignSelf: 'flex-start',
  },
  photoContainer: {
    width: '100%',
    marginBottom: '20px',
    position: 'relative',
  },
  photo: {
    width: '100%',
    height: '300px',
    objectFit: 'cover',
    borderRadius: '8px',
    border: '1px solid #e0e0e0',
  },
  photoPlaceholder: {
    width: '100%',
    height: '300px',
    backgroundColor: '#f5f5f5',
    borderRadius: '8px',
    border: '2px dashed #d0d0d0',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'column',
  },
  placeholderIcon: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#666',
  },
  buttonContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    gap: '15px',
    width: '100%',
  },
  rejectButton: {
    flex: 1,
    backgroundColor: colors.delete,
    color: 'white',
    border: 'none',
    padding: '12px 20px',
    borderRadius: '8px',
    fontSize: '14px',
    fontWeight: '500',
    cursor: 'pointer',
    transition: 'background-color 0.2s ease',
  },
  approveButton: {
    flex: 1,
    backgroundColor: colors.verified,
    color: 'white',
    border: 'none',
    padding: '12px 20px',
    borderRadius: '8px',
    fontSize: '14px',
    fontWeight: '500',
    cursor: 'pointer',
    transition: 'background-color 0.2s ease',
  },
};

export default PhotoProofModal; 