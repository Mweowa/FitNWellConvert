import React, { useState, useEffect } from 'react';
import { colors } from '../utils/colors';

const ViewFitAssessment = ({ visible, onClose, clientName }) => {
  const [selectedAssessmentId, setSelectedAssessmentId] = useState('');
  const [assessmentData, setAssessmentData] = useState(null);
  const [allAssessments, setAllAssessments] = useState([]);

  useEffect(() => {
    if (visible && clientName) {
      // Load all assessments from localStorage
      const existingRecords = JSON.parse(localStorage.getItem('fitnessAssessments') || '[]');
      
      // Filter assessments for this specific client
      const clientAssessments = existingRecords.filter(record => record.client === clientName);
      
      setAllAssessments(clientAssessments);
      
      // Set the latest assessment as default
      if (clientAssessments.length > 0) {
        const latestAssessment = clientAssessments[clientAssessments.length - 1];
        setSelectedAssessmentId(latestAssessment.timestamp);
        setAssessmentData(latestAssessment);
      } else {
        setAssessmentData(null);
      }
    }
  }, [visible, clientName]);

  const handleAssessmentChange = (selectedTimestamp) => {
    setSelectedAssessmentId(selectedTimestamp);
    const selectedAssessment = allAssessments.find(assessment => assessment.timestamp === selectedTimestamp);
    setAssessmentData(selectedAssessment);
  };

  if (!visible) return null;

  const styles = {
    overlay: {
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      zIndex: 1000,
    },
    modal: {
      backgroundColor: '#fff',
      borderRadius: '8px',
      padding: '0',
      width: '500px',
      maxWidth: '90vw',
      maxHeight: '90vh',
      boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
      display: 'flex',
      flexDirection: 'column',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '20px 24px',
      borderBottom: '1px solid #e0e0e0',
      flexShrink: 0,
    },
    title: {
      margin: 0,
      fontSize: '20px',
      fontWeight: 'bold',
      color: colors.main,
    },
    closeButton: {
      background: 'none',
      border: 'none',
      fontSize: '18px',
      cursor: 'pointer',
      color: '#333',
      padding: '4px',
      borderRadius: '4px',
      transition: 'color 0.2s ease',
    },
    content: {
      padding: '24px',
      overflowY: 'auto',
      flex: 1,
      maxHeight: 'calc(90vh - 80px)',
    },
    dropdown: {
      width: '100%',
      padding: '12px',
      border: '1px solid #e0e0e0',
      borderRadius: '8px',
      fontSize: '14px',
      color: '#333',
      backgroundColor: '#f8f9fa',
      marginBottom: '20px',
      cursor: 'pointer',
      outline: 'none',
    },
    section: {
      marginBottom: '24px',
    },
    sectionTitle: {
      fontWeight: '600',
      color: colors.main,
      marginBottom: '10px',
      fontSize: '16px',
    },
    assessmentRow: {
      display: 'flex',
      marginBottom: '8px',
      alignItems: 'flex-start',
    },
    assessmentLabel: {
      fontWeight: '510',
      color: '#333',
      marginRight: '8px',
      marginLeft: '30px',
      minWidth: '150px',
    },
    assessmentValue: {
      color: colors.d_gray,
      flex: 1,
    },
    noDataMessage: {
      textAlign: 'center',
      color: '#666',
      fontSize: '16px',
      padding: '40px 20px',
    },
    categoryBadge: {
      display: 'inline-block',
      backgroundColor: colors.main,
      color: '#fff',
      padding: '4px 12px',
      borderRadius: '16px',
      fontSize: '12px',
      fontWeight: '500',
      marginBottom: '16px',
    },
  };

  const formatDate = (timestamp) => {
    return new Date(timestamp).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div style={styles.overlay}>
      <div style={styles.modal}>
        <div style={styles.header}>
          <h3 style={styles.title}>View Fitness Assessment - {clientName}</h3>
          <button 
            style={styles.closeButton}
            onClick={onClose}
            onMouseEnter={(e) => {
              e.target.style.color = '#666';
            }}
            onMouseLeave={(e) => {
              e.target.style.color = '#333';
            }}
          >
            ✕
          </button>
        </div>
        <div style={styles.content}>
          {allAssessments.length > 0 ? (
            <>
              {/* Assessment Selection Dropdown */}
              <select 
                style={styles.dropdown}
                value={selectedAssessmentId}
                onChange={(e) => handleAssessmentChange(e.target.value)}
              >
                {allAssessments.map((assessment, index) => (
                  <option key={assessment.timestamp} value={assessment.timestamp}>
                    {assessment.title || `Assessment ${index + 1}`} - {formatDate(assessment.timestamp)}
                  </option>
                ))}
              </select>

              {/* Assessment Data Display */}
              {assessmentData && (
                <>
                  <div style={styles.categoryBadge}>
                    {assessmentData.category}
                  </div>
                  
                  <div style={styles.section}>
                    <div style={styles.sectionTitle}>
                      {assessmentData.title || 'Fitness Assessment'}
                    </div>
                    
                    {Object.entries(assessmentData.assessments).map(([key, value]) => (
                      <div key={key} style={styles.assessmentRow}>
                        <span style={styles.assessmentLabel}>{key}:</span>
                        <span style={styles.assessmentValue}>{value}</span>
                      </div>
                    ))}
                  </div>

                  <div style={styles.section}>
                    <div style={styles.sectionTitle}>Assessment Details:</div>
                    <div style={styles.assessmentRow}>
                      <span style={styles.assessmentLabel}>Date Recorded:</span>
                      <span style={styles.assessmentValue}>{formatDate(assessmentData.timestamp)}</span>
                    </div>
                    <div style={styles.assessmentRow}>
                      <span style={styles.assessmentLabel}>Category:</span>
                      <span style={styles.assessmentValue}>{assessmentData.category}</span>
                    </div>
                  </div>
                </>
              )}
            </>
          ) : (
            <div style={styles.noDataMessage}>
              No fitness assessments found for {clientName}.
              <br />
              Add an assessment first to view records.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ViewFitAssessment;