import React, { useState } from 'react';
import { colors } from '../utils/colors';

const AddFitAssessment = ({ isOpen, onClose, clientName }) => {
  const [selectedCategory, setSelectedCategory] = useState('Health-Related Fitness');
  const [assessmentTitle, setAssessmentTitle] = useState('');
  const [selectedAssessment, setSelectedAssessment] = useState('No assessments yet');
  
  // State for assessment values
  const [healthRelatedValues, setHealthRelatedValues] = useState({
    'Cardiovascular Endurance': '',
    'Muscle Strength': '',
    'Muscle Endurance': '',
    'Flexibility': '',
    'BMI': ''
  });

  const [skillRelatedValues, setSkillRelatedValues] = useState({
    'Power': '',
    'Reaction Time': '',
    'Agility': '',
    'Coordination': '',
    'Speed': '',
    'Balance': ''
  });

  const healthRelatedAssessments = [
    'Cardiovascular Endurance',
    'Muscle Strength',
    'Muscle Endurance',
    'Flexibility',
    'BMI'
  ];

  const skillRelatedAssessments = [
    'Power',
    'Reaction Time',
    'Agility',
    'Coordination',
    'Speed',
    'Balance'
  ];

  const getCurrentAssessments = () => {
    return selectedCategory === 'Health-Related Fitness' 
      ? healthRelatedAssessments 
      : skillRelatedAssessments;
  };

  const getCurrentValues = () => {
    return selectedCategory === 'Health-Related Fitness'
      ? healthRelatedValues
      : skillRelatedValues;
  };

  const handleValueChange = (assessmentName, value) => {
    if (selectedCategory === 'Health-Related Fitness') {
      setHealthRelatedValues(prev => ({
        ...prev,
        [assessmentName]: value
      }));
    } else {
      setSkillRelatedValues(prev => ({
        ...prev,
        [assessmentName]: value
      }));
    }
  };

  const handleSave = () => {
    // Check if all required fields are filled
    if (!isFormValid()) {
      alert('Please fill in all fields before saving.');
      return;
    }

    const assessmentData = {
      client: clientName,
      category: selectedCategory,
      title: assessmentTitle,
      assessments: getCurrentValues(),
      timestamp: new Date().toISOString()
    };
    
    console.log('Saving assessment data:', assessmentData);
    
    // Here you would typically save to your database or state management
    // For now, we'll save to localStorage to demonstrate
    const existingRecords = JSON.parse(localStorage.getItem('fitnessAssessments') || '[]');
    existingRecords.push(assessmentData);
    localStorage.setItem('fitnessAssessments', JSON.stringify(existingRecords));
    
    onClose();
  };

  const isFormValid = () => {
    // Check if assessment title is filled
    if (!assessmentTitle.trim()) {
      return false;
    }

    // Check if all assessment values are filled
    const currentValues = getCurrentValues();
    const currentAssessments = getCurrentAssessments();
    
    for (let assessment of currentAssessments) {
      if (!currentValues[assessment] || currentValues[assessment].trim() === '') {
        return false;
      }
    }
    
    return true;
  };

  const resetForm = () => {
    setSelectedCategory('Health-Related Fitness');
    setAssessmentTitle('');
    setSelectedAssessment('No assessments yet');
    setHealthRelatedValues({
      'Cardiovascular Endurance': '',
      'Muscle Strength': '',
      'Muscle Endurance': '',
      'Flexibility': '',
      'BMI': ''
    });
    setSkillRelatedValues({
      'Power': '',
      'Reaction Time': '',
      'Agility': '',
      'Coordination': '',
      'Speed': '',
      'Balance': ''
    });
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  if (!isOpen) return null;

  const styles = {
    overlay: {
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000,
    },
    modal: {
      backgroundColor: '#fff',
      borderRadius: '12px',
      padding: '24px',
      width: '600px',
      maxHeight: '80vh',
      overflowY: 'auto',
      position: 'relative',
      boxShadow: '0 10px 25px rgba(0, 0, 0, 0.15)',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '24px',
    },
    title: {
      fontSize: '24px',
      fontWeight: 'bold',
      color: colors.main,
      margin: 0,
    },
    closeButton: {
      background: 'none',
      border: 'none',
      fontSize: '24px',
      color: '#999',
      cursor: 'pointer',
      padding: '4px',
      lineHeight: 1,
    },
    dropdown: {
      width: '100%',
      padding: '12px',
      border: '1px solid #e0e0e0',
      borderRadius: '8px',
      fontSize: '14px',
      color: '#666',
      backgroundColor: '#f8f9fa',
      marginBottom: '16px',
      cursor: 'pointer',
    },
    input: {
      width: '100%',
      padding: '12px',
      border: '1px solid #e0e0e0',
      borderRadius: '8px',
      fontSize: '14px',
      color: '#333',
      backgroundColor: '#f8f9fa',
      marginBottom: '20px',
      outline: 'none',
    },
    tabContainer: {
      display: 'flex',
      marginBottom: '20px',
      gap: '4px',
    },
    tab: {
      padding: '8px 16px',
      border: 'none',
      borderRadius: '6px',
      fontSize: '14px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      backgroundColor: '#f0f0f0',
      color: '#666',
    },
    activeTab: {
      padding: '8px 16px',
      border: 'none',
      borderRadius: '6px',
      fontSize: '14px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      backgroundColor: colors.main,
      color: '#fff',
    },
    assessmentGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(2, 1fr)',
      gap: '12px',
      marginBottom: '24px',
    },
    assessmentCard: {
      padding: '16px',
      backgroundColor: '#f8f9fa',
      borderRadius: '8px',
      border: '1px solid #e0e0e0',
      display: 'flex',
      flexDirection: 'column',
      gap: '8px',
    },
    assessmentCardSelected: {
      padding: '16px',
      backgroundColor: 'rgba(159, 192, 59, 0.1)',
      borderRadius: '8px',
      border: `2px solid ${colors.main}`,
      display: 'flex',
      flexDirection: 'column',
      gap: '8px',
    },
    assessmentLabel: {
      fontSize: '14px',
      fontWeight: '500',
      color: '#333',
      margin: 0,
      marginBottom: '8px',
    },
    assessmentInput: {
      width: '90%',
      padding: '8px 10px',
      border: '1px solid #ddd',
      borderRadius: '4px',
      fontSize: '13px',
      color: '#333',
      outline: 'none',
      backgroundColor: '#f8f9fa',
      transition: 'border-color 0.2s ease',
    },
    saveButton: {
      backgroundColor: colors.main,
      color: '#fff',
      border: 'none',
      borderRadius: '8px',
      padding: '12px 32px',
      fontSize: '14px',
      fontWeight: '500',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      display: 'block',
      margin: '0 auto',
    },
    saveButtonDisabled: {
      backgroundColor: '#ccc',
      color: '#666',
      border: 'none',
      borderRadius: '8px',
      padding: '12px 32px',
      fontSize: '14px',
      fontWeight: '500',
      cursor: 'not-allowed',
      transition: 'background-color 0.2s ease',
      display: 'block',
      margin: '0 auto',
    },
  };

  return (
    <div style={styles.overlay} onClick={handleClose}>
      <div style={styles.modal} onClick={(e) => e.stopPropagation()}>
        <div style={styles.header}>
          <h2 style={styles.title}>Add Fitness Assessment</h2>
          <button style={styles.closeButton} onClick={handleClose}>
            ×
          </button>
        </div>

        <select 
          style={styles.dropdown}
          value={selectedAssessment}
          onChange={(e) => setSelectedAssessment(e.target.value)}
        >
          <option value="No assessments yet">No assessments yet</option>
        </select>

        <input
          type="text"
          placeholder="Enter assessment title"
          value={assessmentTitle}
          onChange={(e) => setAssessmentTitle(e.target.value)}
          style={styles.input}
        />

        <div style={styles.tabContainer}>
          <button
            style={selectedCategory === 'Health-Related Fitness' ? styles.activeTab : styles.tab}
            onClick={() => setSelectedCategory('Health-Related Fitness')}
          >
            Health-Related Fitness
          </button>
          <button
            style={selectedCategory === 'Skill-Related Fitness' ? styles.activeTab : styles.tab}
            onClick={() => setSelectedCategory('Skill-Related Fitness')}
          >
            Skill-Related Fitness
          </button>
        </div>

        <div style={styles.assessmentGrid}>
          {getCurrentAssessments().map((assessment, index) => (
            <div key={index}>
              <p style={styles.assessmentLabel}>{assessment}</p>
              <input
                type="number"
                step="0.01"
                placeholder={`Enter ${assessment.toLowerCase()} value`}
                value={getCurrentValues()[assessment] || ''}
                onChange={(e) => handleValueChange(assessment, e.target.value)}
                style={styles.assessmentInput}
                onFocus={(e) => {
                  e.target.style.borderColor = colors.main;
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = '#ddd';
                }}
              />
            </div>
          ))}
        </div>

        <button
          style={isFormValid() ? styles.saveButton : styles.saveButtonDisabled}
          onClick={handleSave}
          disabled={!isFormValid()}
          onMouseEnter={(e) => {
            if (isFormValid()) {
              e.target.style.backgroundColor = '#87a333';
            }
          }}
          onMouseLeave={(e) => {
            if (isFormValid()) {
              e.target.style.backgroundColor = colors.main;
            }
          }}
        >
          Save
        </button>
      </div>
    </div>
  );
};

export default AddFitAssessment;