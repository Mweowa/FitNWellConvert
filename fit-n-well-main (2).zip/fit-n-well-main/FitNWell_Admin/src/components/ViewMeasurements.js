import React from 'react';
import { colors } from '../utils/colors';

const ViewMeasurements = ({ visible, onClose, measurementData }) => {
  if (!visible) return null;

  const styles = {
    overlay: {
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      zIndex: 1000,
    },
    modal: {
      backgroundColor: '#fff',
      borderRadius: '8px',
      padding: '0',
      width: '500px',
      maxWidth: '90vw',
      maxHeight: '90vh',
      boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
      display: 'flex',
      flexDirection: 'column',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '20px 24px',
      borderBottom: '1px solid #e0e0e0',
      flexShrink: 0,
    },
    title: {
      margin: 0,
      fontSize: '20px',
      fontWeight: 'bold',
      color: colors.main,
    },
    closeButton: {
      background: 'none',
      border: 'none',
      fontSize: '18px',
      cursor: 'pointer',
      color: '#333',
      padding: '4px',
      borderRadius: '4px',
      transition: 'color 0.2s ease',
    },
    content: {
      padding: '24px',
      overflowY: 'auto',
      flex: 1,
      maxHeight: 'calc(90vh - 80px)',
    },
    section: {
      marginBottom: '24px',
    },
    sectionTitle: {
      fontWeight: '600',
      color: colors.main,
      marginBottom: '10px',
      fontSize: '16px',
    },
    measurementRow: {
      display: 'flex',
      marginBottom: '8px',
      alignItems: 'flex-start',
    },
    measurementLabel: {
      fontWeight: '510',
      color: '#333',
      marginRight: '8px',
      marginLeft: '30px',

    },
    measurementValue: {
      color: colors.d_gray,
      flex: 1,
    },
  };

  // Default measurement data if none provided
  const defaultMeasurementData = {
    name: 'John Doe',
    basicMeasurements: {
      height: 150,
      weight: 76.4,
      bmi: 33.2
    },
    circumferences: {
      chest: 10,
      waist: 10,
      upperArm: 10,
      thigh: 10,
      calf: 10,
      waistToHipRatio: 10
    },
    skinFold: {
      chest: 10,
      abdomen: 10,
      thigh: 10
    }
  };

  const measurements = measurementData || defaultMeasurementData;

  return (
    <div style={styles.overlay}>
      <div style={styles.modal}>
        <div style={styles.header}>
          <h3 style={styles.title}>View Measurements</h3>
          <button 
            style={styles.closeButton}
            onClick={onClose}
            onMouseEnter={(e) => {
              e.target.style.color = '#666';
            }}
            onMouseLeave={(e) => {
              e.target.style.color = '#333';
            }}
          >
            ✕
          </button>
        </div>
        <div style={styles.content}>
          <div style={styles.section}>
            <div style={styles.sectionTitle}>Basic Measurements:</div>
            <div style={styles.measurementRow}>
              <span style={styles.measurementLabel}>Height (cm):</span>
              <span style={styles.measurementValue}>{measurements.basicMeasurements.height}</span>
            </div>
            <div style={styles.measurementRow}>
              <span style={styles.measurementLabel}>Weight (kg):</span>
              <span style={styles.measurementValue}>{measurements.basicMeasurements.weight}</span>
            </div>
            <div style={styles.measurementRow}>
              <span style={styles.measurementLabel}>BMI:</span>
              <span style={styles.measurementValue}>{measurements.basicMeasurements.bmi}</span>
            </div>
          </div>

          <div style={styles.section}>
            <div style={styles.sectionTitle}>Circumferences (cm):</div>
            <div style={styles.measurementRow}>
              <span style={styles.measurementLabel}>Chest:</span>
              <span style={styles.measurementValue}>{measurements.circumferences.chest}</span>
            </div>
            <div style={styles.measurementRow}>
              <span style={styles.measurementLabel}>Waist:</span>
              <span style={styles.measurementValue}>{measurements.circumferences.waist}</span>
            </div>
            <div style={styles.measurementRow}>
              <span style={styles.measurementLabel}>Upper Arm:</span>
              <span style={styles.measurementValue}>{measurements.circumferences.upperArm}</span>
            </div>
            <div style={styles.measurementRow}>
              <span style={styles.measurementLabel}>Thigh:</span>
              <span style={styles.measurementValue}>{measurements.circumferences.thigh}</span>
            </div>
            <div style={styles.measurementRow}>
              <span style={styles.measurementLabel}>Calf:</span>
              <span style={styles.measurementValue}>{measurements.circumferences.calf}</span>
            </div>
            <div style={styles.measurementRow}>
              <span style={styles.measurementLabel}>Waist-to-hip Ratio:</span>
              <span style={styles.measurementValue}>{measurements.circumferences.waistToHipRatio}</span>
            </div>
          </div>

          <div style={styles.section}>
            <div style={styles.sectionTitle}>Skin Fold (mm):</div>
            <div style={styles.measurementRow}>
              <span style={styles.measurementLabel}>Chest:</span>
              <span style={styles.measurementValue}>{measurements.skinFold.chest}</span>
            </div>
            <div style={styles.measurementRow}>
              <span style={styles.measurementLabel}>Abdomen / Suprailiac:</span>
              <span style={styles.measurementValue}>{measurements.skinFold.abdomen}</span>
            </div>
            <div style={styles.measurementRow}>
              <span style={styles.measurementLabel}>Thigh:</span>
              <span style={styles.measurementValue}>{measurements.skinFold.thigh}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ViewMeasurements; 