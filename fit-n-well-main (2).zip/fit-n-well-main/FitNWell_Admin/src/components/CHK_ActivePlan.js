import React from 'react';
import { colors } from '../utils/colors';

const CHK_ActivePlan = ({ visible, onClose, planData }) => {
  if (!visible) return null;

  const styles = {
    overlay: {
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      zIndex: 1000,
    },
    modal: {
      backgroundColor: '#fff',
      borderRadius: '8px',
      padding: '0',
      width: '500px',
      maxWidth: '90vw',
      boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '20px 24px',
      borderBottom: '1px solid #e0e0e0',
    },
    title: {
      margin: 0,
      fontSize: '20px',
      fontWeight: 'bold',
      color: colors.main,
    },
    closeButton: {
      background: 'none',
      border: 'none',
      fontSize: '18px',
      cursor: 'pointer',
      color: '#333',
      padding: '4px',
      borderRadius: '4px',
      transition: 'color 0.2s ease',
    },
    content: {
      padding: '24px',
    },
    detailRow: {
      display: 'flex',
      marginBottom: '12px',
      alignItems: 'flex-start',
    },
    detailLabel: {
      fontWeight: '600',
      color: '#333',
      minWidth: '80px',
      marginRight: '8px',
    },
    detailValue: {
      color: colors.d_gray,
      flex: 1,
    },
    exercisesSection: {
      marginTop: '20px',
    },
    exercisesTitle: {
      fontWeight: '600',
      color: '#333',
      marginBottom: '12px',
      fontSize: '16px',
    },
    exerciseCategory: {
      marginBottom: '16px',
    },
    categoryTitle: {
      fontWeight: '600',
      color: '#333',
      marginBottom: '8px',
    },
    exerciseItem: {
      color: colors.d_gray,
      marginLeft: '16px',
      marginBottom: '4px',
    },
  };

  const defaultPlanData = {
    planId: '01',
    planTitle: 'Workout 1',
    name: 'Jimmy Reyes',
    date: 'August 08, 2025 - August 24, 2025',
    days: 'Mon, Tue, Wed',
    exercises: {
      warmUp: [
        { name: 'Stretch', duration: '1 min' }
      ],
      mainExercise: [
        { name: 'Squats', sets: 5, reps: 10 }
      ],
      coolDown: [
        { name: 'Stretch', duration: '1 min' }
      ]
    }
  };

  const plan = planData || defaultPlanData;

  return (
    <div style={styles.overlay}>
      <div style={styles.modal}>
        <div style={styles.header}>
          <h3 style={styles.title}>Active Fitness Plan</h3>
          <button 
            style={styles.closeButton}
            onClick={onClose}
            onMouseEnter={(e) => {
              e.target.style.color = '#666';
            }}
            onMouseLeave={(e) => {
              e.target.style.color = '#333';
            }}
          >
            ✕
          </button>
        </div>
        <div style={styles.content}>
          <div style={styles.detailRow}>
            <span style={styles.detailLabel}>Plan ID:</span>
            <span style={styles.detailValue}>{plan.planId}</span>
          </div>
          <div style={styles.detailRow}>
            <span style={styles.detailLabel}>Plan Title:</span>
            <span style={styles.detailValue}>{plan.planTitle}</span>
          </div>
          <div style={styles.detailRow}>
            <span style={styles.detailLabel}>Name:</span>
            <span style={styles.detailValue}>{plan.name}</span>
          </div>
          <div style={styles.detailRow}>
            <span style={styles.detailLabel}>Date:</span>
            <span style={styles.detailValue}>{plan.date}</span>
          </div>
          <div style={styles.detailRow}>
            <span style={styles.detailLabel}>Days:</span>
            <span style={styles.detailValue}>{plan.days}</span>
          </div>

          <div style={styles.exercisesSection}>
            <div style={styles.exercisesTitle}>Exercises:</div>
            
            <div style={styles.exerciseCategory}>
              <div style={styles.categoryTitle}>Warm Up:</div>
              {plan.exercises.warmUp.map((exercise, index) => (
                <div key={index} style={styles.exerciseItem}>
                  {exercise.name} - {exercise.duration}
                </div>
              ))}
            </div>

            <div style={styles.exerciseCategory}>
              <div style={styles.categoryTitle}>Main Exercise:</div>
              {plan.exercises.mainExercise.map((exercise, index) => (
                <div key={index} style={styles.exerciseItem}>
                  {exercise.name} - {exercise.sets} sets x {exercise.reps} reps
                </div>
              ))}
            </div>

            <div style={styles.exerciseCategory}>
              <div style={styles.categoryTitle}>Cool Down:</div>
              {plan.exercises.coolDown.map((exercise, index) => (
                <div key={index} style={styles.exerciseItem}>
                  {exercise.name} - {exercise.duration}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CHK_ActivePlan; 