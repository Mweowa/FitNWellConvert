import React from 'react';
import { colors } from '../utils/colors';

const MPComplete = ({ 
  visible, 
  onClose, 
  onConfirm, 
  title = "Are you sure you want to mark this appointment as completed?",
  confirmText = "Yes",
  cancelText = "No"
}) => {
  if (!visible) return null;

  return (
    <div style={styles.overlay}>
      <div style={styles.modalContainer}>
        {/* Close button */}
        <button style={styles.closeButton} onClick={onClose}>
          <span style={styles.closeButtonText}>×</span>
        </button>
        
        {/* Modal content */}
        <div style={styles.content}>
          <h3 style={styles.title}>{title}</h3>
          
          {/* Action buttons */}
          <div style={styles.buttonContainer}>
            <button style={styles.noButton} onClick={onClose}>
              {cancelText}
            </button>
            
            <button style={styles.yesButton} onClick={onConfirm}>
              {confirmText}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const styles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  modalContainer: {
    backgroundColor: 'white',
    borderRadius: '10px',
    padding: '20px',
    margin: '20px',
    height: '160px',
    width: '500px',
    position: 'relative',
    border: '1px solid #e0e0e0',
    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },
  closeButton: {
    position: 'absolute',
    top: '10px',
    right: '10px',
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontSize: '24px',
    color: colors.d_gray,
    fontWeight: 'bold',
    padding: '0',
    width: '30px',
    height: '30px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeButtonText: {
    lineHeight: '1',
  },
  content: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
  },
  title: {
    fontSize: '18px',
    color: colors.d_gray,
    textAlign: 'center',
    marginBottom: '20px',
    fontWeight: '500',
    margin: '0 0 20px 0',
  },
  buttonContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    gap: '15px',
  },
  noButton: {
    flex: 1,
    backgroundColor: colors.edit,
    color: '#323232',
    border: 'none',
    padding: '12px 20px',
    borderRadius: '8px',
    fontSize: '14px',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'background-color 0.2s ease',
  },
  yesButton: {
    flex: 1,
    backgroundColor: colors.main,
    color: '#323232',
    border: 'none',
    padding: '12px 20px',
    borderRadius: '8px',
    fontSize: '14px',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'background-color 0.2s ease',
  },
};

export default MPComplete; 