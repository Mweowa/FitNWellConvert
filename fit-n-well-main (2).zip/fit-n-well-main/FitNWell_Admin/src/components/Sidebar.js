import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { 
  LayoutDashboard, 
  Calendar, 
  Users, 
  BarChart3, 
  Settings, 
  LogOut 
} from 'lucide-react-native';

const Sidebar = () => {
  const navigation = useNavigation();

  const navItems = [
    { name: 'Dashboard', icon: LayoutDashboard, screen: 'Dashboard' },
    { name: 'Appointments', icon: Calendar, screen: 'Appointments' },
    { name: 'Users', icon: Users, screen: 'Users' },
    { name: 'Analytics', icon: BarChart3, screen: 'Analytics' },
    { name: 'Settings', icon: Settings, screen: 'Settings' },
  ];

  const handleNavigation = (screenName) => {
    navigation.navigate(screenName);
  };

  return (
    <View style={styles.sidebar}>
      <View style={styles.sidebarHeader}>
        <Text style={styles.sidebarTitle}>FitNWell</Text>
        <Text style={styles.sidebarSubtitle}>Admin Dashboard</Text>
      </View>
      
      <ScrollView style={styles.navContainer}>
        {navItems.map((item, index) => {
          const Icon = item.icon;
          return (
            <TouchableOpacity
              key={index}
              style={styles.navItem}
              onPress={() => handleNavigation(item.screen)}
            >
              <View style={styles.navLink}>
                <Icon size={20} color="rgba(255, 255, 255, 0.9)" />
                <Text style={styles.navText}>{item.name}</Text>
              </View>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
      
      <View style={styles.logoutContainer}>
        <TouchableOpacity style={styles.navItem}>
          <View style={styles.navLink}>
            <LogOut size={20} color="rgba(255, 255, 255, 0.9)" />
            <Text style={styles.navText}>Logout</Text>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  sidebar: {
    width: 280,
    backgroundColor: '#9FC03B',
    height: '100%',
    position: 'absolute',
    left: 0,
    top: 0,
    paddingVertical: 24,
  },
  sidebarHeader: {
    paddingHorizontal: 24,
    paddingBottom: 24,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
    marginBottom: 24,
  },
  sidebarTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: 'white',
    marginBottom: 8,
  },
  sidebarSubtitle: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  navContainer: {
    flex: 1,
    paddingHorizontal: 16,
  },
  navItem: {
    marginBottom: 8,
  },
  navLink: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  navText: {
    marginLeft: 12,
    color: 'rgba(255, 255, 255, 0.9)',
    fontWeight: '500',
    fontSize: 16,
  },
  logoutContainer: {
    paddingHorizontal: 16,
    paddingTop: 24,
  },
});

export default Sidebar; 