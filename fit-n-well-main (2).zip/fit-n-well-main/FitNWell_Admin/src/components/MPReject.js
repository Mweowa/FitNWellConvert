import React, { useState } from 'react';
import { colors } from '../utils/colors';

const MPReject = ({ 
  visible, 
  onClose, 
  onConfirm, 
  title = "Are you sure you want to reject this appointment?",
  confirmText = "Yes",
  cancelText = "No"
}) => {
  // Ensure that hooks are called unconditionally, before any early return
  const [reason, setReason] = useState(''); // State for the input field

  if (!visible) return null; // Early return after hook calls

  const handleInputChange = (event) => {
    setReason(event.target.value); // Update the reason state
  };

  return (
    <div style={styles.overlay}>
      <div style={styles.modalContainer}>
        {/* Close button */}
        <button style={styles.closeButton} onClick={onClose}>
          <span style={styles.closeButtonText}>×</span>
        </button>
        
        {/* Modal content */}
        <div style={styles.content}>
          <h3 style={styles.title}>{title}</h3>
          
          {/* Reason input box */}
          <div style={styles.inputContainer}>
            <label style={styles.inputLabel}>Reason</label>
            <input 
              type="text" 
              value={reason}
              onChange={handleInputChange}
              style={styles.inputBox}
              placeholder="Enter"
            />
          </div>

          {/* Action buttons */}
          <div style={styles.buttonContainer}>
            <button style={styles.noButton} onClick={onClose}>
              {cancelText}
            </button>
            
            <button 
              style={styles.yesButton}
              onClick={() => onConfirm(reason)} // Pass reason to onConfirm
              disabled={!reason} // Disable the button if there's no reason
            >
              {confirmText}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const styles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  modalContainer: {
    backgroundColor: 'white',
    borderRadius: '10px',
    padding: '20px',
    margin: '20px',
    height: '250px', // Adjusted height for the input box
    width: '500px',
    position: 'relative',
    border: '1px solid #e0e0e0',
    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },
  closeButton: {
    position: 'absolute',
    top: '10px',
    right: '10px',
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontSize: '24px',
    color: colors.d_gray,
    fontWeight: 'bold',
    padding: '0',
    width: '30px',
    height: '30px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeButtonText: {
    lineHeight: '1',
  },
  content: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
  },
  title: {
    fontSize: '18px',
    color: colors.d_gray,
    textAlign: 'center',
    marginBottom: '25px',
    fontWeight: '500',
    margin: '0 0 20px 0',
  },
  inputContainer: {
    width: '100%',
    marginBottom: '20px',
  },
  inputLabel: {
    fontSize: '16px',
    color: colors.d_gray,
    marginBottom: '5px',
    fontWeight: '500'
  },
  inputBox: {
    width: '100%',
    padding: '10px',
    borderRadius: '8px',
    border: '1px solid #e0e0e0',
    fontSize: '14px',
    outline: 'none',
    marginTop: '8px',
  },
  buttonContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    gap: '15px',
  },
  noButton: {
    flex: 1,
    backgroundColor: colors.edit,
    color: '#323232',
    border: 'none',
    padding: '12px 20px',
    borderRadius: '8px',
    fontSize: '14px',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'background-color 0.2s ease',
  },
  yesButton: {
    flex: 1,
    backgroundColor: colors.main,
    color: '#323232',
    border: 'none',
    padding: '12px 20px',
    borderRadius: '8px',
    fontSize: '14px',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'background-color 0.2s ease',
  },
};

export default MPReject;
