import React, { useState } from 'react';
import { colors } from '../utils/colors';

const PhotoRejection = ({ 
  visible, 
  onClose, 
  onReject,
  photoUrl = null,
}) => {
  const [rejectionReason, setRejectionReason] = useState('');

  if (!visible) return null;

  const handleSubmit = () => {
    if (rejectionReason.trim()) {
      onReject(rejectionReason);
      setRejectionReason('');
    }
  };

  const handleClose = () => {
    setRejectionReason('');
    onClose();
  };

  return (
    <div style={styles.overlay}>
      <div style={styles.modalContainer}>
        {/* Close button */}
        <button style={styles.closeButton} onClick={handleClose}>
          <span style={styles.closeButtonText}>×</span>
        </button>
        
        {/* Modal content */}
        <div style={styles.content}>
          <h3 style={styles.title}>Photo Proof</h3>
          
          {/* Photo display area */}
          <div style={styles.photoContainer}>
            {photoUrl ? (
              <img 
                src={photoUrl} 
                alt="Activity Proof" 
                style={styles.photo}
                onError={(e) => {
                  e.target.style.display = 'none';
                  e.target.nextSibling.style.display = 'flex';
                }}
              />
            ) : null}
            <div style={styles.photoPlaceholder}>
              <div style={styles.placeholderIcon}>
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM19 19H5V5H19V19Z" fill="#666"/>
                  <path d="M14.14 11.86L11 15L9 13L6 16H18L14.14 11.86Z" fill="#666"/>
                </svg>
              </div>
            </div>
          </div>
          
          {/* Rejection Reason Input */}
          <div style={styles.reasonContainer}>
            <label style={styles.reasonLabel}>Reason for Rejection:</label>
            <textarea
              style={styles.reasonInput}
              placeholder="Enter reason..."
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              rows={4}
            />
          </div>

          {/* Submit Button */}
          <div style={styles.buttonContainer}>
            <button 
              style={styles.submitButton}
              onClick={handleSubmit}
              disabled={!rejectionReason.trim()}
            >
              Submit
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const styles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  modalContainer: {
    backgroundColor: 'white',
    borderRadius: '10px',
    padding: '20px',
    margin: '20px',
    width: '500px',
    maxWidth: '90vw',
    position: 'relative',
    border: '1px solid #e0e0e0',
    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
  },
  closeButton: {
    position: 'absolute',
    top: '10px',
    right: '10px',
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontSize: '24px',
    color: colors.d_gray,
    fontWeight: 'bold',
    padding: '0',
    width: '30px',
    height: '30px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeButtonText: {
    lineHeight: '1',
  },
  content: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    width: '100%',
  },
  title: {
    fontSize: '18px',
    color: colors.d_gray,
    textAlign: 'left',
    marginBottom: '20px',
    fontWeight: 'bold',
    margin: '0 0 20px 0',
    alignSelf: 'flex-start',
    fontFamily: 'Inter, sans-serif',
  },
  photoContainer: {
    width: '100%',
    marginBottom: '20px',
    position: 'relative',
  },
  photo: {
    width: '100%',
    height: '300px',
    objectFit: 'cover',
    borderRadius: '8px',
    border: '1px solid #e0e0e0',
  },
  photoPlaceholder: {
    width: '100%',
    height: '300px',
    backgroundColor: '#f5f5f5',
    borderRadius: '8px',
    border: '2px dashed #d0d0d0',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'column',
  },
  placeholderIcon: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#666',
  },
  reasonContainer: {
    width: '100%',
    marginBottom: '20px',
  },
  reasonLabel: {
    display: 'block',
    fontSize: '14px',
    color: colors.d_gray,
    marginBottom: '8px',
    fontWeight: '500',
    textAlign: 'left',
  },
  reasonInput: {
    width: '100%',
    padding: '12px',
    border: '1px solid #e0e0e0',
    borderRadius: '8px',
    fontSize: '14px',
    color: '#333',
    resize: 'vertical',
    minHeight: '100px',
    fontFamily: 'Inter, sans-serif',
  },
  buttonContainer: {
    display: 'flex',
    justifyContent: 'center',
    width: '100%',
  },
  submitButton: {
    backgroundColor: '#fff',
    color: colors.d_gray,
    border: '1px solid #e0e0e0',
    borderRadius: '8px',
    padding: '10px 24px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: '500',
    transition: 'all 0.2s ease',
    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',

  },
};

export default PhotoRejection; 