export const colors = {
    main: "#9FC03B",
    secondary: "#C0D72F",
    d_gray: "#5B5B5B",
    l_gray: "#8E8B8B",
    inp: "#F0F0F0",

    pending : "#ADADAD",
    verified : "#9FC03B",
    rejected : "#888888",

    view: "#7bb3e8",
    delete: '#dc3545',
    edit: "#D9D9D9",
}