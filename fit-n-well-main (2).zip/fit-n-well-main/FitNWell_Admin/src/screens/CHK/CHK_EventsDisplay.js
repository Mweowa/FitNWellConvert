import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { colors } from '../../utils/colors';
import { FaUserCircle, FaHome, FaUsers, FaUsersCog, FaCalendarAlt, FaClipboardList, FaCalendarCheck, FaList } from "react-icons/fa";
import { LuListVideo } from "react-icons/lu";
import { IoScaleSharp } from "react-icons/io5";
import { CiLogout } from "react-icons/ci";
import { FaChevronRight, FaChevronLeft } from "react-icons/fa";
import DeleteModal from '../../components/DeleteModal';

const CHK_EventsDisplay = ({ onLogout }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const navigate = useNavigate();
  const [events, setEvents] = useState([
    {
      id: 1,
      title: 'PUPwell: Learn to Swim and Water Safety Program',
      date: '2025-02-08',
      time: '16:00',
      location: 'PUP Swimming Pool',
      description: 'Sample event description.',
    },
  ]);
  const [form, setForm] = useState({
    title: '',
    description: '',
    date: '',
    time: '',
    location: '',
    photo: null,
  });
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [eventToDelete, setEventToDelete] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingEvent, setEditingEvent] = useState(null);
  const [showViewModal, setShowViewModal] = useState(false);
  const [viewingEvent, setViewingEvent] = useState(null);
  const [editForm, setEditForm] = useState({
    title: '',
    description: '',
    date: '',
    time: '',
    location: '',
    photo: null,
  });

  const styles = {
    container: {
      display: 'flex',
      flexDirection: 'row',
      height: '100vh',
      backgroundColor: '#FEFFFD',
      overflow: 'auto',
    },
    sidebar: {
      backgroundColor: '#F1F1F2',
      padding: '17px 15px',
      width: isCollapsed ? '80px' : '230px',
      transition: 'width 0.3s ease, padding 0.3s ease',
      display: 'flex',
      flexDirection: 'column',
    },
    brand: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '15px',
      padding: isCollapsed ? '0' : '0 10px',
      justifyContent: isCollapsed ? 'center' : 'flex-start',
    },
    brandIcon: {
      width: '47px',
      height: '40px',
    },
    brandText: {
      fontSize: '25px',
      color: colors.d_gray,
      fontWeight: 700,
      fontStyle: 'italic',
      marginLeft: '15px',
      fontFamily: 'Inter, sans-serif',
    },
    menuContainer: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
    },
    menuGroup: {
      marginBottom: '20px',
    },
    menuDivider: {
      height: '1px',
      backgroundColor: '#e0e0e0',
      marginBottom: '15px',
    },
    menuItem: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemActive: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'rgba(159, 192, 59, 0.2)',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemCollapsed: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '12px 8px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuIcon: {
      fontSize: '20px',
      marginRight: isCollapsed ? '0' : '12px',
      color: colors.main,
      display: 'flex',
      alignItems: 'center',
    },
    menuText: {
      fontSize: '14px',
      color: colors.d_gray,
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    menuTextActive: {
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '600',
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    logoutButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#fff',
      border: 'none',
      borderRadius: '30px',
      padding: isCollapsed ? '2px 3px' : '7px 12px',
      marginTop: '20px',
      marginBottom: '10px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      width: isCollapsed ? 'auto' : 'fit-content',
      alignSelf: 'center',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
    },
    logoutIcon: {
      background: 'none',
      fontSize: '18px',
      marginRight: isCollapsed ? '0' : '8px',
      display: 'flex',
      alignItems: 'center',
      color: colors.main,
    },
    logoutText: {
      background: 'none',
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '500',
    },
    mainContent: {
      flex: 1,
      backgroundColor: '#FEFFFD',
      padding: '20px', 
      display: 'flex',
      flexDirection: 'column',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '30px', 
    },
    collapseButton: {
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      fontSize: '10px', 
      color: colors.l_gray,
      transition: 'background-color 0.2s ease',
      marginLeft: '-10px' 
    },
    pageTitle: {
      fontSize: '28px', 
      fontWeight: 'bold',
      color: colors.main,
      marginBottom: '20px', 
    },
    profileButton: {
      color: colors.main,      
      marginTop: '5px', 
      marginRight: '5px', 
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontSize: '32px', 
    },
    contentScrollView: {
      flex: 1,
      overflowY: 'auto',
    },
  };

  const editModalStyles = {
    overlay: {
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      zIndex: 1000,
    },
    modalContainer: {
      backgroundColor: '#fff',
      borderRadius: '10px',
      boxShadow: '0 5px 15px rgba(0, 0, 0, 0.3)',
      width: '90%',
      maxWidth: '600px',
      maxHeight: '90%',
      display: 'flex',
      flexDirection: 'column',
      position: 'relative',
    },
    closeButton: {
      position: 'absolute',
      top: '10px',
      right: '10px',
      background: 'none',
      border: 'none',
      fontSize: '24px',
      cursor: 'pointer',
      color: colors.d_gray,
      zIndex: 1,
    },
    closeButtonText: {
      fontSize: '24px',
    },
    content: {
      padding: '20px',
      overflowY: 'auto',
      flexGrow: 1,
    },
    title: {
      fontSize: '20px',
      fontWeight: 'bold',
      color: colors.main,
      marginBottom: '20px',
      textAlign: 'center',
    },
    formContainer: {
      display: 'flex',
      gap: '20px',
    },
    leftColumn: {
      flex: 1,
    },
    rightColumn: {
      flex: 1,
    },
    inputGroup: {
      marginBottom: '15px',
    },
    label: {
      fontSize: '14px',
      color: colors.main,
      fontWeight: '600',
      marginBottom: '5px',
      display: 'block',
    },
    input: {
      width: '100%',
      padding: '10px',
      border: '1px solid #eee',
      borderRadius: '5px',
      fontSize: '14px',
      background: colors.inp,
      fontFamily: 'inherit',
    },
    timeContainer: {
      display: 'flex',
      alignItems: 'center',
      gap: '5px',
    },
    textarea: {
      width: '100%',
      padding: '10px',
      border: '1px solid #eee',
      borderRadius: '5px',
      fontSize: '14px',
      background: colors.inp,
      fontFamily: 'inherit',
      resize: 'vertical',
    },
    fileInput: {
      marginTop: '10px',
      padding: '10px',
      border: '1px solid #eee',
      borderRadius: '5px',
      fontSize: '14px',
      background: colors.inp,
      fontFamily: 'inherit',
      cursor: 'pointer',
    },
    buttonContainer: {
      display: 'flex',
      justifyContent: 'flex-end',
      padding: '15px 20px',
      borderTop: '1px solid #eee',
    },
    saveButton: {
      background: colors.main,
      color: '#fff',
      border: 'none',
      borderRadius: '8px',
      padding: '10px 20px',
      fontSize: '14px',
      fontWeight: '600',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
    },
  };

  const viewModalStyles = {
    overlay: {
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      zIndex: 1000,
    },
    modalContainer: {
      backgroundColor: '#fff',
      borderRadius: '10px',
      boxShadow: '0 5px 15px rgba(0, 0, 0, 0.3)',
      width: '100%',
      maxWidth: '500px',
      minWidth: 0,
      maxHeight: '90%',
      display: 'flex',
      flexDirection: 'column',
      position: 'relative',
      overflowX: 'hidden',
    },
    closeButton: {
      position: 'absolute',
      top: '15px',
      right: '15px',
      background: 'none',
      border: 'none',
      fontSize: '20px',
      cursor: 'pointer',
      color: colors.d_gray,
      zIndex: 1,
    },
    content: {
      padding: '20px',
      overflowY: 'auto',
    },
    title: {
      fontSize: '18px',
      fontWeight: 'bold',
      color: colors.main,
      marginBottom: '20px',
    },
    imageContainer: {
      width: '100%',
      height: '200px',
      backgroundColor: '#f5f5f5',
      borderRadius: '8px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: '20px',
      border: '2px dashed #ddd',
    },
    imagePlaceholder: {
      fontSize: '48px',
      color: '#999',
    },
    eventTitle: {
      fontSize: '16px',
      fontWeight: 'bold',
      color: colors.d_gray,
      marginBottom: '15px',
      textAlign: 'center',
    },
    description: {
      marginBottom: '15px',
    },
    detailRow: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: '10px',
      flexWrap: 'wrap',
      minWidth: 0,
      width: '100%',
    },
    detailLabel: {
      fontSize: '14px',
      fontWeight: 600,
      color: colors.d_gray,
      minWidth: '80px',
      fontFamily: 'Inter, sans-serif',
      flexShrink: 0,
    },
    detailValue: {
      fontSize: '14px',
      color: '#333',
      flex: 1,
      lineHeight: '1.5',
      fontFamily: 'Inter, sans-serif',
      whiteSpace: 'normal',
      wordBreak: 'break-word',
      minWidth: 0,
    },
    detailsContainer: {
      display: 'flex',
      flexDirection: 'column',
      gap: '8px',
    },
    detailItem: {
      display: 'flex',
      alignItems: 'center',
    },
    detailLabel: {
      fontSize: '14px',
      fontWeight: 600,
      color: colors.d_gray,
      fontFamily: 'Inter, sans-serif',
      marginRight: '8px',
    },
    detailValue: {
      fontSize: '14px',
      color: '#333',
      flex: 1,
      lineHeight: '1',
      fontFamily: 'Inter, sans-serif',
    },
  };

  const menuItems = [
    { name: 'Dashboard', icon: <FaHome />, active: false, route: '/chk-dashboard' },
    { name: 'User Management', icon: <FaUsers />, active: false, route: '/user-management' },
    { name: 'Admin Management', icon: <FaUsersCog />, route: '/admin-management' },
    { name: 'Workout Videos', icon: <LuListVideo />, route: '/workout-videos' },
    { name: 'Events Display', icon: <FaCalendarAlt />, active: true, route: '/events-display' },
    { name: 'Activity Logs', icon: <FaClipboardList />, active: false, route: '/activity-logs' },
    { name: 'Appointments', icon: <FaCalendarCheck />, route: '/appointments' },
    { name: 'Fitness Plans', icon: <FaList />, route: '/fitness-plans' },
    { name: 'Measurements', icon: <IoScaleSharp />, route: '/measurements' },
  ];

  const renderMenuItem = (item, index) => {
    const menuItemStyle = item.active 
      ? (isCollapsed ? styles.menuItemCollapsed : styles.menuItemActive)
      : (isCollapsed ? styles.menuItemCollapsed : styles.menuItem);
    const menuTextStyle = item.active ? styles.menuTextActive : styles.menuText;
    return (
      <button
        key={index}
        style={menuItemStyle}
        onClick={() => {
          if (item.route) {
            navigate(item.route);
          }
        }}
        onMouseEnter={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'rgba(159, 192, 59, 0.1)';
          }
        }}
        onMouseLeave={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'transparent';
          }
        }}
      >
        <span style={styles.menuIcon}>{item.icon}</span>
        {!isCollapsed && (
          <span style={menuTextStyle}>{item.name}</span>
        )}
      </button>
    );
  };

  const handleInputChange = (e) => {
    const { name, value, files } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: files ? files[0] : value,
    }));
  };

  const handleCreateEvent = () => {
    if (!form.title || !form.description || !form.date || !form.time || !form.location || !form.photo) {
      alert('Please fill in all fields and select a photo.');
      return;
    }
    setEvents([
      ...events,
      {
        id: Date.now(),
        ...form,
      },
    ]);
    setForm({ title: '', description: '', date: '', time: '', location: '', photo: null });
    // Clear the file input
    const fileInput = document.querySelector('input[type="file"]');
    if (fileInput) {
      fileInput.value = '';
    }
  };

  const handleDeleteClick = (event) => {
    setEventToDelete(event);
    setShowDeleteModal(true);
  };
  const handleDeleteConfirm = () => {
    if (eventToDelete) {
      setEvents(events.filter(e => e.id !== eventToDelete.id));
    }
    setShowDeleteModal(false);
    setEventToDelete(null);
  };
  const handleDeleteCancel = () => {
    setShowDeleteModal(false);
    setEventToDelete(null);
  };

  const handleEdit = (event) => {
    setEditingEvent(event);
    setEditForm({
      title: event.title,
      description: event.description,
      date: event.date,
      time: event.time,
      location: event.location,
      photo: event.photo,
    });
    setShowEditModal(true);
  };

  const handleEditInputChange = (e) => {
    const { name, value, files } = e.target;
    setEditForm((prev) => ({
      ...prev,
      [name]: files ? files[0] : value,
    }));
  };

  const handleSaveChanges = () => {
    if (!editForm.title || !editForm.description || !editForm.date || !editForm.time || !editForm.location) {
      alert('Please fill in all required fields.');
      return;
    }
    
    setEvents(events.map(event => 
      event.id === editingEvent.id 
        ? { ...event, ...editForm }
        : event
    ));
    
    setShowEditModal(false);
    setEditingEvent(null);
    setEditForm({ title: '', description: '', date: '', time: '', location: '', photo: null });
    
    // Clear the file input
    const fileInput = document.querySelector('input[name="editPhoto"]');
    if (fileInput) {
      fileInput.value = '';
    }
  };

  const handleCloseEditModal = () => {
    setShowEditModal(false);
    setEditingEvent(null);
    setEditForm({ title: '', description: '', date: '', time: '', location: '', photo: null });
    
    // Clear the file input
    const fileInput = document.querySelector('input[name="editPhoto"]');
    if (fileInput) {
      fileInput.value = '';
    }
  };

  const handleView = (event) => {
    setViewingEvent(event);
    setShowViewModal(true);
  };

  const handleCloseViewModal = () => {
    setShowViewModal(false);
    setViewingEvent(null);
  };

  // Helper to format time to 12-hour format with AM/PM
  const formatTime12Hour = (time24) => {
    if (!time24) return '';
    const [hourStr, minute] = time24.split(':');
    let hour = parseInt(hourStr, 10);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    hour = hour % 12;
    if (hour === 0) hour = 12;
    return `${hour}:${minute} ${ampm}`;
  };

  const actionButtonStyle = {
    border: 'none',
    borderRadius: '4px',
    padding: '4px 8px',
    fontSize: '11px',
    cursor: 'pointer',
    color: '#fff',
    transition: 'background-color 0.2s ease',
  };

  return (
    <div style={styles.container}>
      {/* Sidebar */}
      <div style={styles.sidebar}>
        {/* Brand */}
        <div style={styles.brand}>
          <img 
            src="/fnw1.png" 
            alt="FitNWell Logo"
            style={styles.brandIcon}
          />
          {!isCollapsed && (
            <span style={styles.brandText}>FitNWell</span>
          )}
        </div>
        {/* Menu Items */}
        <div style={styles.menuContainer}>
          <div style={styles.menuDivider} />
          <div style={styles.menuGroup}>
            {menuItems.slice(0, 6).map((item, index) => renderMenuItem(item, index))}
          </div>
          <div style={styles.menuDivider} />
          <div style={styles.menuGroup}>
            {menuItems.slice(6).map((item, index) => renderMenuItem(item, index + 6))}
          </div>
        </div>
        {/* Logout Button */}
        <button 
          style={styles.logoutButton}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#f5f5f5';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#fff';
          }}
          onClick={onLogout}
        >
          <span style={styles.logoutIcon}><CiLogout /></span>
          {!isCollapsed && (
            <span style={styles.logoutText}>Log Out</span>
          )}
        </button>
      </div>
      {/* Main Content */}
      <div style={styles.mainContent}>
        {/* Header */}
        <div style={styles.header}>
          <button 
            style={styles.collapseButton}
            onClick={() => setIsCollapsed(!isCollapsed)}
          >
            {isCollapsed ? <FaChevronRight /> : <FaChevronLeft />}
          </button>
          <span style={styles.pageTitle}>Event Display</span>
          <button style={styles.profileButton}
          onClick={() => navigate('/user-profile')}
          >
            <FaUserCircle />
          </button>
        </div>
        {/* Scrollable Content */}
        <div style={styles.contentScrollView}>
          {/* Input Form */}
          <div style={{ background: '#fff', borderRadius: 9, boxShadow: '0 2px 8px #0001', padding: 24, marginBottom: 30 }}>
            <div style={{ color: colors.d_gray, fontWeight: 600, fontSize: 15, marginBottom: 9 }}>Title</div>
            <input
              name="title"
              value={form.title}
              onChange={handleInputChange}
              placeholder="Enter Event Name"
              style={{ width: '100%', padding: 9, borderRadius: 4, border: '1px solid #eee', background: colors.inp, marginBottom: 15, fontSize: 13, fontFamily: 'inherit' }}
              required
            />
            <div style={{ color: colors.d_gray, fontWeight: 600, fontSize: 15, marginBottom: 9 }}>Description</div>
            <textarea
              name="description"
              value={form.description}
              onChange={handleInputChange}
              placeholder="Enter Event Description"
              rows={3}
              style={{ width: '100%', padding: 9, borderRadius: 4, border: '1px solid #eee', background: colors.inp, marginBottom: 15, resize: 'none', fontSize: 13, fontFamily: 'inherit' }}
              required
            />
            <div style={{ display: 'flex', gap: 12, marginBottom: 15 }}>
              <div style={{ flex: 1 }}>
                <div style={{ color: colors.d_gray, fontWeight: 600, fontSize: 15, marginBottom: 9 }}>Date</div>
                <input
                  name="date"
                  type="date"
                  value={form.date}
                  onChange={handleInputChange}
                  placeholder="MM/DD/YYYY"
                  style={{  width: '100%', padding: 9, borderRadius: 4, border: '1px solid #eee', background: colors.inp, fontSize: 13, fontFamily: 'inherit' }}
                  required
                />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ color: colors.d_gray, fontWeight: 600, fontSize: 15, marginBottom: 9 }}>Time</div>
                <input
                  name="time"
                  type="time"
                  value={form.time}
                  onChange={handleInputChange}
                  style={{  width: '100%', padding: 9, borderRadius: 4, border: '1px solid #eee', background: colors.inp, fontSize: 13, fontFamily: 'inherit' }}
                  required
                />
              </div>
              <div style={{ flex: 2 }}>
                <div style={{ color: colors.d_gray, fontWeight: 600, fontSize: 15, marginBottom: 9 }}>Location</div>
                <input
                  name="location"
                  value={form.location}
                  onChange={handleInputChange}
                  placeholder="Location"
                  style={{ width: '100%', padding: 9, borderRadius: 4, border: '1px solid #eee', background: colors.inp, fontSize: 13, fontFamily: 'inherit' }}
                  required
                />
              </div>
            </div>
            <div style={{ color: colors.d_gray, fontWeight: 600, fontSize: 15, marginBottom: 9 }}>Event Photo</div>
            <input
              name="photo"
              type="file"
              accept="image/*"
              onChange={handleInputChange}
              style={{ marginBottom: 15 }}
              required
            />
            <div>
              <button
                onClick={handleCreateEvent}
                style={{ background: colors.main, color: '#fff', border: 'none', borderRadius: 4, padding: '9px 24px', fontSize: 12, cursor: 'pointer' }}
              >
                Create Event
              </button>
            </div>
          </div>
          {/* Barrier */}
          <div style={{ width: '100%', height: 2, background: colors.secondary, borderRadius: 2, margin: '24px 0 24px 0' }} />
          {/* Event List */}
          <div style={{ background: '#fff', borderRadius: 9, boxShadow: '0 2px 8px #0001', padding: 24 }}>
            <div style={{ color: colors.d_gray, fontWeight: 700, fontSize: 16, marginBottom: 18 }}>Event List</div>
            {events.map((event) => (
              <div key={event.id} style={{ marginBottom: 18, padding: 15, borderRadius: 6, background: '#F6F6F6', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ color: colors.d_gray, fontWeight: 600, fontSize: 13 }}>{event.title}</div>
                  <div style={{ color: colors.d_gray, fontSize: 11, margin: '4px 0' }}>Date: {event.date} | Time: {formatTime12Hour(event.time)}</div>
                  <div style={{ color: colors.d_gray, fontSize: 11 }}>Location: {event.location}</div>
                </div>
                <div style={{ display: 'flex', gap: 6 }}>
                  <button
                    style={{ ...actionButtonStyle, background: colors.view }}
                    onMouseEnter={e => e.target.style.backgroundColor = '#6aa3d9'}
                    onMouseLeave={e => e.target.style.backgroundColor = colors.view}
                    onClick={() => handleView(event)}
                  >
                    View
                  </button>
                  <button
                    style={{ ...actionButtonStyle, background: '#6c757d' }}
                    onMouseEnter={e => e.target.style.backgroundColor = '#5a6268'}
                    onMouseLeave={e => e.target.style.backgroundColor = '#6c757d'}
                    onClick={() => handleEdit(event)}
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDeleteClick(event)}
                    style={{ ...actionButtonStyle, background: colors.delete }}
                    onMouseEnter={e => e.target.style.backgroundColor = '#c82333'}
                    onMouseLeave={e => e.target.style.backgroundColor = colors.delete}
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      {/* Delete Modal */}
      <DeleteModal
        visible={showDeleteModal}
        onClose={handleDeleteCancel}
        onConfirm={handleDeleteConfirm}
        title={eventToDelete ? `Are you sure you want to delete the event "${eventToDelete.title}"?` : "Are you sure you want to delete this event?"}
        confirmText="Delete"
        cancelText="Cancel"
      />

      {/* Edit Modal */}
      {showEditModal && (
        <div style={editModalStyles.overlay}>
          <div style={editModalStyles.modalContainer}>
            {/* Close button */}
            <button style={editModalStyles.closeButton} onClick={handleCloseEditModal}>
              <span style={editModalStyles.closeButtonText}>×</span>
            </button>
            
            {/* Modal content */}
            <div style={editModalStyles.content}>
              <h3 style={editModalStyles.title}>Edit Event Details</h3>
              
              <div style={editModalStyles.formContainer}>
                {/* Left Column */}
                <div style={editModalStyles.leftColumn}>
                  <div style={editModalStyles.inputGroup}>
                    <label style={editModalStyles.label}>Title</label>
                    <input
                      name="title"
                      value={editForm.title}
                      onChange={handleEditInputChange}
                      style={editModalStyles.input}
                      required
                    />
                  </div>
                  
                  <div style={editModalStyles.inputGroup}>
                    <label style={editModalStyles.label}>Time</label>
                    <input
                      name="time"
                      type="time"
                      value={editForm.time}
                      onChange={handleEditInputChange}
                      style={editModalStyles.input}
                      required
                    />
                  </div>
                  
                  <div style={editModalStyles.inputGroup}>
                    <label style={editModalStyles.label}>Image Upload</label>
                    <input
                      name="photo"
                      type="file"
                      accept="image/*"
                      onChange={handleEditInputChange}
                      style={editModalStyles.fileInput}
                    />
                  </div>
                  
                  <div style={editModalStyles.inputGroup}>
                    <label style={editModalStyles.label}>Description</label>
                    <textarea
                      name="description"
                      value={editForm.description}
                      onChange={handleEditInputChange}
                      rows={4}
                      style={editModalStyles.textarea}
                      required
                    />
                  </div>
                </div>
                
                {/* Right Column */}
                <div style={editModalStyles.rightColumn}>
                  <div style={editModalStyles.inputGroup}>
                    <label style={editModalStyles.label}>Date</label>
                    <input
                      name="date"
                      type="date"
                      value={editForm.date}
                      onChange={handleEditInputChange}
                      style={editModalStyles.input}
                      required
                    />
                  </div>
                  
                  <div style={editModalStyles.inputGroup}>
                    <label style={editModalStyles.label}>Location</label>
                    <input
                      name="location"
                      value={editForm.location}
                      onChange={handleEditInputChange}
                      style={editModalStyles.input}
                      required
                    />
                  </div>
                </div>
              </div>
              
              {/* Save Changes Button */}
              <div style={editModalStyles.buttonContainer}>
                <button style={editModalStyles.saveButton} onClick={handleSaveChanges}>
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* View Modal (copied and adapted from Approved.js) */}
      {showViewModal && viewingEvent && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 1000,
        }}>
          <div style={{
            backgroundColor: 'white',
            borderRadius: '10px',
            padding: '20px',
            margin: '20px',
            width: '500px',
            maxWidth: '90vw',
            position: 'relative',
            border: '1px solid #e0e0e0',
            boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)'
          }}>
            {/* Close button */}
            <button style={{
              position: 'absolute',
              top: '10px',
              right: '10px',
              background: 'none',
              border: 'none',
              fontSize: '24px',
              color: colors.d_gray,
              fontWeight: 'bold',
              padding: 0,
              width: '30px',
              height: '30px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
            }} onClick={handleCloseViewModal}>
              <span style={{lineHeight: 1}}>×</span>
            </button>
                         {/* Modal content */}
             <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', width: '100%'}}>
                               <h3 style={{fontSize: '18px', color: colors.main, textAlign: 'left', marginBottom: '20px', fontWeight: 'bold', margin: '0 0 20px 0', alignSelf: 'flex-start', fontFamily: 'Inter, sans-serif'}}>View Event</h3>
               {/* Photo display area */}
               <div style={{width: '100%', marginBottom: '20px', position: 'relative'}}>
                 {viewingEvent.photo ? (
                   <img 
                     src={typeof viewingEvent.photo === 'string' ? viewingEvent.photo : URL.createObjectURL(viewingEvent.photo)}
                     alt="Event Photo"
                     style={{width: '100%', height: '300px', objectFit: 'cover', borderRadius: '8px', border: '1px solid #e0e0e0'}}
                   />
                 ) : (
                   <div style={{width: '100%', height: '300px', backgroundColor: '#f5f5f5', borderRadius: '8px', border: '2px dashed #d0d0d0', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column'}}>
                     <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#666'}}>
                       <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                         <path d="M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM19 19H5V5H19V19Z" fill="#666"/>
                         <path d="M14.14 11.86L11 15L9 13L6 16H18L14.14 11.86Z" fill="#666"/>
                       </svg>
                     </div>
                   </div>
                 )}
               </div>
                               {/* Event Title */}
                <div style={{width: '100%', marginBottom: '20px'}}>
                  <h4 style={{fontSize: '16px', color: colors.d_gray, fontWeight: 'bold', margin: '0 0 10px 0', fontFamily: 'Inter, sans-serif', textAlign: 'center'}}>{viewingEvent.title}</h4>
                </div>
              {/* Event Details */}
              <div style={{width: '100%', display: 'flex', flexDirection: 'column', gap: '15px'}}>
                <div style={{display: 'flex', alignItems: 'flex-start', gap: '10px'}}>
                  <span style={{fontSize: '14px', fontWeight: 600, color: colors.d_gray, minWidth: '80px', fontFamily: 'Inter, sans-serif'}}>Description:</span>
                  <span style={{fontSize: '14px', color: '#333', flex: 1, lineHeight: '1.5', fontFamily: 'Inter, sans-serif', wordBreak: 'break-word', overflowWrap: 'break-word'}}>{viewingEvent.description || 'No description available.'}</span>
                </div>
                <div style={{display: 'flex', alignItems: 'flex-start', gap: '10px'}}>
                  <span style={{fontSize: '14px', fontWeight: 600, color: colors.d_gray, minWidth: '80px', fontFamily: 'Inter, sans-serif'}}>Date:</span>
                  <span style={{fontSize: '14px', color: '#333', flex: 1, lineHeight: '1.5', fontFamily: 'Inter, sans-serif'}}>{viewingEvent.date}</span>
                </div>
                <div style={{display: 'flex', alignItems: 'flex-start', gap: '10px'}}>
                  <span style={{fontSize: '14px', fontWeight: 600, color: colors.d_gray, minWidth: '80px', fontFamily: 'Inter, sans-serif'}}>Time:</span>
                  <span style={{fontSize: '14px', color: '#333', flex: 1, lineHeight: '1.5', fontFamily: 'Inter, sans-serif'}}>{formatTime12Hour(viewingEvent.time)}</span>
                </div>
                <div style={{display: 'flex', alignItems: 'flex-start', gap: '10px'}}>
                  <span style={{fontSize: '14px', fontWeight: 600, color: colors.d_gray, minWidth: '80px', fontFamily: 'Inter, sans-serif'}}>Location:</span>
                  <span style={{fontSize: '14px', color: '#333', flex: 1, lineHeight: '1.5', fontFamily: 'Inter, sans-serif'}}>{viewingEvent.location}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CHK_EventsDisplay;