import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { colors } from '../../utils/colors';
import { FaUserCircle, FaHome, FaUsers, FaUsersCog, FaCalendarAlt, FaClipboardList, FaCalendarCheck, FaList } from "react-icons/fa";
import { LuListVideo } from "react-icons/lu";
import { IoScaleSharp } from "react-icons/io5";
import { CiLogout } from "react-icons/ci";
import { FaChevronRight, FaChevronLeft } from "react-icons/fa";

const CHK_Dashboard = ({ onLogout }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    onLogout();
  };

  // Inline styles object
  const styles = {
    container: {
      display: 'flex',
      flexDirection: 'row',
      height: '100vh',
      backgroundColor: '#FEFFFD',
      overflow: 'auto',
    },
    sidebar: {
      backgroundColor: '#F1F1F2',
      padding: '17px 15px',
      width: isCollapsed ? '80px' : '230px',
      transition: 'width 0.3s ease, padding 0.3s ease',
      display: 'flex',
      flexDirection: 'column',
    },
    brand: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '15px',
      padding: isCollapsed ? '0' : '0 10px',
      justifyContent: isCollapsed ? 'center' : 'flex-start',
    },
    brandIcon: {
      width: '47px',
      height: '40px',
    },
    brandText: {
      fontSize: '25px',
      color: colors.d_gray,
      fontWeight: 'bold',
      fontStyle: 'italic',
      marginLeft: '15px',
    },
    menuContainer: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
    },
    menuGroup: {
      marginBottom: '20px',
    },
    menuDivider: {
      height: '1px',
      backgroundColor: '#e0e0e0',
      marginBottom: '15px',
    },
    menuItem: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemActive: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'rgba(159, 192, 59, 0.2)',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemCollapsed: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '12px 8px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuIcon: {
      fontSize: '20px',
      marginRight: isCollapsed ? '0' : '12px',
      color: colors.main,
      display: 'flex',
      alignItems: 'center',
    },
    menuText: {
      fontSize: '14px',
      color: colors.d_gray,
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    menuTextActive: {
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '600',
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    logoutButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#fff',
      border: 'none',
      borderRadius: '30px',
      padding: isCollapsed ? '2px 3px' : '7px 12px',
      marginTop: '20px',
      marginBottom: '10px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      width: isCollapsed ? 'auto' : 'fit-content',
      alignSelf: 'center',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
    },
    logoutIcon: {
      background: 'none',
      fontSize: '18px',
      marginRight: isCollapsed ? '0' : '8px',
      display: 'flex',
      alignItems: 'center',
      color: colors.main,
    },
    logoutText: {
      background: 'none',
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '500',
    },
    mainContent: {
      flex: 1,
      backgroundColor: '#FEFFFD',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '30px',
    },
    collapseButton: {
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      fontSize: '10px',
      color: colors.l_gray,
      transition: 'background-color 0.2s ease',
      marginLeft: '-10px'
    },
    greeting: {
      fontSize: '28px',
      fontWeight: 'bold',
      color: colors.main,
      marginBottom: '20px',
    },
    profileButton: {
      color: colors.main,      
      marginTop: '5px',
      marginRight: '5px',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontSize: '32px',
    },
    contentScrollView: {
      flex: 1,
      overflowY: 'auto',
    },
    contentArea: {
      flex: 1,
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      minHeight: '400px',
    },
    placeholderText: {
      fontSize: '16px',
      color: '#999',
    },
  };

  const menuItems = [
    { name: 'Dashboard', icon: <FaHome />, active: true },
    { name: 'User Management', icon: <FaUsers /> },
    { name: 'Admin Management', icon: <FaUsersCog /> },
    { name: 'Workout Videos', icon: <LuListVideo /> },
    { name: 'Events Display', icon: <FaCalendarAlt /> },
    { name: 'Activity Logs', icon: <FaClipboardList /> },
    { name: 'Appointments', icon: <FaCalendarCheck /> },
    { name: 'Fitness Plans', icon: <FaList /> },
    { name: 'Measurements', icon: <IoScaleSharp /> },
  ];

  const renderMenuItem = (item, index) => {
    const menuItemStyle = item.active 
      ? (isCollapsed ? styles.menuItemCollapsed : styles.menuItemActive)
      : (isCollapsed ? styles.menuItemCollapsed : styles.menuItem);
    
    const menuTextStyle = item.active ? styles.menuTextActive : styles.menuText;

    const handleMenuClick = () => {
      console.log(`Clicked: ${item.name}`);
      // Add navigation logic here based on the menu item
      switch(item.name) {
        case 'User Management':
          navigate('/user-management');
          break;
        case 'Admin Management':
          navigate('/admin-management');
          break;
        case 'Workout Videos':
          navigate('/workout-videos');
          break;
        case 'Events Display':
          navigate('/events-display');
          break;
        case 'Activity Logs':
          navigate('/activity-logs');
          break;
        case 'Appointments':
          navigate('/appointments');
          break;
        case 'Fitness Plans':
          navigate('/fitness-plans');
          break;
        case 'Measurements':
          navigate('/measurements');
          break;
        default:
          console.log('Dashboard clicked');
      }
    };

    return (
      <button
        key={index}
        style={menuItemStyle}
        onClick={handleMenuClick}
        onMouseEnter={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'rgba(159, 192, 59, 0.1)';
          }
        }}
        onMouseLeave={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'transparent';
          }
        }}
      >
        <span style={styles.menuIcon}>{item.icon}</span>
        {!isCollapsed && (
          <span style={menuTextStyle}>
            {item.name}
          </span>
        )}
      </button>
    );
  };

  return (
    <div style={styles.container}>
      {/* Sidebar */}
      <div style={styles.sidebar}>
        {/* Brand */}
        <div style={styles.brand}>
          <img 
            src="/fnw1.png" 
            alt="FitNWell Logo"
            style={styles.brandIcon}
          />
          {!isCollapsed && (
            <span style={styles.brandText}>FitNWell</span>
          )}
        </div>

        {/* Menu Items */}
        <div style={styles.menuContainer}>
          <div style={styles.menuDivider} />
          
          <div style={styles.menuGroup}>
            {menuItems.slice(0, 6).map((item, index) => renderMenuItem(item, index))}
          </div>
          
          <div style={styles.menuDivider} />
          
          <div style={styles.menuGroup}>
            {menuItems.slice(6).map((item, index) => renderMenuItem(item, index + 6))}
          </div>
        </div>

        {/* Logout Button */}
        <button 
          style={styles.logoutButton}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#f5f5f5';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#fff';
          }}
          onClick={handleLogout}
        >
          <span style={styles.logoutIcon}><CiLogout /></span>
          {!isCollapsed && (
            <span style={styles.logoutText}>Log Out</span>
          )}
        </button>
      </div>

      {/* Main Content */}
      <div style={styles.mainContent}>
        {/* Header */}
        <div style={styles.header}>
          <button 
            style={styles.collapseButton}
            onClick={() => setIsCollapsed(!isCollapsed)}
          >
            {isCollapsed ? <FaChevronRight /> : <FaChevronLeft />}
          </button>
          <span style={styles.greeting}>Hello, Admin!</span>
          <button 
          style={styles.profileButton}
          onClick={() => navigate('/user-profile')}
          >
            <FaUserCircle />
          </button>
        </div>

        {/* Content Area */}
        <div style={styles.contentScrollView}>
          <div style={styles.contentArea}>
            <span style={styles.placeholderText}>
              Dashboard content will appear here
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CHK_Dashboard; 