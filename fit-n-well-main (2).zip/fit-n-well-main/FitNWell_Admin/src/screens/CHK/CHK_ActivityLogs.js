import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { colors } from '../../utils/colors';
import { FaUserCircle, FaHome, FaUsers, FaUsersCog, FaCalendarAlt, FaClipboardList, FaCalendarCheck, FaList, FaSearch, FaEdit, FaTrash, FaEye } from "react-icons/fa";
import { LuListVideo } from "react-icons/lu";
import { IoScaleSharp } from "react-icons/io5";
import { CiLogout } from "react-icons/ci";
import { FaChevronRight, FaChevronLeft } from "react-icons/fa";
import DeleteModal from '../../components/DeleteModal';
import PhotoProofModal from '../../components/PhotoProofModal';
import Approved from '../../components/Approved';
import Rejected from '../../components/Rejected';

const CHK_ActivityLogs = ({ onLogout }) => {
  const navigate = useNavigate();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState('All');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showPhotoModal, setShowPhotoModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedActivity, setSelectedActivity] = useState(null);
  const [activityToDelete, setActivityToDelete] = useState(null);
  const [showRejectedModal, setShowRejectedModal] = useState(false);

  // Sample activity data
  const [activities, setActivities] = useState([
    {
      id: 1,
      name: "Jester Pascual",
      activity: "Pickle Ball",
      dateTime: "May 26, 2025 - 5:30 PM",
      proof: "https://example.com/proof1.jpg",
      status: "Approved"
    },
    {
      id: 2,
      name: "Marie Cordera",
      activity: "Basketball",
      dateTime: "April 07, 2025 - 1:27 PM",
      proof: "https://example.com/proof2.jpg",
      status: "Approved"
    },
    {
      id: 3,
      name: "Jameson Aguire",
      activity: "Volleyball",
      dateTime: "April 16, 2025 - 10:30 AM",
      proof: "https://example.com/proof3.jpg",
      status: "Rejected"
    },
    {
      id: 4,
      name: "Joma Lyn Trese",
      activity: "Basketball",
      dateTime: "May 13, 2025 - 9:39 AM",
      proof: "https://example.com/proof4.jpg",
      status: "Pending"
    }
  ]);

  // Filter options
  const filterOptions = ['All', 'Running', 'Video Activity', 'Others'];

  // Delete modal handlers
  const handleDeleteClick = (activity) => {
    setActivityToDelete(activity);
    setShowDeleteModal(true);
  };

  const handleDeleteConfirm = () => {
    if (activityToDelete) {
      setActivities(activities.filter(a => a.id !== activityToDelete.id));
      console.log('Deleted activity:', activityToDelete.name);
    }
    setShowDeleteModal(false);
    setActivityToDelete(null);
  };

  const handleDeleteCancel = () => {
    setShowDeleteModal(false);
    setActivityToDelete(null);
  };

  // Photo proof modal handlers
  const handleViewProof = (activity) => {
    setSelectedActivity(activity);
    if (activity.status === 'Approved') {
      setShowDetailModal(true);
    } else if (activity.status === 'Rejected') {
      setShowRejectedModal(true);
    } else {
      setShowPhotoModal(true);
    }
  };

  const handleApprove = () => {
    if (selectedActivity) {
      setActivities(activities.map(a => 
        a.id === selectedActivity.id 
          ? { ...a, status: 'Approved' }
          : a
      ));
    }
    setShowPhotoModal(false);
    setSelectedActivity(null);
  };

  const handleReject = (reason) => {
    if (selectedActivity) {
      setActivities(activities.map(a => 
        a.id === selectedActivity.id 
          ? { ...a, status: 'Rejected', rejectionReason: reason }
          : a
      ));
    }
    setShowPhotoModal(false);
    setSelectedActivity(null);
  };

  // Filter activities based on search term and active filter
  const filteredActivities = activities.filter(activity => {
    const matchesSearch = 
      activity.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      activity.activity.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = activeFilter === 'All' || activity.activity === activeFilter;
    
    return matchesSearch && matchesFilter;
  });

  // Get status button style
  const getStatusStyle = (status) => {
    switch (status) {
      case 'Approved':
        return {
          backgroundColor: colors.verified,
          color: 'white'
        };
      case 'Rejected':
        return {
          backgroundColor: colors.delete,
          color: 'white'
        };
      case 'Pending':
        return {
          backgroundColor: colors.rejected,
          color: 'white'
        };
      default:
        return {
          backgroundColor: colors.l_gray,
          color: 'white'
        };
    }
  };

  // Inline styles object
  const styles = {
    container: {
      display: 'flex',
      flexDirection: 'row',
      height: '100vh',
      backgroundColor: '#FEFFFD',
      overflow: 'auto',
    },
    sidebar: {
      backgroundColor: '#F1F1F2',
      padding: '17px 15px',
      width: isCollapsed ? '80px' : '230px',
      transition: 'width 0.3s ease, padding 0.3s ease',
      display: 'flex',
      flexDirection: 'column',
    },
    brand: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '15px',
      padding: isCollapsed ? '0' : '0 10px',
      justifyContent: isCollapsed ? 'center' : 'flex-start',
    },
    brandIcon: {
      width: '47px',
      height: '40px',
    },
    brandText: {
      fontSize: '25px',
      color: colors.d_gray,
      fontWeight: 700,
      fontStyle: 'italic',
      marginLeft: '15px',
      fontFamily: 'Inter, sans-serif',
    },
    menuContainer: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
    },
    menuGroup: {
      marginBottom: '20px',
    },
    menuDivider: {
      height: '1px',
      backgroundColor: '#e0e0e0',
      marginBottom: '15px',
    },
    menuItem: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemActive: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'rgba(159, 192, 59, 0.2)',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemCollapsed: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '12px 8px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuIcon: {
      fontSize: '20px',
      marginRight: isCollapsed ? '0' : '12px',
      color: colors.main,
      display: 'flex',
      alignItems: 'center',
    },
    menuText: {
      fontSize: '14px',
      color: colors.d_gray,
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    menuTextActive: {
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '600',
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    logoutButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#fff',
      border: 'none',
      borderRadius: '30px',
      padding: isCollapsed ? '2px 3px' : '7px 12px',
      marginTop: '20px',
      marginBottom: '10px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      width: isCollapsed ? 'auto' : 'fit-content',
      alignSelf: 'center',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
    },
    logoutIcon: {
      background: 'none',
      fontSize: '18px',
      marginRight: isCollapsed ? '0' : '8px',
      display: 'flex',
      alignItems: 'center',
      color: colors.main,
    },
    logoutText: {
      background: 'none',
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '500',
    },
    mainContent: {
      flex: 1,
      backgroundColor: '#FEFFFD',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '30px',
    },
    collapseButton: {
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      fontSize: '10px',
      color: colors.l_gray,
      transition: 'background-color 0.2s ease',
      marginLeft: '-10px'
    },
    pageTitle: {
      fontSize: '28px',
      fontWeight: 'bold',
      color: colors.main,
      marginBottom: '20px',
    },
    profileButton: {
      color: colors.main,      
      marginTop: '5px',
      marginRight: '5px',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontSize: '32px',
    },
    searchContainer: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '20px',
      gap: '15px',
    },
    searchBox: {
      display: 'flex',
      alignItems: 'center',
      backgroundColor: '#fff',
      border: '1px solid #e0e0e0',
      borderRadius: '8px',
      padding: '10px 15px',
      flex: 1,
      maxWidth: '400px',
    },
    searchIcon: {
      color: '#999',
      marginRight: '10px',
      fontSize: '16px',
    },
    searchInput: {
      border: 'none',
      outline: 'none',
      flex: 1,
      fontSize: '14px',
      color: '#333',
    },
    filterContainer: {
      display: 'flex',
      gap: '10px',
      marginBottom: '20px',
    },
    filterButton: {
      backgroundColor: '#fff',
      color: colors.d_gray,
      border: '1px solid #e0e0e0',
      borderRadius: '6px',
      padding: '10px 20px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '500',
      transition: 'all 0.2s ease',
    },
    filterButtonActive: {
      backgroundColor: colors.l_gray,
      color: '#fff',
      border: '1px solid ' + colors.l_gray,
      borderRadius: '6px',
      padding: '8px 16px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '600',
      transition: 'all 0.2s ease',
    },
    tableContainer: {
      backgroundColor: '#fff',
      borderRadius: '8px',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
      overflow: 'hidden',
    },
    table: {
      width: '100%',
      borderCollapse: 'collapse',
    },
    tableHeader: {
      backgroundColor: '#f8f9fa',
      borderBottom: '1px solid #e0e0e0',
    },
    tableHeaderCell: {
      padding: '15px 12px',
      textAlign: 'left',
      fontSize: '14px',
      fontWeight: '600',
      color: '#333',
      borderBottom: '1px solid #e0e0e0',
    },
    tableRow: {
      borderBottom: '1px solid #f0f0f0',
    },
    tableRowHover: {
      backgroundColor: '#f8f9fa',
    },
    tableCell: {
      padding: '12px',
      fontSize: '14px',
      color: '#333',
      borderBottom: '1px solid #f0f0f0',
    },
    actionButtons: {
      display: 'flex',
      gap: '6px',
    },
    viewButton: {
      backgroundColor: colors.view,
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '4px 8px',
      cursor: 'pointer',
      fontSize: '11px',
      transition: 'background-color 0.2s ease',
    },
    statusButton: {
      border: 'none',
      borderRadius: '12px',
      width: '15px',
      padding: '4px 12px',
      fontSize: '11px',
      color: '#fff',
    },
    deleteButton: {
      backgroundColor: colors.delete,
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '4px 8px',
      cursor: 'pointer',
      fontSize: '11px',
      transition: 'background-color 0.2s ease',
    },
  };

  const menuItems = [
    { name: 'Dashboard', icon: <FaHome />, active: false, route: '/chk-dashboard' },
    { name: 'User Management', icon: <FaUsers />, active: false, route: '/user-management' },
    { name: 'Admin Management', icon: <FaUsersCog />, route: '/admin-management' },
    { name: 'Workout Videos', icon: <LuListVideo />, route: '/workout-videos' },
    { name: 'Events Display', icon: <FaCalendarAlt />, route: '/events-display' },
    { name: 'Activity Logs', icon: <FaClipboardList />, active: true, route: '/activity-logs' },
    { name: 'Appointments', icon: <FaCalendarCheck />, route: '/appointments' },
    { name: 'Fitness Plans', icon: <FaList />, route: '/fitness-plans' },
    { name: 'Measurements', icon: <IoScaleSharp />, route: '/measurements' },
  ];

  const renderMenuItem = (item, index) => {
    const menuItemStyle = item.active 
      ? (isCollapsed ? styles.menuItemCollapsed : styles.menuItemActive)
      : (isCollapsed ? styles.menuItemCollapsed : styles.menuItem);
    
    const menuTextStyle = item.active ? styles.menuTextActive : styles.menuText;

    return (
      <button
        key={index}
        style={menuItemStyle}
        onClick={() => {
          if (item.route) {
            navigate(item.route);
          }
        }}
        onMouseEnter={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'rgba(159, 192, 59, 0.1)';
          }
        }}
        onMouseLeave={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'transparent';
          }
        }}
      >
        <span style={styles.menuIcon}>{item.icon}</span>
        {!isCollapsed && (
          <span style={menuTextStyle}>
            {item.name}
          </span>
        )}
      </button>
    );
  };

  return (
    <div style={styles.container}>
      {/* Sidebar */}
      <div style={styles.sidebar}>
        {/* Brand */}
        <div style={styles.brand}>
          <img 
            src="/fnw1.png" 
            alt="FitNWell Logo"
            style={styles.brandIcon}
          />
          {!isCollapsed && (
            <span style={styles.brandText}>FitNWell</span>
          )}
        </div>

        {/* Menu Items */}
        <div style={styles.menuContainer}>
          <div style={styles.menuDivider} />
          
          <div style={styles.menuGroup}>
            {menuItems.slice(0, 6).map((item, index) => renderMenuItem(item, index))}
          </div>
          
          <div style={styles.menuDivider} />
          
          <div style={styles.menuGroup}>
            {menuItems.slice(6).map((item, index) => renderMenuItem(item, index + 6))}
          </div>
        </div>

        {/* Logout Button */}
        <button 
          style={styles.logoutButton}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#f5f5f5';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#fff';
          }}
          onClick={onLogout}
        >
          <span style={styles.logoutIcon}><CiLogout /></span>
          {!isCollapsed && (
            <span style={styles.logoutText}>Log Out</span>
          )}
        </button>
      </div>

      {/* Main Content */}
      <div style={styles.mainContent}>
        {/* Header */}
        <div style={styles.header}>
          <button 
            style={styles.collapseButton}
            onClick={() => setIsCollapsed(!isCollapsed)}
          >
            {isCollapsed ? <FaChevronRight /> : <FaChevronLeft />}
          </button>
          <span style={styles.pageTitle}>Activity Logs</span>
          <button style={styles.profileButton}
          onClick={() => navigate('/user-profile')}
          >
            <FaUserCircle />
          </button>
        </div>

        {/* Search */}
        <div style={styles.searchContainer}>
          <div style={styles.searchBox}>
            <FaSearch style={styles.searchIcon} />
            <input
              type="text"
              placeholder="Search user or activity"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={styles.searchInput}
            />
          </div>
        </div>

        {/* Filter Buttons */}
        <div style={styles.filterContainer}>
          {filterOptions.map((filter) => (
            <button
              key={filter}
              style={activeFilter === filter ? styles.filterButtonActive : styles.filterButton}
              onClick={() => setActiveFilter(filter)}
            >
              {filter}
            </button>
          ))}
        </div>

        {/* Activity Table */}
        <div style={styles.tableContainer}>
          <table style={styles.table}>
            <thead style={styles.tableHeader}>
              <tr>
                <th style={styles.tableHeaderCell}>ID</th>
                <th style={styles.tableHeaderCell}>Name</th>
                <th style={styles.tableHeaderCell}>Activity</th>
                <th style={styles.tableHeaderCell}>Date and Time</th>
                <th style={styles.tableHeaderCell}>Proof</th>
                <th style={styles.tableHeaderCell}>Status</th>
                <th style={styles.tableHeaderCell}>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredActivities.map((activity, index) => (
                <tr 
                  key={activity.id} 
                  style={styles.tableRow}
                  onMouseEnter={(e) => {
                    e.target.parentElement.style.backgroundColor = '#f8f9fa';
                  }}
                  onMouseLeave={(e) => {
                    e.target.parentElement.style.backgroundColor = 'transparent';
                  }}
                >
                  <td style={styles.tableCell}>{activity.id}</td>
                  <td style={styles.tableCell}>{activity.name}</td>
                  <td style={styles.tableCell}>{activity.activity}</td>
                  <td style={styles.tableCell}>{activity.dateTime}</td>
                  <td style={styles.tableCell}>
                    <button 
                      style={styles.viewButton}
                      onClick={() => handleViewProof(activity)}
                      onMouseEnter={(e) => {
                        e.target.style.backgroundColor = '#6aa3d9';
                      }}
                      onMouseLeave={(e) => {
                        e.target.style.backgroundColor = colors.view;
                      }}
                    >
                      View
                    </button>
                  </td>
                  <td style={styles.tableCell}>
                    <span style={{...styles.statusButton, ...getStatusStyle(activity.status)}}>
                      {activity.status}
                    </span>
                  </td>
                  <td style={styles.tableCell}>
                    <div style={styles.actionButtons}>
                      <button 
                        style={styles.deleteButton}
                        onClick={() => handleDeleteClick(activity)}
                        onMouseEnter={(e) => {
                          e.target.style.backgroundColor = '#c82333';
                        }}
                        onMouseLeave={(e) => {
                          e.target.style.backgroundColor = colors.delete;
                        }}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Modal */}
      <DeleteModal
        visible={showDeleteModal}
        onClose={handleDeleteCancel}
        onConfirm={handleDeleteConfirm}
        title={activityToDelete ? `Are you sure you want to delete this activity log for ${activityToDelete.name}?` : "Are you sure you want to delete this activity log?"}
        confirmText="Delete"
        cancelText="Cancel"
      />

      {/* Photo Proof Modal */}
      <PhotoProofModal
        visible={showPhotoModal}
        onClose={() => {
          setShowPhotoModal(false);
          setSelectedActivity(null);
        }}
        onApprove={handleApprove}
        onReject={handleReject}
        photoUrl={selectedActivity?.proof}
      />

      {/* Rejected Modal */}
      <Rejected
        visible={showRejectedModal}
        onClose={() => {
          setShowRejectedModal(false);
          setSelectedActivity(null);
        }}
        activity={selectedActivity}
      />

      {/* Activity Detail Modal */}
      <Approved
        visible={showDetailModal}
        onClose={() => {
          setShowDetailModal(false);
          setSelectedActivity(null);
        }}
        activity={selectedActivity}
      />
    </div>
  );
};

export default CHK_ActivityLogs; 