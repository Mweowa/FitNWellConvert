import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { colors } from '../../utils/colors';
import { FaUserCircle, FaHome, FaUsers, FaUsersCog, FaCalendarAlt, FaClipboardList, FaCalendarCheck, FaList } from "react-icons/fa";
import { LuListVideo } from "react-icons/lu";
import { IoScaleSharp } from "react-icons/io5";
import { CiLogout } from "react-icons/ci";
import { FaChevronRight, FaChevronLeft } from "react-icons/fa";
import { MdPlayCircleOutline } from "react-icons/md";
import DeleteModal from '../../components/DeleteModal';

const CHK_WorkoutVideos = ({ onLogout }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const navigate = useNavigate();
  const [videos, setVideos] = useState([
    {
      id: 1,
      title: 'Chair Basics for Beginners',
      category: 'Chair Exercise',
      duration: '15 mins',
      description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
      videoFile: null,
    },
    {
      id: 2,
      title: 'Warm-Up Routine',
      category: 'Warm-Up',
      duration: '10 mins',
      description: 'A comprehensive warm-up routine to prepare your body for exercise.',
      videoFile: null,
    },
  ]);
  const [form, setForm] = useState({
    title: '',
    category: '',
    description: '',
    videoFile: null,
  });
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [videoToDelete, setVideoToDelete] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingVideo, setEditingVideo] = useState(null);
  const [editForm, setEditForm] = useState({
    title: '',
    category: '',
    description: '',
    videoFile: null,
  });
  const [showViewModal, setShowViewModal] = useState(false);
  const [viewingVideo, setViewingVideo] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = ['All', 'Chair', 'Warm-Up', 'Cool Down', 'Cardio', 'Flexibility', 'Strength', 'Balance'];

  const styles = {
    container: {
      display: 'flex',
      flexDirection: 'row',
      height: '100vh',
      backgroundColor: '#FEFFFD',
      overflow: 'auto',
    },
    sidebar: {
      backgroundColor: '#F1F1F2',
      padding: '17px 15px',
      width: isCollapsed ? '80px' : '230px',
      transition: 'width 0.3s ease, padding 0.3s ease',
      display: 'flex',
      flexDirection: 'column',
    },
    brand: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '15px',
      padding: isCollapsed ? '0' : '0 10px',
      justifyContent: isCollapsed ? 'center' : 'flex-start',
    },
    brandIcon: {
      width: '47px',
      height: '40px',
    },
    brandText: {
      fontSize: '25px',
      color: colors.d_gray,
      fontWeight: 700,
      fontStyle: 'italic',
      marginLeft: '15px',
      fontFamily: 'Inter, sans-serif',
    },
    menuContainer: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
    },
    menuGroup: {
      marginBottom: '20px',
    },
    menuDivider: {
      height: '1px',
      backgroundColor: '#e0e0e0',
      marginBottom: '15px',
    },
    menuItem: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemActive: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'rgba(159, 192, 59, 0.2)',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemCollapsed: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '12px 8px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuIcon: {
      fontSize: '20px',
      marginRight: isCollapsed ? '0' : '12px',
      color: colors.main,
      display: 'flex',
      alignItems: 'center',
    },
    menuText: {
      fontSize: '14px',
      color: colors.d_gray,
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    menuTextActive: {
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '600',
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    logoutButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#fff',
      border: 'none',
      borderRadius: '30px',
      padding: isCollapsed ? '2px 3px' : '7px 12px',
      marginTop: '20px',
      marginBottom: '10px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      width: isCollapsed ? 'auto' : 'fit-content',
      alignSelf: 'center',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
    },
    logoutIcon: {
      background: 'none',
      fontSize: '18px',
      marginRight: isCollapsed ? '0' : '8px',
      display: 'flex',
      alignItems: 'center',
      color: colors.main,
    },
    logoutText: {
      background: 'none',
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '500',
    },
    mainContent: {
      flex: 1,
      backgroundColor: '#FEFFFD',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '30px',
    },
    collapseButton: {
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      fontSize: '10px',
      color: colors.l_gray,
      transition: 'background-color 0.2s ease',
      marginLeft: '-10px'
    },
    pageTitle: {
      fontSize: '28px',
      fontWeight: 'bold',
      color: colors.main,
      marginBottom: '20px',
    },
    profileButton: {
      color: colors.main,      
      marginTop: '5px',
      marginRight: '5px',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontSize: '32px',
    },
    contentScrollView: {
      flex: 1,
      overflowY: 'auto',
    },
  };

  const menuItems = [
    { name: 'Dashboard', icon: <FaHome />, active: false, route: '/chk-dashboard' },
    { name: 'User Management', icon: <FaUsers />, active: false, route: '/user-management' },
    { name: 'Admin Management', icon: <FaUsersCog />, route: '/admin-management' },
    { name: 'Workout Videos', icon: <LuListVideo />, active: true, route: '/workout-videos' },
    { name: 'Events Display', icon: <FaCalendarAlt />, active: false, route: '/events-display' },
    { name: 'Activity Logs', icon: <FaClipboardList />, active: false, route: '/activity-logs' },
    { name: 'Appointments', icon: <FaCalendarCheck />, route: '/appointments' },
    { name: 'Fitness Plans', icon: <FaList />, route: '/fitness-plans' },
    { name: 'Measurements', icon: <IoScaleSharp />, route: '/measurements' },
  ];

  const renderMenuItem = (item, index) => {
    const menuItemStyle = item.active 
      ? (isCollapsed ? styles.menuItemCollapsed : styles.menuItemActive)
      : (isCollapsed ? styles.menuItemCollapsed : styles.menuItem);
    const menuTextStyle = item.active ? styles.menuTextActive : styles.menuText;
    return (
      <button
        key={index}
        style={menuItemStyle}
        onClick={() => {
          if (item.route) {
            navigate(item.route);
          }
        }}
        onMouseEnter={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'rgba(159, 192, 59, 0.1)';
          }
        }}
        onMouseLeave={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'transparent';
          }
        }}
      >
        <span style={styles.menuIcon}>{item.icon}</span>
        {!isCollapsed && (
          <span style={menuTextStyle}>{item.name}</span>
        )}
      </button>
    );
  };

  const handleInputChange = (e) => {
    const { name, value, files } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: files ? files[0] : value,
    }));
  };

  const handleCreateVideo = () => {
    if (!form.title || !form.category || !form.description || !form.videoFile) {
      alert('Please fill in all fields and select a video file.');
      return;
    }
    setVideos([
      ...videos,
      {
        id: Date.now(),
        ...form,
        duration: '15 mins',
      },
    ]);
    setForm({ title: '', category: '', description: '', videoFile: null });
    const fileInput = document.querySelector('input[type="file"]');
    if (fileInput) {
      fileInput.value = '';
    }
  };

  const handleDeleteClick = (video) => {
    setVideoToDelete(video);
    setShowDeleteModal(true);
  };

  const handleDeleteConfirm = () => {
    if (videoToDelete) {
      setVideos(videos.filter(v => v.id !== videoToDelete.id));
    }
    setShowDeleteModal(false);
    setVideoToDelete(null);
  };

  const handleDeleteCancel = () => {
    setShowDeleteModal(false);
    setVideoToDelete(null);
  };

  const handleEdit = (video) => {
    setEditingVideo(video);
    setEditForm({
      title: video.title,
      category: video.category,
      description: video.description,
      videoFile: video.videoFile,
    });
    setShowEditModal(true);
  };

  const handleEditInputChange = (e) => {
    const { name, value, files } = e.target;
    setEditForm((prev) => ({
      ...prev,
      [name]: files ? files[0] : value,
    }));
  };

  const handleSaveChanges = () => {
    if (!editForm.title || !editForm.category || !editForm.description) {
      alert('Please fill in all required fields.');
      return;
    }
    
    setVideos(videos.map(video => 
      video.id === editingVideo.id 
        ? { ...video, ...editForm }
        : video
    ));
    
    setShowEditModal(false);
    setEditingVideo(null);
    setEditForm({ title: '', category: '', description: '', videoFile: null });
  };

  const handleCloseEditModal = () => {
    setShowEditModal(false);
    setEditingVideo(null);
    setEditForm({ title: '', category: '', description: '', videoFile: null });
  };

  const handleView = (video) => {
    setViewingVideo(video);
    setShowViewModal(true);
  };

  const handleCloseViewModal = () => {
    setShowViewModal(false);
    setViewingVideo(null);
  };

  const filteredVideos = selectedCategory === 'All' 
    ? videos 
    : videos.filter(video => video.category === selectedCategory);

  const actionButtonStyle = {
    border: 'none',
    borderRadius: '4px',
    padding: '4px 8px',
    fontSize: '11px',
    cursor: 'pointer',
    color: '#fff',
    transition: 'background-color 0.2s ease',
  };

  const categoryButtonStyle = {
    border: 'none',
    borderRadius: '20px',
    padding: '6px 12px',
    fontSize: '12px',
    cursor: 'pointer',
    marginRight: '8px',
    marginBottom: '8px',
    transition: 'all 0.2s ease',
  };

  return (
    <div style={styles.container}>
      {/* Sidebar */}
      <div style={styles.sidebar}>
        {/* Brand */}
        <div style={styles.brand}>
          <img 
            src="/fnw1.png" 
            alt="FitNWell Logo"
            style={styles.brandIcon}
          />
          {!isCollapsed && (
            <span style={styles.brandText}>FitNWell</span>
          )}
        </div>
        {/* Menu Items */}
        <div style={styles.menuContainer}>
          <div style={styles.menuDivider} />
          <div style={styles.menuGroup}>
            {menuItems.slice(0, 6).map((item, index) => renderMenuItem(item, index))}
          </div>
          <div style={styles.menuDivider} />
          <div style={styles.menuGroup}>
            {menuItems.slice(6).map((item, index) => renderMenuItem(item, index + 6))}
          </div>
        </div>
        {/* Logout Button */}
        <button 
          style={styles.logoutButton}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#f5f5f5';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#fff';
          }}
          onClick={onLogout}
        >
          <span style={styles.logoutIcon}><CiLogout /></span>
          {!isCollapsed && (
            <span style={styles.logoutText}>Log Out</span>
          )}
        </button>
      </div>
      {/* Main Content */}
      <div style={styles.mainContent}>
        {/* Header */}
        <div style={styles.header}>
          <button 
            style={styles.collapseButton}
            onClick={() => setIsCollapsed(!isCollapsed)}
          >
            {isCollapsed ? <FaChevronRight /> : <FaChevronLeft />}
          </button>
          <span style={styles.pageTitle}>Workout Videos</span>
          <button style={styles.profileButton}
          onClick={() => navigate('/user-profile')}
          >
            <FaUserCircle />
          </button>
        </div>
        {/* Scrollable Content */}
        <div style={styles.contentScrollView}>
          {/* Video Upload Form */}
          <div style={{ background: '#fff', borderRadius: 9, boxShadow: '0 2px 8px #0001', padding: 24, marginBottom: 30 }}>
            <div style={{ color: colors.d_gray, fontWeight: 600, fontSize: 15, marginBottom: 9 }}>Video Title</div>
            <input
              name="title"
              value={form.title}
              onChange={handleInputChange}
              placeholder="Enter video title"
              style={{ width: '100%', padding: 9, borderRadius: 4, border: '1px solid #eee', background: colors.inp, marginBottom: 15, fontSize: 13, fontFamily: 'inherit' }}
              required
            />
            <div style={{ color: colors.d_gray, fontWeight: 600, fontSize: 15, marginBottom: 9 }}>Category</div>
            <select
              name="category"
              value={form.category}
              onChange={handleInputChange}
              style={{ width: '100%', padding: 9, borderRadius: 4, border: '1px solid #eee', background: colors.inp, marginBottom: 15, fontSize: 13, fontFamily: 'inherit' }}
              required
            >
              <option value="">-- Select Category --</option>
              <option value="Warm-Up">Warm-Up</option>
              <option value="Cool Down">Cool Down</option>
              <option value="Cardio">Cardio</option>
              <option value="Flexibility">Flexibility</option>
              <option value="Strength">Strength</option>
              <option value="Balance">Balance</option>
              <option value="Chair Exercise">Chair Exercise</option>
            </select>
            <div style={{ color: colors.d_gray, fontWeight: 600, fontSize: 15, marginBottom: 9 }}>Description</div>
            <textarea
              name="description"
              value={form.description}
              onChange={handleInputChange}
              placeholder="Enter Video Description"
              rows={3}
              style={{ width: '100%', padding: 9, borderRadius: 4, border: '1px solid #eee', background: colors.inp, marginBottom: 15, resize: 'none', fontSize: 13, fontFamily: 'inherit' }}
              required
            />
            <div style={{ color: colors.d_gray, fontWeight: 600, fontSize: 15, marginBottom: 9 }}>Select Video File</div>
            <input
              name="videoFile"
              type="file"
              accept="video/*"
              onChange={handleInputChange}
              style={{ marginBottom: 15 }}
              required
            />
            <div>
              <button
                onClick={handleCreateVideo}
                style={{ background: colors.main, color: '#fff', border: 'none', borderRadius: 4, padding: '9px 24px', fontSize: 12, cursor: 'pointer' }}
              >
                Upload Video
              </button>
            </div>
          </div>
          {/* Video Playlist Section */}
          <div style={{ background: '#fff', borderRadius: 9, boxShadow: '0 2px 8px #0001', padding: 24 }}>
            <div style={{ color: colors.d_gray, fontWeight: 700, fontSize: 16, marginBottom: 18 }}>Video Playlist</div>
            
            {/* Category Filters */}
            <div style={{ marginBottom: 20 }}>
              {categories.map((category) => (
                <button
                  key={category}
                  style={{
                    ...categoryButtonStyle,
                    backgroundColor: selectedCategory === category ? colors.main : '#f0f0f0',
                    color: selectedCategory === category ? '#fff' : colors.d_gray,
                  }}
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </button>
              ))}
            </div>

            {/* Video List */}
            {filteredVideos.map((video) => (
              <div key={video.id} style={{ marginBottom: 18, padding: 15, borderRadius: 6, background: '#F6F6F6', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', alignItems: 'center', flex: 1 }}>
                  <MdPlayCircleOutline style={{ fontSize: '24px', color: colors.main, marginRight: '12px' }} />
                  <div>
                    <div style={{ color: colors.d_gray, fontWeight: 600, fontSize: 13 }}>{video.title}</div>
                    <div style={{ color: colors.d_gray, fontSize: 11, margin: '4px 0' }}>Category: {video.category} | Duration: {video.duration}</div>
                    <div style={{ color: colors.d_gray, fontSize: 11 }}>{video.description}</div>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 6 }}>
                  <button
                    style={{ ...actionButtonStyle, background: colors.view }}
                    onMouseEnter={e => e.target.style.backgroundColor = '#6aa3d9'}
                    onMouseLeave={e => e.target.style.backgroundColor = colors.view}
                    onClick={() => handleView(video)}
                  >
                    View
                  </button>
                  <button
                    style={{ ...actionButtonStyle, background: '#6c757d' }}
                    onMouseEnter={e => e.target.style.backgroundColor = '#5a6268'}
                    onMouseLeave={e => e.target.style.backgroundColor = '#6c757d'}
                    onClick={() => handleEdit(video)}
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDeleteClick(video)}
                    style={{ ...actionButtonStyle, background: colors.delete }}
                    onMouseEnter={e => e.target.style.backgroundColor = '#c82333'}
                    onMouseLeave={e => e.target.style.backgroundColor = colors.delete}
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      {/* Delete Modal */}
      <DeleteModal
        visible={showDeleteModal}
        onClose={handleDeleteCancel}
        onConfirm={handleDeleteConfirm}
        title={videoToDelete ? `Are you sure you want to delete the video "${videoToDelete.title}"?` : "Are you sure you want to delete this video?"}
        confirmText="Delete"
        cancelText="Cancel"
      />

      {/* Edit Modal */}
      {showEditModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 1000,
        }}>
          <div style={{
            backgroundColor: '#fff',
            borderRadius: '10px',
            boxShadow: '0 5px 15px rgba(0, 0, 0, 0.3)',
            width: '90%',
            maxWidth: '600px',
            maxHeight: '90%',
            display: 'flex',
            flexDirection: 'column',
            position: 'relative',
          }}>
            <button style={{
              position: 'absolute',
              top: '10px',
              right: '10px',
              background: 'none',
              border: 'none',
              fontSize: '24px',
              cursor: 'pointer',
              color: colors.d_gray,
              zIndex: 1,
            }} onClick={handleCloseEditModal}>×</button>
            
            <div style={{ padding: '20px', overflowY: 'auto', flexGrow: 1 }}>
              <h3 style={{ fontSize: '20px', fontWeight: 'bold', color: colors.main, marginBottom: '20px', textAlign: 'center' }}>Edit Video Details</h3>
              
              <div style={{ display: 'flex', gap: '20px' }}>
                <div style={{ flex: 1 }}>
                  <div style={{ marginBottom: '15px' }}>
                    <label style={{ fontSize: '14px', color: colors.main, fontWeight: '600', marginBottom: '5px', display: 'block' }}>Title</label>
                    <input
                      name="title"
                      value={editForm.title}
                      onChange={handleEditInputChange}
                      style={{ width: '100%', padding: '10px', border: '1px solid #eee', borderRadius: '5px', fontSize: '14px', background: colors.inp, fontFamily: 'inherit' }}
                      required
                    />
                  </div>
                  
                  <div style={{ marginBottom: '15px' }}>
                    <label style={{ fontSize: '14px', color: colors.main, fontWeight: '600', marginBottom: '5px', display: 'block' }}>Category</label>
                    <select
                      name="category"
                      value={editForm.category}
                      onChange={handleEditInputChange}
                      style={{ width: '100%', padding: '10px', border: '1px solid #eee', borderRadius: '5px', fontSize: '14px', background: colors.inp, fontFamily: 'inherit' }}
                      required
                    >
                      <option value="">-- Select Category --</option>
                      <option value="Warm-Up">Warm-Up</option>
                      <option value="Chair">Chair</option>
                      <option value="Cool Down">Cool Down</option>
                      <option value="Cardio">Cardio</option>
                      <option value="Flexibility">Flexibility</option>
                      <option value="Strength">Strength</option>
                      <option value="Balance">Balance</option>
                      <option value="Chair Exercise">Chair Exercise</option>
                    </select>
                  </div>
                  
                  <div style={{ marginBottom: '15px' }}>
                    <label style={{ fontSize: '14px', color: colors.main, fontWeight: '600', marginBottom: '5px', display: 'block' }}>Video Upload</label>
                    <input
                      name="videoFile"
                      type="file"
                      accept="video/*"
                      onChange={handleEditInputChange}
                      style={{ marginTop: '10px', padding: '10px', border: '1px solid #eee', borderRadius: '5px', fontSize: '14px', background: colors.inp, fontFamily: 'inherit', cursor: 'pointer' }}
                    />
                  </div>
                </div>
                
                <div style={{ flex: 1 }}>
                  <div style={{ marginBottom: '15px' }}>
                    <label style={{ fontSize: '14px', color: colors.main, fontWeight: '600', marginBottom: '5px', display: 'block' }}>Description</label>
                    <textarea
                      name="description"
                      value={editForm.description}
                      onChange={handleEditInputChange}
                      rows={6}
                      style={{ width: '100%', padding: '10px', border: '1px solid #eee', borderRadius: '5px', fontSize: '14px', background: colors.inp, fontFamily: 'inherit', resize: 'vertical' }}
                      required
                    />
                  </div>
                </div>
              </div>
              
              <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '15px 20px', borderTop: '1px solid #eee', marginTop: '20px' }}>
                <button style={{ background: colors.main, color: '#fff', border: 'none', borderRadius: '8px', padding: '10px 20px', fontSize: '14px', fontWeight: '600', cursor: 'pointer', transition: 'background-color 0.2s ease' }} onClick={handleSaveChanges}>
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* View Modal */}
      {showViewModal && viewingVideo && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 1000,
        }}>
          <div style={{
            backgroundColor: 'white',
            borderRadius: '10px',
            padding: '20px',
            margin: '20px',
            width: '600px',
            maxWidth: '90vw',
            position: 'relative',
            border: '1px solid #e0e0e0',
            boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)'
          }}>
            {/* Close button */}
            <button style={{
              position: 'absolute',
              top: '10px',
              right: '10px',
              background: 'none',
              border: 'none',
              fontSize: '24px',
              color: colors.d_gray,
              fontWeight: 'bold',
              padding: 0,
              width: '30px',
              height: '30px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
            }} onClick={handleCloseViewModal}>
              <span style={{lineHeight: 1}}>×</span>
            </button>
            
            {/* Modal content */}
            <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', width: '100%'}}>
              <h3 style={{fontSize: '18px', color: colors.main, textAlign: 'left', marginBottom: '20px', fontWeight: 'bold', margin: '0 0 20px 0', alignSelf: 'flex-start', fontFamily: 'Inter, sans-serif'}}>View Video</h3>
              
              {/* Video display area */}
              <div style={{width: '100%', marginBottom: '20px', position: 'relative'}}>
                {viewingVideo.videoFile ? (
                  <video 
                    controls
                    style={{width: '100%', height: '300px', objectFit: 'cover', borderRadius: '8px', border: '1px solid #e0e0e0'}}
                    src={typeof viewingVideo.videoFile === 'string' ? viewingVideo.videoFile : URL.createObjectURL(viewingVideo.videoFile)}
                  >
                    Your browser does not support the video tag.
                  </video>
                ) : (
                  <div style={{width: '100%', height: '300px', backgroundColor: '#f5f5f5', borderRadius: '8px', border: '2px dashed #d0d0d0', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column'}}>
                    <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#666'}}>
                      <MdPlayCircleOutline style={{fontSize: '48px', color: '#666'}} />
                    </div>
                    <div style={{color: '#666', marginTop: '10px', fontSize: '14px'}}>No video file available</div>
                  </div>
                )}
              </div>
              
              {/* Video Title */}
              <div style={{width: '100%', marginBottom: '20px'}}>
                <h4 style={{fontSize: '16px', color: colors.d_gray, fontWeight: 'bold', margin: '0 0 10px 0', fontFamily: 'Inter, sans-serif', textAlign: 'center'}}>{viewingVideo.title}</h4>
              </div>
              
              {/* Video Details */}
              <div style={{width: '100%', display: 'flex', flexDirection: 'column', gap: '15px'}}>
                <div style={{display: 'flex', alignItems: 'flex-start', gap: '10px'}}>
                  <span style={{fontSize: '14px', fontWeight: 600, color: colors.d_gray, minWidth: '80px', fontFamily: 'Inter, sans-serif'}}>Description:</span>
                  <span style={{fontSize: '14px', color: '#333', flex: 1, lineHeight: '1.5', fontFamily: 'Inter, sans-serif', wordBreak: 'break-word', overflowWrap: 'break-word'}}>{viewingVideo.description || 'No description available.'}</span>
                </div>
                <div style={{display: 'flex', alignItems: 'flex-start', gap: '10px'}}>
                  <span style={{fontSize: '14px', fontWeight: 600, color: colors.d_gray, minWidth: '80px', fontFamily: 'Inter, sans-serif'}}>Category:</span>
                  <span style={{fontSize: '14px', color: '#333', flex: 1, lineHeight: '1.5', fontFamily: 'Inter, sans-serif'}}>{viewingVideo.category}</span>
                </div>
                <div style={{display: 'flex', alignItems: 'flex-start', gap: '10px'}}>
                  <span style={{fontSize: '14px', fontWeight: 600, color: colors.d_gray, minWidth: '80px', fontFamily: 'Inter, sans-serif'}}>Duration:</span>
                  <span style={{fontSize: '14px', color: '#333', flex: 1, lineHeight: '1.5', fontFamily: 'Inter, sans-serif'}}>{viewingVideo.duration}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CHK_WorkoutVideos;
