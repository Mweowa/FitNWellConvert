import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { colors } from '../../utils/colors';
import { FaUserCircle, FaHome, FaUsers, FaUsersCog, FaCalendarAlt, FaClipboardList, FaCalendarCheck, FaList, FaSearch } from "react-icons/fa";
import { LuListVideo } from "react-icons/lu";
import { IoScaleSharp } from "react-icons/io5";
import { CiLogout } from "react-icons/ci";
import { FaChevronRight, FaChevronLeft } from "react-icons/fa";
import ViewMeasurements from '../../components/ViewMeasurements';
import EditMeasurements from '../../components/EditMeasurements';

const CHK_Measurements = ({ onLogout }) => {
  const navigate = useNavigate();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isViewMeasurementsModalOpen, setIsViewMeasurementsModalOpen] = useState(false);
  const [selectedMeasurement, setSelectedMeasurement] = useState(null);
  const [isEditMeasurementsModalOpen, setIsEditMeasurementsModalOpen] = useState(false);
  const [editingMeasurement, setEditingMeasurement] = useState(null);

  // Sample measurements data
  const [measurements] = useState([
    {
      id: 1,
      name: "Jimmy Reyes",
      sex: "Male"
    },
    {
      id: 2,
      name: "Grace Mendoza",
      sex: "Female"
    },
    {
      id: 3,
      name: "Carlo Chua",
      sex: "Male"
    },
    {
      id: 4,
      name: "Daniel Torres",
      sex: "Male"
    }
  ]);

  // View Measurements Modal handlers
  const handleViewMeasurements = (measurement) => {
    // Generate varied measurement data based on user
    const measurementData = generateMeasurementData(measurement);
    setSelectedMeasurement(measurementData);
    setIsViewMeasurementsModalOpen(true);
  };

  const handleCloseViewMeasurementsModal = () => {
    setIsViewMeasurementsModalOpen(false);
    setSelectedMeasurement(null);
  };

  // Edit Measurements Modal handlers
  const handleEditMeasurements = (measurement) => {
    // Generate varied measurement data based on user
    const measurementData = generateMeasurementData(measurement);
    setEditingMeasurement(measurementData);
    setIsEditMeasurementsModalOpen(true);
  };

  const handleCloseEditMeasurementsModal = () => {
    setIsEditMeasurementsModalOpen(false);
    setEditingMeasurement(null);
  };

  const handleSaveMeasurements = (updatedData) => {
    // Here you would typically update the database or state
    console.log('Saving updated measurements:', updatedData);
    // For now, we'll just close the modal
    setIsEditMeasurementsModalOpen(false);
    setEditingMeasurement(null);
  };

  const generateMeasurementData = (measurement) => {
    const userName = measurement.name;
    const userSex = measurement.sex;
    
    // Different measurement data based on user
    if (userName === "Jimmy Reyes") {
      return {
        name: userName,
        basicMeasurements: {
          height: 175,
          weight: 82.5,
          bmi: 26.9
        },
        circumferences: {
          chest: 105,
          waist: 95,
          upperArm: 32,
          thigh: 58,
          calf: 38,
          waistToHipRatio: 0.89
        },
        skinFold: {
          chest: 12,
          abdomen: 18,
          thigh: 15
        }
      };
    } else if (userName === "Grace Mendoza") {
      return {
        name: userName,
        basicMeasurements: {
          height: 162,
          weight: 58.2,
          bmi: 22.2
        },
        circumferences: {
          chest: 88,
          waist: 72,
          upperArm: 26,
          thigh: 52,
          calf: 32,
          waistToHipRatio: 0.76
        },
        skinFold: {
          chest: 8,
          abdomen: 12,
          thigh: 18
        }
      };
    } else if (userName === "Carlo Chua") {
      return {
        name: userName,
        basicMeasurements: {
          height: 168,
          weight: 70.8,
          bmi: 25.1
        },
        circumferences: {
          chest: 98,
          waist: 85,
          upperArm: 30,
          thigh: 55,
          calf: 35,
          waistToHipRatio: 0.82
        },
        skinFold: {
          chest: 10,
          abdomen: 15,
          thigh: 12
        }
      };
    } else if (userName === "Daniel Torres") {
      return {
        name: userName,
        basicMeasurements: {
          height: 180,
          weight: 75.3,
          bmi: 23.2
        },
        circumferences: {
          chest: 102,
          waist: 80,
          upperArm: 31,
          thigh: 56,
          calf: 36,
          waistToHipRatio: 0.78
        },
        skinFold: {
          chest: 9,
          abdomen: 11,
          thigh: 14
        }
      };
    } else {
      // Default measurement data
      return {
        name: userName,
        basicMeasurements: {
          height: 170,
          weight: 70.0,
          bmi: 24.2
        },
        circumferences: {
          chest: 95,
          waist: 80,
          upperArm: 28,
          thigh: 54,
          calf: 34,
          waistToHipRatio: 0.80
        },
        skinFold: {
          chest: 10,
          abdomen: 14,
          thigh: 15
        }
      };
    }
  };

  const styles = {
    container: {
      display: 'flex',
      flexDirection: 'row',
      height: '100vh',
      backgroundColor: '#FEFFFD',
      overflow: 'auto',
    },
    sidebar: {
      backgroundColor: '#F1F1F2',
      padding: '17px 15px',
      width: isCollapsed ? '80px' : '230px',
      transition: 'width 0.3s ease, padding 0.3s ease',
      display: 'flex',
      flexDirection: 'column',
    },
    brand: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '15px',
      padding: isCollapsed ? '0' : '0 10px',
      justifyContent: isCollapsed ? 'center' : 'flex-start',
    },
    brandIcon: {
      width: '47px',
      height: '40px',
    },
    brandText: {
      fontSize: '25px',
      color: colors.d_gray,
      fontWeight: 'bold',
      fontStyle: 'italic',
      marginLeft: '15px',
    },
    menuContainer: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
    },
    menuGroup: {
      marginBottom: '20px',
    },
    menuDivider: {
      height: '1px',
      backgroundColor: '#e0e0e0',
      marginBottom: '15px',
    },
    menuItem: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemActive: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'rgba(159, 192, 59, 0.2)',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemCollapsed: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '12px 8px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuIcon: {
      fontSize: '20px',
      marginRight: isCollapsed ? '0' : '12px',
      color: colors.main,
      display: 'flex',
      alignItems: 'center',
    },
    menuText: {
      fontSize: '14px',
      color: colors.d_gray,
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    menuTextActive: {
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '600',
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    logoutButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#fff',
      border: 'none',
      borderRadius: '30px',
      padding: isCollapsed ? '2px 3px' : '7px 12px',
      marginTop: '20px',
      marginBottom: '10px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      width: isCollapsed ? 'auto' : 'fit-content',
      alignSelf: 'center',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
    },
    logoutIcon: {
      background: 'none',
      fontSize: '18px',
      marginRight: isCollapsed ? '0' : '8px',
      display: 'flex',
      alignItems: 'center',
      color: colors.main,
    },
    logoutText: {
      background: 'none',
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '500',
    },
    mainContent: {
      flex: 1,
      backgroundColor: '#FEFFFD',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '30px',
    },
    collapseButton: {
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      fontSize: '10px',
      color: colors.l_gray,
      transition: 'background-color 0.2s ease',
      marginLeft: '-10px'
    },
    pageTitle: {
      fontSize: '28px',
      fontWeight: 'bold',
      color: colors.main,
      marginBottom: '20px',
    },
    profileButton: {
      color: colors.main,      
      marginTop: '5px',
      marginRight: '5px',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontSize: '32px',
    },
    searchContainer: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '20px',
      gap: '15px',
    },
    searchBox: {
      display: 'flex',
      alignItems: 'center',
      backgroundColor: '#fff',
      border: '1px solid #e0e0e0',
      borderRadius: '8px',
      padding: '10px 15px',
      flex: 1,
      maxWidth: '400px',
    },
    searchIcon: {
      color: '#999',
      marginRight: '10px',
      fontSize: '16px',
    },
    searchInput: {
      border: 'none',
      outline: 'none',
      flex: 1,
      fontSize: '14px',
      color: '#333',
    },
    tableContainer: {
      backgroundColor: '#fff',
      borderRadius: '8px',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
      overflow: 'hidden',
    },
    table: {
      width: '100%',
      borderCollapse: 'collapse',
    },
    tableHeader: {
      backgroundColor: '#f8f9fa',
      borderBottom: '1px solid #e0e0e0',
    },
    tableHeaderCell: {
      padding: '15px 12px',
      textAlign: 'left',
      fontSize: '14px',
      fontWeight: '600',
      color: '#333',
      borderBottom: '1px solid #e0e0e0',
    },
    tableRow: {
      borderBottom: '1px solid #f0f0f0',
    },
    tableCell: {
      padding: '12px',
      fontSize: '14px',
      color: '#333',
      borderBottom: '1px solid #f0f0f0',
    },
    actionButtons: {
      display: 'flex',
      gap: '8px',
    },
    viewActiveButton: {
      backgroundColor: colors.view,
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '6px 12px',
      cursor: 'pointer',
      fontSize: '12px',
      transition: 'background-color 0.2s ease',
    },
    historyButton: {
      backgroundColor: colors.l_gray,
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '6px 12px',
      cursor: 'pointer',
      fontSize: '12px',
      transition: 'background-color 0.2s ease',
    },
  };

  const menuItems = [
    { name: 'Dashboard', icon: <FaHome />, active: false, route: '/chk-dashboard' },
    { name: 'User Management', icon: <FaUsers />, active: false, route: '/user-management' },
    { name: 'Admin Management', icon: <FaUsersCog />, route: '/admin-management' },
    { name: 'Workout Videos', icon: <LuListVideo />, route: '/workout-videos' },
    { name: 'Events Display', icon: <FaCalendarAlt />, route: '/events-display' },
    { name: 'Activity Logs', icon: <FaClipboardList />, active: false, route: '/activity-logs' },
    { name: 'Appointments', icon: <FaCalendarCheck />, route: '/appointments' },
    { name: 'Fitness Plans', icon: <FaList />, active: false, route: '/fitness-plans' },
    { name: 'Measurements', icon: <IoScaleSharp />, active: true, route: '/measurements' },
  ];

  const renderMenuItem = (item, index) => {
    const menuItemStyle = item.active 
      ? (isCollapsed ? styles.menuItemCollapsed : styles.menuItemActive)
      : (isCollapsed ? styles.menuItemCollapsed : styles.menuItem);
    
    const menuTextStyle = item.active ? styles.menuTextActive : styles.menuText;

    return (
      <button
        key={index}
        style={menuItemStyle}
        onClick={() => {
          if (item.route) {
            navigate(item.route);
          }
        }}
        onMouseEnter={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'rgba(159, 192, 59, 0.1)';
          }
        }}
        onMouseLeave={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'transparent';
          }
        }}
      >
        <span style={styles.menuIcon}>{item.icon}</span>
        {!isCollapsed && (
          <span style={menuTextStyle}>
            {item.name}
          </span>
        )}
      </button>
    );
  };

  const filteredMeasurements = measurements.filter(measurement =>
    measurement.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div style={styles.container}>
      {/* Sidebar */}
      <div style={styles.sidebar}>
        {/* Brand */}
        <div style={styles.brand}>
          <img 
            src="/fnw1.png" 
            alt="FitNWell Logo"
            style={styles.brandIcon}
          />
          {!isCollapsed && (
            <span style={styles.brandText}>FitNWell</span>
          )}
        </div>

        {/* Menu Items */}
        <div style={styles.menuContainer}>
          <div style={styles.menuDivider} />
          
          <div style={styles.menuGroup}>
            {menuItems.slice(0, 6).map((item, index) => renderMenuItem(item, index))}
          </div>
          
          <div style={styles.menuDivider} />
          
          <div style={styles.menuGroup}>
            {menuItems.slice(6).map((item, index) => renderMenuItem(item, index + 6))}
          </div>
        </div>

        {/* Logout Button */}
        <button 
          style={styles.logoutButton}
          onClick={onLogout}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#f5f5f5';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#fff';
          }}
        >
          <span style={styles.logoutIcon}><CiLogout /></span>
          {!isCollapsed && (
            <span style={styles.logoutText}>Log Out</span>
          )}
        </button>
      </div>

      {/* Main Content */}
      <div style={styles.mainContent}>
        {/* Header */}
        <div style={styles.header}>
          <button 
            style={styles.collapseButton}
            onClick={() => setIsCollapsed(!isCollapsed)}
          >
            {isCollapsed ? <FaChevronRight /> : <FaChevronLeft />}
          </button>
          <span style={styles.pageTitle}>Anthropometric Measurements</span>
          <button style={styles.profileButton}
          onClick={() => navigate('/user-profile')}
          >
            <FaUserCircle />
          </button>
        </div>

        {/* Search */}
        <div style={styles.searchContainer}>
          <div style={styles.searchBox}>
            <FaSearch style={styles.searchIcon} />
            <input
              type="text"
              placeholder="Search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={styles.searchInput}
            />
          </div>
        </div>

        {/* Measurements Table */}
        <div style={styles.tableContainer}>
          <table style={styles.table}>
            <thead style={styles.tableHeader}>
              <tr>
                <th style={styles.tableHeaderCell}>ID</th>
                <th style={styles.tableHeaderCell}>Name</th>
                <th style={styles.tableHeaderCell}>Sex</th>
                <th style={styles.tableHeaderCell}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredMeasurements.map((measurement) => (
                <tr 
                  key={measurement.id} 
                  style={styles.tableRow}
                  onMouseEnter={(e) => {
                    e.target.parentElement.style.backgroundColor = '#f8f9fa';
                  }}
                  onMouseLeave={(e) => {
                    e.target.parentElement.style.backgroundColor = 'transparent';
                  }}
                >
                  <td style={styles.tableCell}>{measurement.id}</td>
                  <td style={styles.tableCell}>{measurement.name}</td>
                  <td style={styles.tableCell}>{measurement.sex}</td>
                  <td style={styles.tableCell}>
                    <div style={styles.actionButtons}>
                      <button 
                        style={styles.viewActiveButton}
                        onClick={() => handleViewMeasurements(measurement)}
                        onMouseEnter={(e) => {
                          e.target.style.backgroundColor = '#6aa3d9';
                        }}
                        onMouseLeave={(e) => {
                          e.target.style.backgroundColor = colors.view;
                        }}
                      >
                        View Measurements
                      </button>
                      <button 
                        style={styles.historyButton}
                        onClick={() => handleEditMeasurements(measurement)}
                        onMouseEnter={(e) => {
                          e.target.style.backgroundColor = '#5a6268';
                        }}
                        onMouseLeave={(e) => {
                          e.target.style.backgroundColor = colors.l_gray;
                        }}
                      >
                        Edit Measurements
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* View Measurements Modal */}
      {isViewMeasurementsModalOpen && selectedMeasurement && (
        <ViewMeasurements
          visible={isViewMeasurementsModalOpen}
          measurementData={selectedMeasurement}
          onClose={handleCloseViewMeasurementsModal}
        />
      )}

      {/* Edit Measurements Modal */}
      {isEditMeasurementsModalOpen && editingMeasurement && (
        <EditMeasurements
          visible={isEditMeasurementsModalOpen}
          measurementData={editingMeasurement}
          onClose={handleCloseEditMeasurementsModal}
          onSave={handleSaveMeasurements}
        />
      )}
    </div>
  );
};

export default CHK_Measurements; 