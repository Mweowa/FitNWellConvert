import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { colors } from '../utils/colors';
import { FiEye, FiEyeOff } from 'react-icons/fi';
import adminBg from '../assets/photos/adminbg.png';
import fnwLogo from '../assets/photos/fnw1.png';
import { IoChevronBackCircleOutline } from "react-icons/io5";

export default function Login({ onLoginSuccess, selectedRole }) {
  const navigate = useNavigate();
  const [hoveredButton, setHoveredButton] = React.useState(null);
  const [showPassword, setShowPassword] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleMouseEnter = (buttonIndex) => {
    setHoveredButton(buttonIndex);
  };

  const handleMouseLeave = () => {
    setHoveredButton(null);
  };

  const handleSignIn = () => {
    // Handle sign in logic here
    console.log('Sign in:', { username, password, role: selectedRole });

    if (username && password) {
      onLoginSuccess();
      if (selectedRole === 'College of Human Kinetics') {
        navigate('/chk-dashboard');
      } else if (selectedRole === 'Muscle Pain Management') {
        navigate('/mp-dashboard');
      } else if (selectedRole === 'Coach') {
        navigate('/coach-dashboard');
      }
    } else {
      alert('Please enter both username and password');
    }
  };

  const handleBackButton = () => {
    navigate('/');
  };

  return (
    <div style={styles.container}>
      <img
        src={adminBg}
        style={styles.backgroundImage}
        alt="Background"
      />
      <div style={styles.centerBox}>
        <img
          src={fnwLogo}
          style={styles.logo}
          alt="FitNWell Logo"
        />
        <button 
          onClick={() => window.location.reload()} 
          style={styles.backButton}
        >          
        </button>
        <div style={styles.headerContainer}>
          <h1 style={styles.title}>FitNWell</h1>
          {selectedRole && (
            <p style={styles.selectedRole}>{selectedRole}</p>
          )}
        </div>
        
        <div style={styles.formContainer}>
          <div style={styles.inputGroup}>
            <label style={styles.label}>Username</label>
            <input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              style={styles.input}
            />
          </div>
          
          <div style={styles.inputGroup}>
            <label style={styles.label}>Password</label>
            <div style={styles.passwordContainer}>
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                style={styles.input}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                style={styles.eyeButton}
              >
                {showPassword ? <FiEye size={18} color={colors.l_gray} /> : <FiEyeOff size={18} color={colors.l_gray} />}
              </button>
            </div>
          </div>
          
          <div style={styles.forgotPassword}>
            <span style={styles.forgotPasswordText}>Forgot Password?</span>
          </div>
          
          <button 
            style={{
              ...styles.button,
              ...(hoveredButton === 0 && styles.buttonHover)
            }}
            onMouseEnter={() => handleMouseEnter(0)}
            onMouseLeave={handleMouseLeave}
            onClick={handleSignIn}
          >
            <span style={styles.buttonText}>Sign In</span>
          </button>
        </div>
      </div>
    </div>
  );
}

const styles = {
  container: {
    width: '100vw',
    height: '100vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
    overflow: 'hidden',
  },
  backgroundImage: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    objectFit: 'cover',
    zIndex: 0,
  },
  centerBox: {
    backgroundColor: '#FBFBFB',
    borderRadius: '28px',
    padding: '48px 40px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    width: '390px',
    height: '600px',
    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.25), 0 4px 16px rgba(0, 0, 0, 0.15)',
    opacity: 1.0,
    zIndex: 1,
    position: 'relative',
  },
  logo: {
    width: '160px',
    height: '120px',
    marginBottom: '5px',
    objectFit: 'contain',
  },
  headerContainer: {
    width: '100%',
    position: 'relative',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  backButton: {
    position: 'absolute',
    left: 15,
    top: 20,
    background: 'none',
    border: 'none',
    color: colors.l_gray,
    fontSize: '14px',
    cursor: 'pointer',
    padding: '8px',
    borderRadius: '8px',
    transition: 'all 0.2s ease',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 10,
  },
  title: {
    fontSize: '32px',
    color: colors.d_gray,
    marginBottom: '32px',
    fontWeight: 'bold',
    fontStyle: 'italic',
    margin: '0 0 32px 0',
    letterSpacing: -0.5,
    textAlign: 'center',
  },
  selectedRole: {
    fontSize: '14px',
    color: colors.d_gray,
    marginBottom: '30px',
    marginTop: '-15px',
    textAlign: 'center',
    fontStyle: 'italic',
  },
  formContainer: {
    width: '100%',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  inputGroup: {
    width: '100%',
    marginBottom: '20px',
  },
  label: {
    color: colors.d_gray,
    fontSize: '14px',
    fontWeight: 'bold',
    marginBottom: '8px',
    display: 'block',
  },
  input: {
    width: '100%',
    padding: '12px 16px',
    borderRadius: '12px',
    border: '1px solid #e0e0e0',
    fontSize: '14px',
    backgroundColor: '#f8f9fa',
    outline: 'none',
    transition: 'all 0.2s ease',
  },
  passwordContainer: {
    position: 'relative',
    width: '100%',
  },
  eyeButton: {
    position: 'absolute',
    right: '12px',
    top: '50%',
    transform: 'translateY(-50%)',
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontSize: '16px',
    padding: '4px',
  },
  forgotPassword: {
    width: '100%',
    textAlign: 'right',
    marginBottom: '24px',
  },  
    forgotPasswordText: {
    letterSpacing: -.4,
    color: 'l_gray',
    fontSize: '12px',
    cursor: 'pointer',
    textDecoration: 'underline',
  },
  button: {
    backgroundColor: '#fff',
    borderRadius: '28px',
    padding: '14px 24px',
    margin: '8px 0',
    width: '290px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.08)',
    border: 'none',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
  },
  buttonText: {
    color: colors.d_gray,
    fontSize: '13px',
    fontWeight: 'bold',
    margin: 0,
  },
  buttonHover: {
    backgroundColor: '#f8f9fa',
    transform: 'translateY(-2px)',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
  },
}; 