import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { colors } from '../../utils/colors';
import { FaUserCircle, FaHome, FaCalendarAlt, FaCalendarCheck, FaSearch } from "react-icons/fa";
import { CiLogout } from "react-icons/ci";
import { FaChevronRight, FaChevronLeft } from "react-icons/fa";
import MPComplete from '../../components/MPComplete';
import MPMissed from '../../components/MPMissed';

const MP_Appointments = ({ onLogout }) => {
  const navigate = useNavigate();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState('all');
  const [activeMenu, setActiveMenu] = useState('appointments');
  const [isMPCompleteVisible, setIsMPCompleteVisible] = useState(false);
  const [isMPMissedVisible, setIsMPMissedVisible] = useState(false);
  const [selectedAppointmentId, setSelectedAppointmentId] = useState(null);

  const handleLogout = () => {
    onLogout();
    navigate('/');
  };

  const handleMenuClick = (route) => {
    setActiveMenu(route);
    if (route === 'dashboard') {
      navigate('/mp-dashboard');
    } else if (route === 'appointment-requests') {
      navigate('/mp-requests');
    }
  };

  // Handle Complete button click
  const handleComplete = (appointmentId) => {
    setSelectedAppointmentId(appointmentId);
    setIsMPCompleteVisible(true);
  };

  // Handle Missed button click
  const handleMissed = (appointmentId) => {
    setSelectedAppointmentId(appointmentId);
    setIsMPMissedVisible(true);
  };

  // Handle Complete modal close
  const handleCompleteClose = () => {
    setIsMPCompleteVisible(false);
    setSelectedAppointmentId(null);
  };

  // Handle Missed modal close
  const handleMissedClose = () => {
    setIsMPMissedVisible(false);
    setSelectedAppointmentId(null);
  };

  // Handle Complete confirmation
  const handleCompleteConfirm = () => {
    if (selectedAppointmentId) {
      setAppointments(appointments.map(appointment =>
        appointment.id === selectedAppointmentId
          ? { ...appointment, status: 'Completed' }
          : appointment
      ));
    }
    setIsMPCompleteVisible(false);
    setSelectedAppointmentId(null);
  };

  // Handle Missed confirmation
  const handleMissedConfirm = () => {
    if (selectedAppointmentId) {
      setAppointments(appointments.map(appointment =>
        appointment.id === selectedAppointmentId
          ? { ...appointment, status: 'Missed' }
          : appointment
      ));
    }
    setIsMPMissedVisible(false);
    setSelectedAppointmentId(null);
  };

  // Get status button style
  const getStatusStyle = (status) => {
    switch (status) {
      case 'Approved': return { backgroundColor: colors.l_gray, color: 'white' };
      case 'Completed': return { backgroundColor: colors.verified, color: 'white' };
      case 'Missed': return { backgroundColor: colors.delete, color: 'white' };
      default: return { backgroundColor: colors.l_gray, color: 'white' };
    }
  };

  // Sample appointments data
  const [appointments, setAppointments] = useState([
    { id: 1, name: "Juan Carlo Cruz", date: "May 26, 2025", timeslot: "1:30 PM", status: "Approved" },
    { id: 2, name: "Angela Mae Ramirez", date: "April 07, 2025", timeslot: "3:30 PM", status: "Approved" },
    { id: 3, name: "Juan dela Cruz", date: "August 09, 2025", timeslot: "4:00 PM", status: "Approved" },
    { id: 4, name: "Sofia Smith", date: "August 23, 2025", timeslot: "5:30 PM", status: "Approved" }
  ]);

  // Function to check if a date is today
  const isToday = (dateString) => {
    const today = new Date();
    const appointmentDate = new Date(dateString);
    return appointmentDate.getFullYear() === today.getFullYear() &&
           appointmentDate.getMonth() === today.getMonth() &&
           appointmentDate.getDate() === today.getDate();
  };

  // Function to check if a date is upcoming (future dates, not today)
  const isUpcoming = (dateString) => {
    const today = new Date();
    const appointmentDate = new Date(dateString);
    today.setHours(0, 0, 0, 0); // Reset time for comparison
    appointmentDate.setHours(0, 0, 0, 0); // Reset time for comparison
    return appointmentDate > today;
  };

  // Filter appointments based on active filter
  const filteredAppointments = appointments.filter(appointment => {
    const matchesSearch = appointment.name.toLowerCase().includes(searchTerm.toLowerCase());
    if (!matchesSearch) return false;

    switch (activeFilter) {
      case 'all':
        return true;
      case 'today':
        return isToday(appointment.date);
      case 'upcoming':
        return isUpcoming(appointment.date);
      default:
        return true;
    }
  });

  const filterButtons = [
    { key: 'all', label: 'All' },
    { key: 'today', label: 'Today' },
    { key: 'upcoming', label: 'Upcoming' }
  ];

  const styles = {
    container: {
      display: 'flex',
      flexDirection: 'row',
      height: '100vh',
      backgroundColor: '#FEFFFD',
      overflow: 'auto',
    },
    sidebar: {
      backgroundColor: '#F1F1F2',
      padding: '17px 15px',
      width: isCollapsed ? '80px' : '230px',
      transition: 'width 0.3s ease, padding 0.3s ease',
      display: 'flex',
      flexDirection: 'column',
    },
    brand: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '15px',
      padding: isCollapsed ? '0' : '0 10px',
      justifyContent: isCollapsed ? 'center' : 'flex-start',
    },
    brandIcon: {
      width: '47px',
      height: '40px',
    },
    brandText: {
      fontSize: '25px',
      color: colors.d_gray,
      fontWeight: 'bold',
      fontStyle: 'italic',
      marginLeft: '15px',
    },
    menuContainer: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
    },
    menuGroup: {
      marginBottom: '20px',
    },
    menuDivider: {
      height: '1px',
      backgroundColor: '#e0e0e0',
      marginBottom: '15px',
    },
    menuItem: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemActive: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'rgba(159, 192, 59, 0.2)',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemCollapsed: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '12px 8px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuIcon: {
      fontSize: '20px',
      marginRight: isCollapsed ? '0' : '12px',
      color: colors.main,
      display: 'flex',
      alignItems: 'center',
    },
    menuText: {
      fontSize: '14px',
      color: colors.d_gray,
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    menuTextActive: {
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '600',
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    logoutButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#fff',
      border: 'none',
      borderRadius: '30px',
      padding: isCollapsed ? '2px 3px' : '7px 12px',
      marginTop: '20px',
      marginBottom: '10px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      width: isCollapsed ? 'auto' : 'fit-content',
      alignSelf: 'center',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
    },
    logoutIcon: {
      background: 'none',
      fontSize: '18px',
      marginRight: isCollapsed ? '0' : '8px',
      display: 'flex',
      alignItems: 'center',
      color: colors.main,
    },
    logoutText: {
      background: 'none',
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '500',
    },
    mainContent: {
      flex: 1,
      backgroundColor: '#FEFFFD',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '30px',
    },
    collapseButton: {
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      fontSize: '10px',
      color: colors.l_gray,
      transition: 'background-color 0.2s ease',
      marginLeft: '-10px'
    },
    pageTitle: {
      fontSize: '28px',
      fontWeight: 'bold',
      color: colors.main,
      marginBottom: '20px',
    },
    profileButton: {
      color: colors.main,      
      marginTop: '5px',
      marginRight: '5px',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontSize: '32px',
    },
    searchContainer: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '20px',
      gap: '15px',
    },
    searchBox: {
      display: 'flex',
      alignItems: 'center',
      backgroundColor: '#fff',
      border: '1px solid #e0e0e0',
      borderRadius: '8px',
      padding: '10px 15px',
      flex: 1,
      maxWidth: '400px',
    },
    searchIcon: {
      color: '#999',
      marginRight: '10px',
      fontSize: '16px',
    },
    searchInput: {
      border: 'none',
      outline: 'none',
      flex: 1,
      fontSize: '14px',
      color: '#333',
    },
    filterContainer: {
      display: 'flex',
      gap: '10px',
    },
    filterButton: {
      backgroundColor: '#fff',
      color: colors.d_gray,
      border: '1px solid #e0e0e0',
      borderRadius: '6px',
      padding: '10px 20px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '500',
      transition: 'all 0.2s ease',
    },
    filterButtonActive: {
      backgroundColor: colors.l_gray,
      color: '#fff',
      border: '1px solid ' + colors.l_gray,
      borderRadius: '6px',
      padding: '8px 16px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '600',
      transition: 'all 0.2s ease',
    },
    tableContainer: {
      backgroundColor: '#fff',
      borderRadius: '8px',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
      overflow: 'hidden',
    },
    table: {
      width: '100%',
      borderCollapse: 'collapse',
    },
    tableHeader: {
      backgroundColor: '#f8f9fa',
      borderBottom: '1px solid #e0e0e0',
    },
    tableHeaderCell: {
      padding: '15px 12px',
      textAlign: 'left',
      fontSize: '14px',
      fontWeight: '600',
      color: '#333',
      borderBottom: '1px solid #e0e0e0',
    },
    tableRow: {
      borderBottom: '1px solid #f0f0f0',
    },
    tableCell: {
      padding: '12px',
      fontSize: '14px',
      color: '#333',
      borderBottom: '1px solid #f0f0f0',
    },
    statusButton: {
      backgroundColor: colors.l_gray,
      color: '#fff',
      border: 'none',
      borderRadius: '12px',
      padding: '4px 12px',
      width: '15px',
      cursor: 'pointer',
      fontSize: '11px',
      fontWeight: '500',
    },
    actionButtons: {
      display: 'flex',
      gap: '6px',
    },
    approveButton: {
      backgroundColor: colors.l_gray,
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '4px 8px',
      cursor: 'pointer',
      fontSize: '11px',
      transition: 'background-color 0.2s ease',
    },
    completedButton: {
      backgroundColor: colors.main,
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '4px 8px',
      cursor: 'pointer',
      fontSize: '11px',
      transition: 'background-color 0.2s ease',
    },
    missedButton: {
      backgroundColor: '#dc3545',
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '4px 8px',
      cursor: 'pointer',
      fontSize: '11px',
      transition: 'background-color 0.2s ease',
    },
  };

  const menuItems = [
    { name: 'Dashboard', icon: <FaHome />, active: activeMenu === 'dashboard', route: 'dashboard' },
    { name: 'Appointment Requests', icon: <FaCalendarAlt />, active: activeMenu === 'appointment-requests', route: 'appointment-requests' },
    { name: 'Appointments', icon: <FaCalendarCheck />, active: activeMenu === 'appointments', route: 'appointments' },
  ];

  const renderMenuItem = (item, index) => {
    const menuItemStyle = item.active 
      ? (isCollapsed ? styles.menuItemCollapsed : styles.menuItemActive)
      : (isCollapsed ? styles.menuItemCollapsed : styles.menuItem);
    
    const menuTextStyle = item.active ? styles.menuTextActive : styles.menuText;

    return (
      <button
        key={index}
        style={menuItemStyle}
        onClick={() => handleMenuClick(item.route)}
        onMouseEnter={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'rgba(159, 192, 59, 0.1)';
          }
        }}
        onMouseLeave={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'transparent';
          }
        }}
      >
        <span style={styles.menuIcon}>{item.icon}</span>
        {!isCollapsed && (
          <span style={menuTextStyle}>
            {item.name}
          </span>
        )}
      </button>
    );
  };

  return (
    <div style={styles.container}>
      {/* Sidebar */}
      <div style={styles.sidebar}>
        {/* Brand */}
        <div style={styles.brand}>
          <img 
            src="/fnw1.png" 
            alt="FitNWell Logo"
            style={styles.brandIcon}
          />
          {!isCollapsed && (
            <span style={styles.brandText}>FitNWell</span>
          )}
        </div>

        {/* Menu Items */}
        <div style={styles.menuContainer}>
          <div style={styles.menuDivider} />
          <div style={styles.menuGroup}>
            {menuItems.map((item, index) => renderMenuItem(item, index))}
          </div>
        </div>

        {/* Logout Button */}
        <button 
          style={styles.logoutButton}
          onClick={handleLogout}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#f5f5f5';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#fff';
          }}
        >
          <span style={styles.logoutIcon}><CiLogout /></span>
          {!isCollapsed && (
            <span style={styles.logoutText}>Log Out</span>
          )}
        </button>
      </div>

      {/* Main Content */}
      <div style={styles.mainContent}>
        {/* Header */}
        <div style={styles.header}>
          <button 
            style={styles.collapseButton}
            onClick={() => setIsCollapsed(!isCollapsed)}
          >
            {isCollapsed ? <FaChevronRight /> : <FaChevronLeft />}
          </button>
          <span style={styles.pageTitle}>Appointments</span>
          <button style={styles.profileButton}
          onClick={() => navigate('/mp-user-profile')}
          >
            <FaUserCircle />
          </button>
        </div>

        {/* Search and Filter */}
        <div style={styles.searchContainer}>
          <div style={styles.searchBox}>
            <FaSearch style={styles.searchIcon} />
            <input
              type="text"
              placeholder="Search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={styles.searchInput}
            />
          </div>
          <div style={styles.filterContainer}>
            {filterButtons.map((filter) => (
              <button
                key={filter.key}
                style={activeFilter === filter.key ? styles.filterButtonActive : styles.filterButton}
                onClick={() => setActiveFilter(filter.key)}
              >
                {filter.label}
              </button>
            ))}
          </div>
        </div>

        {/* Appointments Table */}
        <div style={styles.tableContainer}>
          <table style={styles.table}>
            <thead style={styles.tableHeader}>
              <tr>
                <th style={styles.tableHeaderCell}>ID</th>
                <th style={styles.tableHeaderCell}>Name</th>
                <th style={styles.tableHeaderCell}>Date</th>
                <th style={styles.tableHeaderCell}>Timeslot</th>
                <th style={styles.tableHeaderCell}>Status</th>
                <th style={styles.tableHeaderCell}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredAppointments.map((appointment) => (
                <tr 
                  key={appointment.id} 
                  style={styles.tableRow}
                >
                  <td style={styles.tableCell}>{appointment.id}</td>
                  <td style={styles.tableCell}>{appointment.name}</td>
                  <td style={styles.tableCell}>{appointment.date}</td>
                  <td style={styles.tableCell}>{appointment.timeslot}</td>
                  <td style={styles.tableCell}>
                    <span style={{...styles.statusButton, ...getStatusStyle(appointment.status)}}>
                      {appointment.status}
                    </span>
                  </td>
                  <td style={styles.tableCell}>
                    <div style={styles.actionButtons}>
                      <button 
                        style={styles.completedButton}
                        onClick={() => handleComplete(appointment.id)}
                      >
                        Completed
                      </button>
                      <button 
                        style={styles.missedButton}
                        onClick={() => handleMissed(appointment.id)}
                      >
                        Missed
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Modal Components */}
      <MPComplete visible={isMPCompleteVisible} onClose={handleCompleteClose} onConfirm={handleCompleteConfirm} />
      <MPMissed visible={isMPMissedVisible} onClose={handleMissedClose} onConfirm={handleMissedConfirm} />
    </div>
  );
};

export default MP_Appointments;
