import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { colors } from '../../utils/colors';
import { FaUserCircle, FaHome, FaCalendarAlt, FaCalendarCheck, FaSearch } from "react-icons/fa";
import { CiLogout } from "react-icons/ci";
import { FaChevronRight, FaChevronLeft } from "react-icons/fa";
import MPApprove from '../../components/MPApprove';
import MPReject from '../../components/MPReject';

const MP_Requests = ({ onLogout }) => {
  const navigate = useNavigate();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState('all');
  const [activeMenu, setActiveMenu] = useState('appointment-requests');
  
  // Modal states
  const [showApproveModal, setShowApproveModal] = useState(false);
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState(null);

  const handleLogout = () => {
    onLogout();
    navigate('/');
  };

  const handleMenuClick = (route) => {
    setActiveMenu(route);
    if (route === 'dashboard') {
      navigate('/mp-dashboard');
    } else if (route === 'appointments') {
      navigate('/mp-appointments');
    }
  };

  // Sample appointment requests data - now using useState to allow updates
  const [appointmentRequests, setAppointmentRequests] = useState([
    {
      id: 1,
      name: "Maria Santos",
      date: "May 28, 2025",
      timeslot: "2:00 PM",
      status: "Pending"
    },
    {
      id: 2,
      name: "Carlos Rodriguez",
      date: "May 30, 2025",
      timeslot: "4:30 PM",
      status: "Pending"
    },
    {
      id: 3,
      name: "Ana Martinez",
      date: "June 02, 2025",
      timeslot: "1:00 PM",
      status: "Pending"
    },
    {
      id: 4,
      name: "Luis Garcia",
      date: "June 05, 2025",
      timeslot: "3:00 PM",
      status: "Pending"
    }
  ]);

  // Handle approve button click
  const handleApproveClick = (appointment) => {
    console.log('Approve clicked for:', appointment); // Debug log
    setSelectedAppointment(appointment);
    setShowApproveModal(true);
    console.log('Modal state set to true'); // Debug log
  };

  // Handle reject button click
  const handleRejectClick = (appointment) => {
    console.log('Reject clicked for:', appointment); // Debug log
    setSelectedAppointment(appointment);
    setShowRejectModal(true);
    console.log('Reject modal state set to true'); // Debug log
  };

  // Handle approve confirmation
  const handleApproveConfirm = () => {
    if (selectedAppointment) {
      // Update the request status to Approved
      setAppointmentRequests(prev => 
        prev.map(appointment => 
          appointment.id === selectedAppointment.id 
            ? { ...appointment, status: "Approved" }
            : appointment
        )
      );

      // Add the approved appointment to MP_Appointments
      const approvedAppointment = {
        id: selectedAppointment.id,
        name: selectedAppointment.name,
        date: selectedAppointment.date,
        timeslot: selectedAppointment.timeslot,
        status: "Approved"
      };

      // Get existing appointments from localStorage or use default
      const existingAppointments = JSON.parse(localStorage.getItem('mp_appointments') || '[]');
      
      // Check if appointment already exists to prevent duplicates
      const appointmentExists = existingAppointments.some(
        apt => apt.id === approvedAppointment.id
      );
      
      if (!appointmentExists) {
        const updatedAppointments = [...existingAppointments, approvedAppointment];
        localStorage.setItem('mp_appointments', JSON.stringify(updatedAppointments));
      }
    }
    setShowApproveModal(false);
    setSelectedAppointment(null);
  };

  // Handle reject confirmation
  const handleRejectConfirm = () => {
    if (selectedAppointment) {
      setAppointmentRequests(prev => 
        prev.map(appointment => 
          appointment.id === selectedAppointment.id 
            ? { ...appointment, status: "Rejected" }
            : appointment
        )
      );
    }
    setShowRejectModal(false);
    setSelectedAppointment(null);
  };

  // Handle approve modal close
  const handleApproveClose = () => {
    setShowApproveModal(false);
    setSelectedAppointment(null);
  };

  // Handle reject modal close
  const handleRejectClose = () => {
    setShowRejectModal(false);
    setSelectedAppointment(null);
  };

  // Filter logic based on activeFilter
  const filteredRequests = appointmentRequests.filter((request) => {
    if (activeFilter === 'all') {
      return true; // No filtering for 'all'
    }
    return request.status.toLowerCase() === activeFilter;
  }).filter(request =>
    request.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Function to get status button style based on status
  const getStatusButtonStyle = (status) => {
    const baseStyle = {
      border: 'none',
      borderRadius: '12px',
      padding: '4px 12px',
      cursor: 'pointer',
      fontSize: '11px',
      fontWeight: '500',
    };

    switch (status.toLowerCase()) {
      case 'approved':
        return {
          ...baseStyle,
          backgroundColor: "#9FC03B",
          color: '#fff',
        };
      case 'rejected':
        return {
          ...baseStyle,
          backgroundColor: '#dc3545',
          color: '#fff',
        };
      case 'pending':
      default:
        return {
          ...baseStyle,
          backgroundColor: colors.l_gray,
          color: '#fff',
        };
    }
  };

  const styles = {
    container: {
      display: 'flex',
      flexDirection: 'row',
      height: '100vh',
      backgroundColor: '#FEFFFD',
      overflow: 'auto',
    },
    sidebar: {
      backgroundColor: '#F1F1F2',
      padding: '17px 15px',
      width: isCollapsed ? '80px' : '230px',
      transition: 'width 0.3s ease, padding 0.3s ease',
      display: 'flex',
      flexDirection: 'column',
    },
    brand: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '15px',
      padding: isCollapsed ? '0' : '0 10px',
      justifyContent: isCollapsed ? 'center' : 'flex-start',
    },
    brandIcon: {
      width: '47px',
      height: '40px',
    },
    brandText: {
      fontSize: '25px',
      color: colors.d_gray,
      fontWeight: 'bold',
      fontStyle: 'italic',
      marginLeft: '15px',
    },
    menuContainer: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
    },
    menuGroup: {
      marginBottom: '20px',
    },
    menuDivider: {
      height: '1px',
      backgroundColor: '#e0e0e0',
      marginBottom: '15px',
    },
    menuItem: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemActive: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'rgba(159, 192, 59, 0.2)',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemCollapsed: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '12px 8px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuIcon: {
      fontSize: '20px',
      marginRight: isCollapsed ? '0' : '12px',
      color: colors.main,
      display: 'flex',
      alignItems: 'center',
    },
    menuText: {
      fontSize: '14px',
      color: colors.d_gray,
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    menuTextActive: {
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '600',
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    logoutButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#fff',
      border: 'none',
      borderRadius: '30px',
      padding: isCollapsed ? '2px 3px' : '7px 12px',
      marginTop: '20px',
      marginBottom: '10px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      width: isCollapsed ? 'auto' : 'fit-content',
      alignSelf: 'center',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
    },
    logoutIcon: {
      background: 'none',
      fontSize: '18px',
      marginRight: isCollapsed ? '0' : '8px',
      display: 'flex',
      alignItems: 'center',
      color: colors.main,
    },
    logoutText: {
      background: 'none',
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '500',
    },
    mainContent: {
      flex: 1,
      backgroundColor: '#FEFFFD',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '30px',
    },
    collapseButton: {
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      fontSize: '10px',
      color: colors.l_gray,
      transition: 'background-color 0.2s ease',
      marginLeft: '-10px'
    },
    pageTitle: {
      fontSize: '28px',
      fontWeight: 'bold',
      color: colors.main,
      marginBottom: '20px',
    },
    profileButton: {
      color: colors.main,      
      marginTop: '5px',
      marginRight: '5px',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontSize: '32px',
    },
    searchContainer: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '20px',
      gap: '15px',
    },
    searchBox: {
      display: 'flex',
      alignItems: 'center',
      backgroundColor: '#fff',
      border: '1px solid #e0e0e0',
      borderRadius: '8px',
      padding: '10px 15px',
      flex: 1,
      maxWidth: '400px',
    },
    searchIcon: {
      color: '#999',
      marginRight: '10px',
      fontSize: '16px',
    },
    searchInput: {
      border: 'none',
      outline: 'none',
      flex: 1,
      fontSize: '14px',
      color: '#333',
    },
    filterContainer: {
      display: 'flex',
      gap: '10px',
    },
    filterButton: {
      backgroundColor: '#fff',
      color: colors.d_gray,
      border: '1px solid #e0e0e0',
      borderRadius: '6px',
      padding: '10px 20px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '500',
      transition: 'all 0.2s ease',
    },
    filterButtonActive: {
      backgroundColor: colors.l_gray,
      color: '#fff',
      border: '1px solid ' + colors.l_gray,
      borderRadius: '6px',
      padding: '8px 16px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '600',
      transition: 'all 0.2s ease',
    },
    tableContainer: {
      backgroundColor: '#fff',
      borderRadius: '8px',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
      overflow: 'hidden',
    },
    table: {
      width: '100%',
      borderCollapse: 'collapse',
    },
    tableHeader: {
      backgroundColor: '#f8f9fa',
      borderBottom: '1px solid #e0e0e0',
    },
    tableHeaderCell: {
      padding: '15px 12px',
      textAlign: 'left',
      fontSize: '14px',
      fontWeight: '600',
      color: '#333',
      borderBottom: '1px solid #e0e0e0',
    },
    tableRow: {
      borderBottom: '1px solid #f0f0f0',
    },
    tableCell: {
      padding: '12px',
      fontSize: '14px',
      color: '#333',
      borderBottom: '1px solid #f0f0f0',
    },
    actionButtons: {
      display: 'flex',
      gap: '6px',
    },
    approveButton: {
      backgroundColor: colors.main,
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '4px 8px',
      cursor: 'pointer',
      fontSize: '11px',
      transition: 'background-color 0.2s ease',
    },
    rejectButton: {
      backgroundColor: '#dc3545',
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '4px 8px',
      cursor: 'pointer',
      fontSize: '11px',
      transition: 'background-color 0.2s ease',
    },
    disabledButton: {
      backgroundColor: '#6c757d',
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '4px 8px',
      cursor: 'not-allowed',
      fontSize: '11px',
      opacity: '0.6',
    },
  };

  const menuItems = [
    { name: 'Dashboard', icon: <FaHome />, active: activeMenu === 'dashboard', route: 'dashboard' },
    { name: 'Appointment Requests', icon: <FaCalendarAlt />, active: activeMenu === 'appointment-requests', route: 'appointment-requests' },
    { name: 'Appointments', icon: <FaCalendarCheck />, active: activeMenu === 'appointments', route: 'appointments' },
  ];

  const renderMenuItem = (item, index) => {
    const menuItemStyle = item.active 
      ? (isCollapsed ? styles.menuItemCollapsed : styles.menuItemActive)
      : (isCollapsed ? styles.menuItemCollapsed : styles.menuItem);
    
    const menuTextStyle = item.active ? styles.menuTextActive : styles.menuText;

    return (
      <button
        key={index}
        style={menuItemStyle}
        onClick={() => handleMenuClick(item.route)}
        onMouseEnter={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'rgba(159, 192, 59, 0.1)';
          }
        }}
        onMouseLeave={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'transparent';
          }
        }}
      >
        <span style={styles.menuIcon}>{item.icon}</span>
        {!isCollapsed && (
          <span style={menuTextStyle}>
            {item.name}
          </span>
        )}
      </button>
    );
  };

  return (
    <div style={styles.container}>
      {/* Sidebar */}
      <div style={styles.sidebar}>
        {/* Brand */}
        <div style={styles.brand}>
          <img 
            src="/fnw1.png" 
            alt="FitNWell Logo"
            style={styles.brandIcon}
          />
          {!isCollapsed && (
            <span style={styles.brandText}>FitNWell</span>
          )}
        </div>

        {/* Menu Items */}
        <div style={styles.menuContainer}>
          <div style={styles.menuDivider} />
          <div style={styles.menuGroup}>
            {menuItems.map((item, index) => renderMenuItem(item, index))}
          </div>
        </div>

        {/* Logout Button */}
        <button 
          style={styles.logoutButton}
          onClick={handleLogout}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#f5f5f5';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#fff';
          }}
        >
          <span style={styles.logoutIcon}><CiLogout /></span>
          {!isCollapsed && (
            <span style={styles.logoutText}>Log Out</span>
          )}
        </button>
      </div>

      {/* Main Content */}
      <div style={styles.mainContent}>
        {/* Header */}
        <div style={styles.header}>
          <button 
            style={styles.collapseButton}
            onClick={() => setIsCollapsed(!isCollapsed)}
          >
            {isCollapsed ? <FaChevronRight /> : <FaChevronLeft />}
          </button>
          <span style={styles.pageTitle}>Appointment Requests</span>
          <button style={styles.profileButton}
          onClick={() => navigate('/mp-user-profile')}
          >
            <FaUserCircle />
          </button>
        </div>

         {/* Search and Filter */}
         <div style={styles.searchContainer}>
           <div style={styles.searchBox}>
             <FaSearch style={styles.searchIcon} />
             <input
               type="text"
               placeholder="Search"
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
               style={styles.searchInput}
             />
           </div>
           <div style={styles.filterContainer}>
             {['all', 'pending', 'approved', 'rejected'].map((filter) => (
               <button
                 key={filter}
                 style={activeFilter === filter ? styles.filterButtonActive : styles.filterButton}
                 onClick={() => setActiveFilter(filter)}
               >
                 {filter.charAt(0).toUpperCase() + filter.slice(1)}
               </button>
             ))}
           </div>
         </div>

        {/* Appointments Table */}
        <div style={styles.tableContainer}>
          <table style={styles.table}>
            <thead style={styles.tableHeader}>
              <tr>
                <th style={styles.tableHeaderCell}>ID</th>
                <th style={styles.tableHeaderCell}>Name</th>
                <th style={styles.tableHeaderCell}>Date</th>
                <th style={styles.tableHeaderCell}>Timeslot</th>
                <th style={styles.tableHeaderCell}>Status</th>
                <th style={styles.tableHeaderCell}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredRequests.map((appointment) => (
                <tr 
                  key={appointment.id} 
                  style={styles.tableRow}
                  onMouseEnter={(e) => {
                    e.target.parentElement.style.backgroundColor = '#f8f9fa';
                  }}
                  onMouseLeave={(e) => {
                    e.target.parentElement.style.backgroundColor = 'transparent';
                  }}
                >
                  <td style={styles.tableCell}>{appointment.id}</td>
                  <td style={styles.tableCell}>{appointment.name}</td>
                  <td style={styles.tableCell}>{appointment.date}</td>
                  <td style={styles.tableCell}>{appointment.timeslot}</td>
                  <td style={styles.tableCell}>
                    <button style={getStatusButtonStyle(appointment.status)}>
                      {appointment.status}
                    </button>
                  </td>
                  <td style={styles.tableCell}>
                    <div style={styles.actionButtons}>
                      {appointment.status === 'Pending' ? (
                        <>
                          <button 
                            style={styles.approveButton}
                            onClick={() => handleApproveClick(appointment)}
                            onMouseEnter={(e) => {
                              e.target.style.backgroundColor = '#8a9c3b';
                            }}
                            onMouseLeave={(e) => {
                              e.target.style.backgroundColor = colors.main;
                            }}
                          >
                            Approve
                          </button>
                          <button 
                            style={styles.rejectButton}
                            onClick={() => handleRejectClick(appointment)}
                            onMouseEnter={(e) => {
                              e.target.style.backgroundColor = '#f25555';
                            }}
                            onMouseLeave={(e) => {
                              e.target.style.backgroundColor = '#dc3545';
                            }}
                          >
                            Reject
                          </button>
                        </>
                      ) : (
                        <>
                          <button style={styles.disabledButton} disabled>
                            Approve
                          </button>
                          <button style={styles.disabledButton} disabled>
                            Reject
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Components */}
      <MPApprove 
        visible={showApproveModal} 
        onClose={handleApproveClose} 
        onConfirm={handleApproveConfirm} 
      />
      <MPReject 
        visible={showRejectModal} 
        onClose={handleRejectClose} 
        onConfirm={handleRejectConfirm} 
      />
    </div>
  );
};

export default MP_Requests;