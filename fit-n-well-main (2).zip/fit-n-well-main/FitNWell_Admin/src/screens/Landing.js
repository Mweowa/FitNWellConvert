import React from 'react';
import { useNavigate } from 'react-router-dom';
import { colors } from '../utils/colors';
import adminBg from '../assets/photos/adminbg.png';
import fnwLogo from '../assets/photos/fnw1.png';

export default function Landing({ onButtonClick }) {
  const [hoveredButton, setHoveredButton] = React.useState(null);
  const navigate = useNavigate();

  const handleMouseEnter = (buttonIndex) => {
    setHoveredButton(buttonIndex);
  };

  const handleMouseLeave = () => {
    setHoveredButton(null);
  };

  const handleButtonClick = (role) => {
    onButtonClick(role);
    navigate('/login');
  };

  return (
    <div style={styles.container}>
      <img
        src={adminBg}
        style={styles.backgroundImage}
        alt="Background"
      />
      <div style={styles.centerBox}>
        <img
          src={fnwLogo}
          style={styles.logo}
          alt="FitNWell Logo"
        />
        <h1 style={styles.title}>FitNWell</h1>
        <button 
          style={{
            ...styles.button,
            ...(hoveredButton === 0 && styles.buttonHover)
          }}
          onMouseEnter={() => handleMouseEnter(0)}
          onMouseLeave={handleMouseLeave}
          onClick={() => handleButtonClick('College of Human Kinetics')}
        >
          <span style={styles.buttonText}>College of Human Kinetics</span>
        </button>
        <button 
          style={{
            ...styles.button,
            ...(hoveredButton === 1 && styles.buttonHover)
          }}
          onMouseEnter={() => handleMouseEnter(1)}
          onMouseLeave={handleMouseLeave}
          onClick={() => handleButtonClick('Coach')}
        >
          <span style={styles.buttonText}>Coach</span>
        </button>
        <button 
          style={{
            ...styles.button,
            ...(hoveredButton === 2 && styles.buttonHover)
          }}
          onMouseEnter={() => handleMouseEnter(2)}
          onMouseLeave={handleMouseLeave}
          onClick={() => handleButtonClick('Muscle Pain Management')}
        >
          <span style={styles.buttonText}>Muscle Pain Management</span>
        </button>
      </div>
    </div>
  );
}

const styles = {
  container: {
    width: '100vw',
    height: '100vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
    overflow: 'hidden',
  },
  backgroundImage: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    objectFit: 'cover',
    zIndex: 0,
  },
  centerBox: {
    backgroundColor: '#FBFBFB',
    borderRadius: '28px',
    padding: '48px 40px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    width: '390px',
    height: '600px',
    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.25), 0 4px 16px rgba(0, 0, 0, 0.15)',
    opacity: 1.0,
    zIndex: 1,
    position: 'relative',
  },
  logo: {
    width: '160px',
    height: '120px',
    marginTop: '10px',
    marginBottom: '2px',
    objectFit: 'contain',
  },
  title: {
    fontSize: '32px',
    color: colors.d_gray,
    fontWeight: 'bold',
    fontStyle: 'italic',
    margin: '0 0 75px 0',
    letterSpacing: -0.5,
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#fff',
    borderRadius: '28px',
    padding: '14px 24px',
    margin: '8px 0',
    width: '290px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.08)',
    border: 'none',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
  },
  buttonText: {
    color: colors.d_gray,
    fontSize: '13px',
    fontWeight: 'bold',
    margin: 0,
  },
  buttonHover: {
    backgroundColor: '#f8f9fa',
    transform: 'translateY(-2px)',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
  },
}; 