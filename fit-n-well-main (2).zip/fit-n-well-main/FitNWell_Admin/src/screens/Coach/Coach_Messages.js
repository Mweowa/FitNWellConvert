import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { colors } from '../../utils/colors';
import { FaUserCircle, FaHome, FaClipboardList, FaList, FaSearch } from "react-icons/fa";
import { FaCalendarPlus } from "react-icons/fa6";
import { IoScaleSharp, IoChatbubbleSharp, IoSend } from "react-icons/io5";
import { MdFactCheck } from "react-icons/md";
import { CiLogout } from "react-icons/ci";
import { FaChevronRight, FaChevronLeft } from "react-icons/fa";
import { TiPlus } from "react-icons/ti";

const Coach_Messages = ({ onLogout }) => {
  const navigate = useNavigate();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeMenu, setActiveMenu] = useState('messages');
  const [selectedUser, setSelectedUser] = useState('Christian Rovero');
  const [showNewConversationModal, setShowNewConversationModal] = useState(false);
  const [newUserName, setNewUserName] = useState('');

  // Conversation data - moved to state
  const [conversations, setConversations] = useState({
    'Christian Rovero': [
      { id: 1, sender: 'user', name: 'Christian Rovero', text: "I'm done coach with my workout. Today was really challenging but I managed to complete all the exercises you assigned to me. Thank you for the motivation!", time: '5:34 PM' },
      { id: 2, sender: 'coach', text: "Okay, got it! That's amazing progress. Keep up the excellent work and remember to stay hydrated and get proper rest.", time: 'Just Now' },
    ],
    'Marilyn Ruiz': [
      { id: 1, sender: 'user', name: 'Marilyn Ruiz', text: "Currently working on the leg day routine you gave me. The squats are really intense!", time: '8:17 AM' },
      { id: 2, sender: 'coach', text: "Great to hear! Remember to maintain proper form. How many reps are you doing?", time: '8:20 AM' },
      { id: 3, sender: 'user', name: 'Marilyn Ruiz', text: "I'm doing 3 sets of 12 reps. Should I increase it?", time: '8:25 AM' },
    ]
  });

  // User order state to track the order of users based on latest message
  const [userOrder, setUserOrder] = useState(['Christian Rovero', 'Marilyn Ruiz']);

  // Chat state
  const [messages, setMessages] = useState(conversations[selectedUser]);
  const [inputMessage, setInputMessage] = useState('');
  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);

  const scrollToBottom = () => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    setMessages(conversations[selectedUser]);
  }, [selectedUser, conversations]);

  // Auto-resize textarea
  const adjustTextareaHeight = () => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + 'px';
    }
  };

  useEffect(() => {
    adjustTextareaHeight();
  }, [inputMessage]);

  const handleLogout = () => {
    onLogout();
    navigate('/');
  };

  const handleMenuClick = (route) => {
    setActiveMenu(route);
    if (route === 'dashboard') {
      navigate('/coach-dashboard');
    } else if (route === 'plan-requests') {
      navigate('/coach-plan-requests');
    } else if (route === 'fitness-plans') {
      navigate('/coach-fitness-plans');
    } else if (route === 'activity-logs') {
      navigate('/coach-activity-logs');
    } else if (route === 'fitness-assessments') {
      navigate('/coach-fitness-assessments');
    } else if (route === 'measurements') {
      navigate('/coach-measurements');
    } else if (route === 'messages') {
      navigate('/coach-messages');
    }
  };

  const moveUserToTop = (userName) => {
    setUserOrder(prevOrder => {
      const newOrder = prevOrder.filter(user => user !== userName);
      return [userName, ...newOrder];
    });
  };

  const createNewConversation = () => {
    if (newUserName.trim() === '') return;
    
    const trimmedName = newUserName.trim();
    
    // Check if conversation already exists
    if (conversations[trimmedName]) {
      setSelectedUser(trimmedName);
      moveUserToTop(trimmedName);
    } else {
      // Create new conversation
      const newConversation = [];
      
      setConversations(prevConversations => ({
        ...prevConversations,
        [trimmedName]: newConversation
      }));
      
      setUserOrder(prevOrder => [trimmedName, ...prevOrder]);
      setSelectedUser(trimmedName);
    }
    
    setNewUserName('');
    setShowNewConversationModal(false);
  };

  const sendMessage = () => {
    if (inputMessage.trim() === '') return;
    const newMessage = {
      id: messages.length + 1,
      sender: 'coach',
      text: inputMessage.trim(),
      time: 'Just Now',
    };
    const updatedMessages = [...messages, newMessage];
    setMessages(updatedMessages);
    
    // Update the conversations state to persist the message
    setConversations(prevConversations => ({
      ...prevConversations,
      [selectedUser]: updatedMessages
    }));
    
    // Move current user to top of the list
    moveUserToTop(selectedUser);
    
    setInputMessage('');
    
    // Reset textarea height
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.ctrlKey) {
      e.preventDefault();
      sendMessage();
    }
    // Allow Shift+Enter or Ctrl+Enter for new lines
  };

  const handleNewConversationKeyPress = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      createNewConversation();
    }
  };

  // Filter users based on search term and maintain order
  const filteredUsers = userOrder.filter(user => 
    user.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const styles = {
    container: {
      display: 'flex',
      flexDirection: 'row',
      height: '100vh',
      backgroundColor: '#FEFFFD',
      overflow: 'auto',
    },
    sidebar: {
      backgroundColor: '#F1F1F2',
      padding: '17px 15px',
      width: isCollapsed ? '80px' : '230px',
      transition: 'width 0.3s ease, padding 0.3s ease',
      display: 'flex',
      flexDirection: 'column',
    },
    brand: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '15px',
      padding: isCollapsed ? '0' : '0 10px',
      justifyContent: isCollapsed ? 'center' : 'flex-start',
    },
    brandIcon: {
      width: '47px',
      height: '40px',
    },
    brandText: {
      fontSize: '25px',
      color: colors.d_gray,
      fontWeight: 'bold',
      fontStyle: 'italic',
      marginLeft: '15px',
    },
    menuContainer: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
    },
    menuGroup: {
      marginBottom: '20px',
    },
    menuDivider: {
      height: '1px',
      backgroundColor: '#e0e0e0',
      marginBottom: '15px',
    },
    menuItem: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemActive: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'rgba(159, 192, 59, 0.2)',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemCollapsed: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '12px 8px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuIcon: {
      fontSize: '20px',
      marginRight: isCollapsed ? '0' : '12px',
      color: colors.main,
      display: 'flex',
      alignItems: 'center',
    },
    menuText: {
      fontSize: '14px',
      color: colors.d_gray,
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    menuTextActive: {
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '600',
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    logoutButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#fff',
      border: 'none',
      borderRadius: '30px',
      padding: isCollapsed ? '2px 3px' : '7px 12px',
      marginTop: '20px',
      marginBottom: '10px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      width: isCollapsed ? 'auto' : 'fit-content',
      alignSelf: 'center',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
    },
    logoutIcon: {
      background: 'none',
      fontSize: '18px',
      marginRight: isCollapsed ? '0' : '8px',
      display: 'flex',
      alignItems: 'center',
      color: colors.main,
    },
    logoutText: {
      background: 'none',
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '500',
    },
    mainContent: {
      flex: 1,
      backgroundColor: '#FFFFFF',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
      borderRadius: '10px',
      marginLeft: '20px',
      marginRight: '20px',
      justifyContent: 'space-between',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '30px',
    },
    collapseButton: {
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      fontSize: '10px',
      color: colors.l_gray,
      transition: 'background-color 0.2s ease',
      marginLeft: '-10px'
    },
    pageTitle: {
      fontSize: '28px',
      fontWeight: 'bold',
      color: colors.main,
      marginBottom: '20px',
    },
    profileButton: {
      color: colors.main,
      marginTop: '5px',
      marginRight: '5px',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontSize: '32px',
    },
    searchContainer: {
      display: 'flex',
      alignItems: 'center',
      marginTop: '-10px',
      marginBottom: '-5px',
      gap: '15px',
      height: '48px', 
    },
    searchBox: {
      display: 'flex',
      alignItems: 'center',
      backgroundColor: '#fff',
      border: '1px solid #e0e0e0',
      borderRadius: '8px',
      padding: '10px 15px',
      flex: 1,
      maxWidth: '300px',
      height: '100%',
    },
    searchIcon: {
      color: '#999',
      marginRight: '10px',
      fontSize: '16px',
    },
    searchInput: {
      border: 'none',
      outline: 'none',
      flex: 1,
      fontSize: '14px',
      color: '#333',
    },
    messagesContainer: {
      flex: 1,
      overflowY: 'auto',
      padding: '10px',
      marginBottom: '10px',
      backgroundColor: '#f5f5f5',
      borderRadius: '10px',
      maxHeight: 'calc(100vh - 250px)',
    },
    messageRow: {
      display: 'flex',
      flexDirection: 'column',
      marginBottom: '15px',
      width: '100%',
    },
    messageRowUser: {
      alignItems: 'flex-start',
    },
    messageRowCoach: {
      alignItems: 'flex-end',
    },
    messageBubble: {
      maxWidth: '70%',
      minWidth: '60px',
      padding: '12px 16px',
      borderRadius: '18px',
      fontSize: '14px',
      lineHeight: '1.4',
      boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
      wordWrap: 'break-word',
      overflowWrap: 'break-word',
      wordBreak: 'break-word',
      hyphens: 'auto',
      whiteSpace: 'pre-wrap',
      width: 'fit-content',
    },
    messageBubbleUser: {
      backgroundColor: '#fff',
      color: '#333',
      borderTopRightRadius: '18px',
      borderTopLeftRadius: '4px',
      borderBottomLeftRadius: '18px',
      borderBottomRightRadius: '18px',
      alignSelf: 'flex-start',
    },
    messageBubbleCoach: {
      backgroundColor: '#fff',
      color: '#333',
      borderTopLeftRadius: '18px',
      borderTopRightRadius: '4px',
      borderBottomLeftRadius: '18px',
      borderBottomRightRadius: '18px',
      alignSelf: 'flex-end',
    },
    messageSender: {
      fontWeight: 'bold',
      marginBottom: '5px',
      fontSize: '12px',
      color: '#333',
    },
    messageTime: {
      fontSize: '11px',
      color: '#333',
      marginTop: '4px',
      textAlign: 'right',
    },
    messageTimeUser: {
      fontSize: '11px',
      color: '#333',
      marginTop: '4px',
      textAlign: 'right',
    },
    inputContainer: {
      display: 'flex',
      alignItems: 'flex-end',
      backgroundColor: '#ffffff',
      borderRadius: '30px',
      padding: '5px 15px',
      marginTop: 'auto',
      border: '1px solid #e0e0e0',
      minHeight: '48px',
      maxHeight: '140px',
    },
    inputField: {
      flex: 1,
      border: 'none',
      outline: 'none',
      borderRadius: '20px',
      padding: '10px 15px',
      fontSize: '14px',
      backgroundColor: '#ffffff',
      marginRight: '10px',
      resize: 'none',
      fontFamily: 'inherit',
      lineHeight: '1.4',
      minHeight: '20px',
      maxHeight: '120px',
      overflowY: 'auto',
      scrollbarWidth: 'thin',
      scrollbarColor: '#ccc #f5f5f5',
    },
    sendButton: {
      backgroundColor: 'transparent',
      border: 'none',
      cursor: 'pointer',
      color: colors.main,
      fontSize: '18px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '8px',
      marginBottom: '2px',
      flexShrink: 0,
    },
    chatSection: {
      display: 'flex', 
      flex: 1, 
      marginTop: '10px',
      height: 'calc(100vh - 200px)',
      paddingBottom: '10px'
    },
    userList: {
      width: '300px', 
      backgroundColor: '#ffffff', 
      borderRadius: '10px', 
      padding: '10px', 
      marginRight: '20px', 
      display: 'flex', 
      flexDirection: 'column',
      height: '100%',
      position: 'relative',
    },
    chatArea: {
      flex: 1, 
      display: 'flex', 
      flexDirection: 'column', 
      backgroundColor: '#f5f5f5', 
      borderRadius: '10px', 
      padding: '15px',
      height: '100%', 
    },
    floatingButton: {
      position: 'absolute',
      bottom: '-1px',
      right: '10px',
      width: '48px',
      height: '48px',
      borderRadius: '50%',
      backgroundColor: colors.main,
      border: 'none',
      color: '#fff',
      fontSize: '30px',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.2)',
      transition: 'all 0.2s ease',
      zIndex: 100,
    },
    modal: {
      position: 'fixed',
      top: '0',
      left: '0',
      width: '100%',
      height: '100%',
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1001,
    },
    modalContent: {
      backgroundColor: '#fff',
      borderRadius: '12px',
      padding: '24px',
      width: '400px',
      maxWidth: '90vw',
      boxShadow: '0 8px 32px rgba(0, 0, 0, 0.2)',
    },
    modalTitle: {
      fontSize: '20px',
      fontWeight: 'bold',
      color: colors.d_gray,
      marginBottom: '16px',
      textAlign: 'center',
    },
    modalInput: {
      width: '100%',
      padding: '12px 16px',
      border: '2px solid #e0e0e0',
      borderRadius: '8px',
      fontSize: '14px',
      outline: 'none',
      marginBottom: '20px',
      transition: 'border-color 0.2s ease',
    },
    modalButtons: {
      display: 'flex',
      gap: '12px',
      justifyContent: 'flex-end',
    },
    modalButton: {
      padding: '10px 20px',
      borderRadius: '8px',
      fontSize: '14px',
      fontWeight: '500',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      border: 'none',
    },
    modalButtonCancel: {
      backgroundColor: '#f5f5f5',
      color: colors.d_gray,
    },
    modalButtonCreate: {
      backgroundColor: colors.main,
      color: '#fff',
    },
  };

  const menuItems = [
    { name: 'Dashboard', icon: <FaHome />, route: 'dashboard', active: activeMenu === 'dashboard' },
    { name: 'Plan Requests', icon: <FaCalendarPlus />, route: 'plan-requests', active: activeMenu === 'plan-requests' },
    { name: 'Fitness Plans', icon: <FaList />, route: 'fitness-plans', active: activeMenu === 'fitness-plans' },
    { name: 'Activity Logs', icon: <FaClipboardList />, route: 'activity-logs', active: activeMenu === 'activity-logs' },
    { name: 'Fitness Assessments', icon: <MdFactCheck />, route: 'fitness-assessments', active: activeMenu === 'fitness-assessments' },
    { name: 'Measurements', icon: <IoScaleSharp />, route: 'measurements', active: activeMenu === 'measurements' },
    { name: 'Messages', icon: <IoChatbubbleSharp />, route: 'messages', active: activeMenu === 'messages' },
  ];

  const renderMenuItem = (item, index) => {
    const menuItemStyle = item.active
      ? (isCollapsed ? styles.menuItemCollapsed : styles.menuItemActive)
      : (isCollapsed ? styles.menuItemCollapsed : styles.menuItem);

    const menuTextStyle = item.active ? styles.menuTextActive : styles.menuText;

    return (
      <button
        key={index}
        style={menuItemStyle}
        onClick={() => handleMenuClick(item.route)}
        onMouseEnter={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'rgba(159, 192, 59, 0.1)';
          }
        }}
        onMouseLeave={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'transparent';
          }
        }}
      >
        <span style={styles.menuIcon}>{item.icon}</span>
        {!isCollapsed && (
          <span style={menuTextStyle}>
            {item.name}
          </span>
        )}
      </button>
    );
  };

  return (
    <div style={styles.container}>
      {/* Sidebar */}
      <div style={styles.sidebar}>
        {/* Brand */}
        <div style={styles.brand}>
          <img
            src="/fnw1.png"
            alt="FitNWell Logo"
            style={styles.brandIcon}
          />
          {!isCollapsed && (
            <span style={styles.brandText}>FitNWell</span>
          )}
        </div>

        {/* Menu Items */}
        <div style={styles.menuContainer}>
          <div style={styles.menuDivider} />

          <div style={styles.menuGroup}>
            {menuItems.slice(0, 7).map((item, index) => renderMenuItem(item, index))}
          </div>

          <div style={styles.menuGroup}>
            {menuItems.slice(7).map((item, index) => renderMenuItem(item, index + 7))}
          </div>
        </div>

        {/* Logout Button */}
        <button
          style={styles.logoutButton}
          onClick={onLogout}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#f5f5f5';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#fff';
          }}
        >
          <span style={styles.logoutIcon}><CiLogout /></span>
          {!isCollapsed && (
            <span style={styles.logoutText}>Log Out</span>
          )}
        </button>
      </div>

      {/* Main Content */}
      <div style={styles.mainContent}>
        {/* Header */}
        <div style={styles.header}>
          <button
            style={styles.collapseButton}
            onClick={() => setIsCollapsed(!isCollapsed)}
          >
            {isCollapsed ? <FaChevronRight /> : <FaChevronLeft />}
          </button>
          <span style={styles.pageTitle}>Messages</span>
          <button style={styles.profileButton}
          onClick={() => navigate('/coach-user-profile')}
          >
            <FaUserCircle />
          </button>
        </div>

        {/* Search */}
        <div style={styles.searchContainer}>
          <div style={styles.searchBox}>
            <FaSearch style={styles.searchIcon} />
            <input
              type="text"
              placeholder="Search user"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={styles.searchInput}
            />
          </div>
        </div>

        {/* Messages List and Chat Area */}
        <div style={styles.chatSection}>
          {/* User List */}
          <div style={styles.userList}>
            <div style={{ flex: 1, overflowY: 'auto' }}>
              {/* Filtered users based on search and sorted by message activity */}
              {filteredUsers.map((userName, index) => (
<div 
  key={userName} 
  style={{
    padding: '10px', 
    borderTop: index === 0 ? '1px solid #ddd' : 'none',
    borderBottom: '1px solid #ddd', 
    cursor: 'pointer',
    backgroundColor: selectedUser === userName ? 'rgba(159, 192, 59, 0.2)' : 'transparent',  // Same highlight color as the menu
    transition: 'background-color 0.2s ease',
  }}
  onClick={() => setSelectedUser(userName)} // Click to select conversation
>
  <div style={{ fontSize: '14px', color: '#333', fontWeight: '600' }}>{userName}</div>
  <div style={{ fontSize: '14px', color: '#333', marginTop: '6px' }}>
    {conversations[userName][conversations[userName].length - 1]?.text.length > 27
      ? conversations[userName][conversations[userName].length - 1]?.text.slice(0, 27) + '...'
      : conversations[userName][conversations[userName].length - 1]?.text
    }
  </div>
  <div style={{ fontSize: '12px', color: '#333', textAlign: 'right' }}>
    {conversations[userName][conversations[userName].length - 1]?.time}
  </div>
</div>



              ))}
            </div>

            {/* Floating Add Button - positioned within user list */}
            <button
              style={styles.floatingButton}
              onClick={() => setShowNewConversationModal(true)}
              onMouseEnter={(e) => {
                e.target.style.transform = 'scale(1.05)';
                e.target.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.3)';
              }}
              onMouseLeave={(e) => {
                e.target.style.transform = 'scale(1)';
                e.target.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.2)';
              }}
            >
              +
            </button>
          </div>

          {/* Chat Area */}
          <div style={styles.chatArea}>
            <div style={styles.messagesContainer}>
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  style={{
                    ...styles.messageRow,
                    ...(msg.sender === 'user' ? styles.messageRowUser : styles.messageRowCoach),
                  }}
                >
                  {msg.sender === 'user' && (
                    <div style={styles.messageSender}>
                      {msg.name}
                    </div>
                  )}
                  <div
                    style={{
                      ...styles.messageBubble,
                      ...(msg.sender === 'user' ? styles.messageBubbleUser : styles.messageBubbleCoach),
                    }}
                  >  
                    <div>{msg.text}</div>
                    <div style={msg.sender === 'user' ? styles.messageTimeUser : styles.messageTime}>
                      {msg.time}
                    </div>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input */}
            <div style={styles.inputContainer}>
              <textarea
                ref={textareaRef}
                placeholder="Message"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyDown={handleKeyPress}
                style={styles.inputField}
                rows={1}
              />
              <button onClick={sendMessage} style={styles.sendButton} aria-label="Send message">
                <IoSend />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* New Conversation Modal */}
      {showNewConversationModal && (
        <div style={styles.modal} onClick={(e) => {
          if (e.target === e.currentTarget) {
            setShowNewConversationModal(false);
            setNewUserName('');
          }
        }}>
          <div style={styles.modalContent}>
            <h3 style={styles.modalTitle}>New Conversation</h3>
            <input
              type="text"
              placeholder="Name"
              value={newUserName}
              onChange={(e) => setNewUserName(e.target.value)}
              onKeyPress={handleNewConversationKeyPress}
              style={{
                ...styles.modalInput,
                borderColor: newUserName.trim() ? colors.main : '#e0e0e0'
              }}
              autoFocus
            />
            <div style={styles.modalButtons}>
              <button
                style={{...styles.modalButton, ...styles.modalButtonCancel}}
                onClick={() => {
                  setShowNewConversationModal(false);
                  setNewUserName('');
                }}
                onMouseEnter={(e) => {
                  e.target.style.backgroundColor = '#e0e0e0';
                }}
                onMouseLeave={(e) => {
                  e.target.style.backgroundColor = '#f5f5f5';
                }}
              >
                Cancel
              </button>
              <button
                style={{...styles.modalButton, ...styles.modalButtonCreate}}
                onClick={createNewConversation}
                disabled={!newUserName.trim()}
                onMouseEnter={(e) => {
                  if (newUserName.trim()) {
                    e.target.style.backgroundColor = '#8fb83b';
                  }
                }}
                onMouseLeave={(e) => {
                  if (newUserName.trim()) {
                    e.target.style.backgroundColor = colors.main;
                  }
                }}
              >
                Create
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Coach_Messages;