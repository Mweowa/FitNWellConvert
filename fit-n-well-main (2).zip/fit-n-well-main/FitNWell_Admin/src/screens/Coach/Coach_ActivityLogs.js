import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { colors } from '../../utils/colors';
import { FaUserCircle, FaHome, FaClipboardList, FaList, FaSearch } from "react-icons/fa";
import { FaCalendarPlus } from "react-icons/fa6";
import { IoScaleSharp, IoChatbubbleSharp } from "react-icons/io5";
import { MdFactCheck } from "react-icons/md";
import { CiLogout } from "react-icons/ci";
import { FaChevronRight, FaChevronLeft } from "react-icons/fa";

const Coach_ActivityLogs = ({ onLogout }) => {
  const navigate = useNavigate();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeMenu, setActiveMenu] = useState('activity-logs');
  

  const handleLogout = () => {
    onLogout();
    navigate('/');
  };

  const handleMenuClick = (route) => {
    setActiveMenu(route);
    if (route === 'dashboard') {
      navigate('/coach-dashboard');
    } else if (route === 'plan-requests') {
      navigate('/coach-plan-requests');
    } else if (route === 'fitness-plans') {
      navigate('/coach-fitness-plans');
    } else if (route === 'activity-logs') {
      navigate('/coach-activity-logs');
    } else if (route === 'fitness-assessments') {
      navigate('/coach-fitness-assessments');
    } else if (route === 'measurements') {
      navigate('/coach-measurements');
    } else if (route === 'messages') {
      navigate('/coach-messages');
    }
  };

  // Sample activity logs data
  const [activityLogs] = useState([
    {
      id: 1,
      name: "Jimmy Reyes"
    },
    {
      id: 2,
      name: "Grace Mendoza"
    },
    {
      id: 3,
      name: "Carlo Chua"
    },
    {
      id: 4,
      name: "Daniel Torres"
    }
  ]);

  // View Logs handler - Updated to navigate to ALView
  const handleViewLogs = (activityLog) => {
    console.log('Viewing logs for:', activityLog.name);
    // Navigate to ALView with client name as URL parameter
    navigate(`/coach-activity-logs-view/${encodeURIComponent(activityLog.name)}`);
  };

  const styles = {
    container: {
      display: 'flex',
      flexDirection: 'row',
      height: '100vh',
      backgroundColor: '#FEFFFD',
      overflow: 'auto',
    },
    sidebar: {
      backgroundColor: '#F1F1F2',
      padding: '17px 15px',
      width: isCollapsed ? '80px' : '230px',
      transition: 'width 0.3s ease, padding 0.3s ease',
      display: 'flex',
      flexDirection: 'column',
    },
    brand: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '15px',
      padding: isCollapsed ? '0' : '0 10px',
      justifyContent: isCollapsed ? 'center' : 'flex-start',
    },
    brandIcon: {
      width: '47px',
      height: '40px',
    },
    brandText: {
      fontSize: '25px',
      color: colors.d_gray,
      fontWeight: 'bold',
      fontStyle: 'italic',
      marginLeft: '15px',
    },
    menuContainer: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
    },
    menuGroup: {
      marginBottom: '20px',
    },
    menuDivider: {
      height: '1px',
      backgroundColor: '#e0e0e0',
      marginBottom: '15px',
    },
    menuItem: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemActive: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'rgba(159, 192, 59, 0.2)',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemCollapsed: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '12px 8px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuIcon: {
      fontSize: '20px',
      marginRight: isCollapsed ? '0' : '12px',
      color: colors.main,
      display: 'flex',
      alignItems: 'center',
    },
    menuText: {
      fontSize: '14px',
      color: colors.d_gray,
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    menuTextActive: {
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '600',
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    logoutButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#fff',
      border: 'none',
      borderRadius: '30px',
      padding: isCollapsed ? '2px 3px' : '7px 12px',
      marginTop: '20px',
      marginBottom: '10px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      width: isCollapsed ? 'auto' : 'fit-content',
      alignSelf: 'center',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
    },
    logoutIcon: {
      background: 'none',
      fontSize: '18px',
      marginRight: isCollapsed ? '0' : '8px',
      display: 'flex',
      alignItems: 'center',
      color: colors.main,
    },
    logoutText: {
      background: 'none',
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '500',
    },
    mainContent: {
      flex: 1,
      backgroundColor: '#FEFFFD',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '30px',
    },
    collapseButton: {
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      fontSize: '10px',
      color: colors.l_gray,
      transition: 'background-color 0.2s ease',
      marginLeft: '-10px'
    },
    pageTitle: {
      fontSize: '28px',
      fontWeight: 'bold',
      color: colors.main,
      marginBottom: '20px',
    },
    profileButton: {
      color: colors.main,      
      marginTop: '5px',
      marginRight: '5px',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontSize: '32px',
    },
    searchContainer: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '20px',
      gap: '15px',
    },
    searchBox: {
      display: 'flex',
      alignItems: 'center',
      backgroundColor: '#fff',
      border: '1px solid #e0e0e0',
      borderRadius: '8px',
      padding: '10px 15px',
      flex: 1,
      maxWidth: '400px',
    },
    searchIcon: {
      color: '#999',
      marginRight: '10px',
      fontSize: '16px',
    },
    searchInput: {
      border: 'none',
      outline: 'none',
      flex: 1,
      fontSize: '14px',
      color: '#333',
    },
    tableContainer: {
      backgroundColor: '#fff',
      borderRadius: '8px',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
      overflow: 'hidden',
    },
    table: {
      width: '100%',
      borderCollapse: 'collapse',
    },
    tableHeader: {
      backgroundColor: '#f8f9fa',
      borderBottom: '1px solid #e0e0e0',
    },
    tableHeaderCell: {
      padding: '15px 12px',
      textAlign: 'left',
      fontSize: '14px',
      fontWeight: '600',
      color: '#333',
      borderBottom: '1px solid #e0e0e0',
    },
    tableRow: {
      borderBottom: '1px solid #f0f0f0',
    },
    tableCell: {
      padding: '12px',
      fontSize: '14px',
      color: '#333',
      borderBottom: '1px solid #f0f0f0',
    },
    actionButtons: {
      display: 'flex',
      gap: '8px',
    },
    viewLogsButton: {
      backgroundColor: colors.view,
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '6px 12px',
      cursor: 'pointer',
      fontSize: '12px',
      transition: 'background-color 0.2s ease',
    },
  };

  const menuItems = [
    { name: 'Dashboard', icon: <FaHome />, route: 'dashboard', active: activeMenu === 'dashboard' },
    { name: 'Plan Requests', icon: <FaCalendarPlus />, route: 'plan-requests', active: activeMenu === 'plan-requests' },
    { name: 'Fitness Plans', icon: <FaList />, route: 'fitness-plans', active: activeMenu === 'fitness-plans' },
    { name: 'Activity Logs', icon: <FaClipboardList />, route: 'activity-logs', active: activeMenu === 'activity-logs' },
    { name: 'Fitness Assessments', icon: <MdFactCheck />, route: 'fitness-assessments', active: activeMenu === 'fitness-assessments' },
    { name: 'Measurements', icon: <IoScaleSharp />, route: 'measurements', active: activeMenu === 'measurements' },
    { name: 'Messages', icon: <IoChatbubbleSharp />, route: 'messages', active: activeMenu === 'messages' },
  ];

  const renderMenuItem = (item, index) => {
    const menuItemStyle = item.active 
      ? (isCollapsed ? styles.menuItemCollapsed : styles.menuItemActive)
      : (isCollapsed ? styles.menuItemCollapsed : styles.menuItem);
    
    const menuTextStyle = item.active ? styles.menuTextActive : styles.menuText;

    return (
      <button
        key={index}
        style={menuItemStyle}
        onClick={() => handleMenuClick(item.route)}
        onMouseEnter={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'rgba(159, 192, 59, 0.1)';
          }
        }}
        onMouseLeave={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'transparent';
          }
        }}
      >
        <span style={styles.menuIcon}>{item.icon}</span>
        {!isCollapsed && (
          <span style={menuTextStyle}>
            {item.name}
          </span>
        )}
      </button>
    );
  };

  const filteredActivityLogs = activityLogs.filter(activityLog =>
    activityLog.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div style={styles.container}>
      {/* Sidebar */}
      <div style={styles.sidebar}>
        {/* Brand */}
        <div style={styles.brand}>
          <img 
            src="/fnw1.png" 
            alt="FitNWell Logo"
            style={styles.brandIcon}
          />
          {!isCollapsed && (
            <span style={styles.brandText}>FitNWell</span>
          )}
        </div>

        {/* Menu Items */}
        <div style={styles.menuContainer}>
          <div style={styles.menuDivider} />
          
          <div style={styles.menuGroup}>
            {menuItems.slice(0, 7).map((item, index) => renderMenuItem(item, index))}
          </div>
          
          <div style={styles.menuGroup}>
            {menuItems.slice(7).map((item, index) => renderMenuItem(item, index + 7))}
          </div>
        </div>

        {/* Logout Button */}
        <button 
          style={styles.logoutButton}
          onClick={onLogout}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#f5f5f5';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#fff';
          }}
        >
          <span style={styles.logoutIcon}><CiLogout /></span>
          {!isCollapsed && (
            <span style={styles.logoutText}>Log Out</span>
          )}
        </button>
      </div>

      {/* Main Content */}
      <div style={styles.mainContent}>
        {/* Header */}
        <div style={styles.header}>
          <button 
            style={styles.collapseButton}
            onClick={() => setIsCollapsed(!isCollapsed)}
          >
            {isCollapsed ? <FaChevronRight /> : <FaChevronLeft />}
          </button>
          <span style={styles.pageTitle}>Activity Logs</span>
          <button style={styles.profileButton}
          onClick={() => navigate('/coach-user-profile')}
          >
            <FaUserCircle />
          </button>
        </div>

        {/* Search */}
        <div style={styles.searchContainer}>
          <div style={styles.searchBox}>
            <FaSearch style={styles.searchIcon} />
            <input
              type="text"
              placeholder="Search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={styles.searchInput}
            />
          </div>
        </div>

        {/* Activity Logs Table */}
        <div style={styles.tableContainer}>
          <table style={styles.table}>
            <thead style={styles.tableHeader}>
              <tr>
                <th style={styles.tableHeaderCell}>ID</th>
                <th style={styles.tableHeaderCell}>Name</th>
                <th style={styles.tableHeaderCell}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredActivityLogs.map((activityLog) => (
                <tr 
                  key={activityLog.id} 
                  style={styles.tableRow}
                  onMouseEnter={(e) => {
                    e.target.parentElement.style.backgroundColor = '#f8f9fa';
                  }}
                  onMouseLeave={(e) => {
                    e.target.parentElement.style.backgroundColor = 'transparent';
                  }}
                >
                  <td style={styles.tableCell}>{activityLog.id}</td>
                  <td style={styles.tableCell}>{activityLog.name}</td>
                  <td style={styles.tableCell}>
                    <div style={styles.actionButtons}>
                      <button 
                        style={styles.viewLogsButton}
                        onClick={() => handleViewLogs(activityLog)}
                        onMouseEnter={(e) => {
                          e.target.style.backgroundColor = '#6aa3d9';
                        }}
                        onMouseLeave={(e) => {
                          e.target.style.backgroundColor = colors.view;
                        }}
                      >
                        View Logs
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Coach_ActivityLogs;