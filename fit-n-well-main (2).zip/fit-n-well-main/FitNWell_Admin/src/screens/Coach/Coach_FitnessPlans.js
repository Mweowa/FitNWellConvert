import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { colors } from '../../utils/colors';
import { FaUserCircle, FaHome, FaClipboardList, FaList, FaSearch } from "react-icons/fa";
import { FaCalendarPlus } from "react-icons/fa6";
import { IoScaleSharp, IoChatbubbleSharp } from "react-icons/io5";
import { MdFactCheck } from "react-icons/md";
import { CiLogout } from "react-icons/ci";
import { FaChevronRight, FaChevronLeft } from "react-icons/fa";
import DeletePlan from '../../components/DeletePlan';

const Coach_FitnessPlans = ({ onLogout }) => {
  const navigate = useNavigate();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isActivePlanModalOpen, setIsActivePlanModalOpen] = useState(false);
  const [activePlan, setActivePlan] = useState('coach-fitness-plans');
  const [activeMenu, setActiveMenu] = useState('fitness-plans');
  
  // Edit Modal States
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedPlanForEdit, setSelectedPlanForEdit] = useState(null);
  const [formData, setFormData] = useState({
    planTitle: '',
    startDate: '',
    endDate: '',
    selectedDays: [],
    warmUpExercises: [{ name: '', time: '' }],
    mainExercises: [{ name: '', sets: '', reps: '' }],
    coolDownExercises: [{ name: '', time: '' }]
  });

  // Delete Modal States
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [planToDelete, setPlanToDelete] = useState(null);

  const handleLogout = () => {
    onLogout();
    navigate('/');
  };

  const handleMenuClick = (route) => {
    setActiveMenu(route);
    if (route === 'dashboard') {
      navigate('/coach-dashboard');
    } else if (route === 'plan-requests') {
      navigate('/coach-plan-requests');
    } else if (route === 'fitness-plans') {
      navigate('/coach-fitness-plans');
    } else if (route === 'activity-logs') {
      navigate('/coach-activity-logs');
    } else if (route === 'fitness-assessments') {
      navigate('/coach-fitness-assessments');
    } else if (route === 'measurements') {
      navigate('/coach-measurements');
    } else if (route === 'messages') {
      navigate('/coach-messages');
    }
  };

  // Sample fitness plans data
  const [fitnessPlans] = useState([
    {
      id: 1,
      name: "Jimmy Reyes",
      plans: "01"
    },
    {
      id: 2,
      name: "Grace Mendoza",
      plans: "02"
    },
    {
      id: 3,
      name: "Carlo Chua",
      plans: "04"
    },
    {
      id: 4,
      name: "Daniel Torres",
      plans: "02"
    }
  ]);

  // Edit Modal Functions
  const daysOfWeek = ['Mon', 'Tues', 'Wed', 'Thurs', 'Fri', 'Sat', 'Sun'];

  const handleDayToggle = (day) => {
    setFormData(prev => ({
      ...prev,
      selectedDays: prev.selectedDays.includes(day)
        ? prev.selectedDays.filter(d => d !== day)
        : [...prev.selectedDays, day]
    }));
  };

  const addWarmUpExercise = () => {
    setFormData(prev => ({
      ...prev,
      warmUpExercises: [...prev.warmUpExercises, { name: '', time: '' }]
    }));
  };

  const addMainExercise = () => {
    setFormData(prev => ({
      ...prev,
      mainExercises: [...prev.mainExercises, { name: '', sets: '', reps: '' }]
    }));
  };

  const addCoolDownExercise = () => {
    setFormData(prev => ({
      ...prev,
      coolDownExercises: [...prev.coolDownExercises, { name: '', time: '' }]
    }));
  };

  const removeWarmUpExercise = (index) => {
    setFormData(prev => ({
      ...prev,
      warmUpExercises: prev.warmUpExercises.filter((_, i) => i !== index)
    }));
  };

  const removeMainExercise = (index) => {
    setFormData(prev => ({
      ...prev,
      mainExercises: prev.mainExercises.filter((_, i) => i !== index)
    }));
  };

  const removeCoolDownExercise = (index) => {
    setFormData(prev => ({
      ...prev,
      coolDownExercises: prev.coolDownExercises.filter((_, i) => i !== index)
    }));
  };

  const updateWarmUpExercise = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      warmUpExercises: prev.warmUpExercises.map((exercise, i) =>
        i === index ? { ...exercise, [field]: value } : exercise
      )
    }));
  };

  const updateMainExercise = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      mainExercises: prev.mainExercises.map((exercise, i) =>
        i === index ? { ...exercise, [field]: value } : exercise
      )
    }));
  };

  const updateCoolDownExercise = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      coolDownExercises: prev.coolDownExercises.map((exercise, i) =>
        i === index ? { ...exercise, [field]: value } : exercise
      )
    }));
  };

  const openEditModal = (plan) => {
    setSelectedPlanForEdit(plan);
    setShowEditModal(true);
    // Reset form data with existing plan data
    setFormData({
      planTitle: `Workout ${plan.plans}`,
      startDate: '2025-08-08',
      endDate: '2025-08-24',
      selectedDays: ['Mon', 'Tue', 'Wed'],
      warmUpExercises: [{ name: 'Stretch', time: '1 min' }],
      mainExercises: [{ name: 'Squats', sets: '5', reps: '10' }],
      coolDownExercises: [{ name: 'Stretch', time: '1 min' }]
    });
  };

  const closeEditModal = () => {
    setShowEditModal(false);
    setSelectedPlanForEdit(null);
  };

  const handleSaveEdit = () => {
    console.log('Saving edited plan:', formData);
    // Handle save logic here
    closeEditModal();
  };

  const handleCancelEdit = () => {
    closeEditModal();
    // Reopen the active plan modal
    if (selectedPlanForEdit) {
      handleViewActivePlan(selectedPlanForEdit);
    }
  };

  // Delete Modal Functions
  const handleDeletePlan = (plan) => {
    setPlanToDelete(plan);
    setShowDeleteModal(true);
    setIsActivePlanModalOpen(false); // Close active plan modal
  };

  const handleConfirmDelete = () => {
    console.log('Deleting plan:', planToDelete);
    // Handle delete logic here
    setShowDeleteModal(false);
    setPlanToDelete(null);
  };

  const handleCancelDelete = () => {
    setShowDeleteModal(false);
    setPlanToDelete(null);
    // Don't reopen active plan modal - just close the delete modal
  };

  // CHK_ActivePlan Modal Component
  const CHK_ActivePlan = ({ visible, onClose, planData }) => {
    if (!visible) return null;

    const modalStyles = {
      overlay: {
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 1000,
      },
      modal: {
        backgroundColor: '#fff',
        borderRadius: '8px',
        padding: '0',
        width: '500px',
        maxWidth: '90vw',
        boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
      },
      header: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '20px 24px',
        borderBottom: '1px solid #e0e0e0',
      },
      title: {
        margin: 0,
        fontSize: '20px',
        fontWeight: 'bold',
        color: colors.main,
      },
      closeButton: {
        background: 'none',
        border: 'none',
        fontSize: '18px',
        cursor: 'pointer',
        color: '#333',
        padding: '4px',
        borderRadius: '4px',
        transition: 'color 0.2s ease',
      },
      content: {
        padding: '24px',
      },
      detailRow: {
        display: 'flex',
        marginBottom: '12px',
        alignItems: 'flex-start',
      },
      detailLabel: {
        fontWeight: '600',
        color: '#333',
        minWidth: '80px',
        marginRight: '8px',
      },
      detailValue: {
        color: colors.d_gray,
        flex: 1,
      },
      exercisesSection: {
        marginTop: '20px',
      },
      exercisesTitle: {
        fontWeight: '600',
        color: '#333',
        marginBottom: '12px',
        fontSize: '16px',
      },
      exerciseCategory: {
        marginBottom: '16px',
      },
      categoryTitle: {
        fontWeight: '600',
        color: '#333',
        marginBottom: '8px',
      },
      exerciseItem: {
        color: colors.d_gray,
        marginLeft: '16px',
        marginBottom: '4px',
      },
      buttonContainer: {
        display: 'flex',
        justifyContent: 'flex-end',
        gap: '10px',
        marginTop: '20px',
        paddingTop: '20px',
        borderTop: '1px solid #e0e0e0',
      },
      editButton: {
        backgroundColor: '#5a6268',
        color: '#fff',
        border: 'none',
        borderRadius: '5px',
        padding: '10px 20px',
        cursor: 'pointer',
        fontSize: '14px',
        fontWeight: '500',
        transition: 'background-color 0.2s ease',
      },
      deleteButton: {
        backgroundColor: '#dc3545',
        color: '#fff',
        border: 'none',
        borderRadius: '5px',
        padding: '10px 20px',
        cursor: 'pointer',
        fontSize: '14px',
        fontWeight: '500',
        transition: 'background-color 0.2s ease',
      },
    };

    const defaultPlanData = {
      planId: '01',
      planTitle: 'Workout 1',
      name: 'Jimmy Reyes',
      date: 'August 08, 2025 - August 24, 2025',
      days: 'Mon, Tue, Wed',
      exercises: {
        warmUp: [
          { name: 'Stretch', duration: '1 min' }
        ],
        mainExercise: [
          { name: 'Squats', sets: 5, reps: 10 }
        ],
        coolDown: [
          { name: 'Stretch', duration: '1 min' }
        ]
      }
    };

    const plan = planData || defaultPlanData;

    return (
      <div style={modalStyles.overlay}>
        <div style={modalStyles.modal}>
          <div style={modalStyles.header}>
            <h3 style={modalStyles.title}>Active Fitness Plan</h3>
            <button 
              style={modalStyles.closeButton}
              onClick={onClose}
              onMouseEnter={(e) => {
                e.target.style.color = '#666';
              }}
              onMouseLeave={(e) => {
                e.target.style.color = '#333';
              }}
            >
              ✕
            </button>
          </div>
          <div style={modalStyles.content}>
            <div style={modalStyles.detailRow}>
              <span style={modalStyles.detailLabel}>Plan ID:</span>
              <span style={modalStyles.detailValue}>{plan.planId}</span>
            </div>
            <div style={modalStyles.detailRow}>
              <span style={modalStyles.detailLabel}>Plan Title:</span>
              <span style={modalStyles.detailValue}>{plan.planTitle}</span>
            </div>
            <div style={modalStyles.detailRow}>
              <span style={modalStyles.detailLabel}>Name:</span>
              <span style={modalStyles.detailValue}>{plan.name}</span>
            </div>
            <div style={modalStyles.detailRow}>
              <span style={modalStyles.detailLabel}>Date:</span>
              <span style={modalStyles.detailValue}>{plan.date}</span>
            </div>
            <div style={modalStyles.detailRow}>
              <span style={modalStyles.detailLabel}>Days:</span>
              <span style={modalStyles.detailValue}>{plan.days}</span>
            </div>

            <div style={modalStyles.exercisesSection}>
              <div style={modalStyles.exercisesTitle}>Exercises:</div>
              
              <div style={modalStyles.exerciseCategory}>
                <div style={modalStyles.categoryTitle}>Warm Up:</div>
                {plan.exercises.warmUp.map((exercise, index) => (
                  <div key={index} style={modalStyles.exerciseItem}>
                    {exercise.name} - {exercise.duration}
                  </div>
                ))}
              </div>

              <div style={modalStyles.exerciseCategory}>
                <div style={modalStyles.categoryTitle}>Main Exercise:</div>
                {plan.exercises.mainExercise.map((exercise, index) => (
                  <div key={index} style={modalStyles.exerciseItem}>
                    {exercise.name} - {exercise.sets} sets x {exercise.reps} reps
                  </div>
                ))}
              </div>

              <div style={modalStyles.exerciseCategory}>
                <div style={modalStyles.categoryTitle}>Cool Down:</div>
                {plan.exercises.coolDown.map((exercise, index) => (
                  <div key={index} style={modalStyles.exerciseItem}>
                    {exercise.name} - {exercise.duration}
                  </div>
                ))}
              </div>
            </div>

            <div style={modalStyles.buttonContainer}>
              <button 
                style={modalStyles.deleteButton}
                onMouseEnter={(e) => {
                  e.target.style.backgroundColor = '#c82333';
                }}
                onMouseLeave={(e) => {
                  e.target.style.backgroundColor = '#dc3545';
                }}
                onClick={() => {
                  const planToDelete = selectedPlanForEdit || { 
                    id: plan.planId, 
                    name: plan.name, 
                    plans: plan.planId 
                  };
                  handleDeletePlan(planToDelete);
                }}
              >
                Delete
              </button>
              <button 
                style={modalStyles.editButton}
                onMouseEnter={(e) => {
                  e.target.style.backgroundColor = '#5a6268';
                }}
                onMouseLeave={(e) => {
                  e.target.style.backgroundColor = '#8E8B8B';
                }}
                onClick={() => {
                  onClose(); // Close the active plan modal first
                  openEditModal(selectedPlanForEdit || { id: 1, name: plan.name, plans: plan.planId });
                }}
              >
                Edit
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Active Plan Modal handlers
  const handleViewActivePlan = (plan) => {
    // Sample plan data for demonstration
    const planData = {
      planId: plan.plans,
      planTitle: `Workout ${plan.plans}`,
      name: plan.name,
      date: 'August 08, 2025 - August 24, 2025',
      days: 'Mon, Tue, Wed',
      exercises: {
        warmUp: [
          { name: 'Stretch', duration: '1 min' }
        ],
        mainExercise: [
          { name: 'Squats', sets: 5, reps: 10 }
        ],
        coolDown: [
          { name: 'Stretch', duration: '1 min' }
        ]
      }
    };
    setActivePlan(planData);
    setSelectedPlanForEdit(plan); // Store the plan for potential editing
    setIsActivePlanModalOpen(true);
  };

  const handleCloseActivePlanModal = () => {
    setIsActivePlanModalOpen(false);
    setActivePlan(null);
    setSelectedPlanForEdit(null);
  };

  const handleHistoryPlan = (plan) => {
    navigate('/coach-fp-history', { 
      state: { 
        userData: {
          id: plan.id,
          name: plan.name,
          plans: plan.plans
        }
      }
    });
  };

  const styles = {
    container: {
      display: 'flex',
      flexDirection: 'row',
      height: '100vh',
      backgroundColor: '#FEFFFD',
      overflow: 'auto',
    },
    sidebar: {
      backgroundColor: '#F1F1F2',
      padding: '17px 15px',
      width: isCollapsed ? '80px' : '230px',
      transition: 'width 0.3s ease, padding 0.3s ease',
      display: 'flex',
      flexDirection: 'column',
    },
    brand: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '15px',
      padding: isCollapsed ? '0' : '0 10px',
      justifyContent: isCollapsed ? 'center' : 'flex-start',
    },
    brandIcon: {
      width: '47px',
      height: '40px',
    },
    brandText: {
      fontSize: '25px',
      color: colors.d_gray,
      fontWeight: 'bold',
      fontStyle: 'italic',
      marginLeft: '15px',
    },
    menuContainer: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
    },
    menuGroup: {
      marginBottom: '20px',
    },
    menuDivider: {
      height: '1px',
      backgroundColor: '#e0e0e0',
      marginBottom: '15px',
    },
    menuItem: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemActive: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'rgba(159, 192, 59, 0.2)',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemCollapsed: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '12px 8px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuIcon: {
      fontSize: '20px',
      marginRight: isCollapsed ? '0' : '12px',
      color: colors.main,
      display: 'flex',
      alignItems: 'center',
    },
    menuText: {
      fontSize: '14px',
      color: colors.d_gray,
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    menuTextActive: {
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '600',
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    logoutButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#fff',
      border: 'none',
      borderRadius: '30px',
      padding: isCollapsed ? '2px 3px' : '7px 12px',
      marginTop: '20px',
      marginBottom: '10px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      width: isCollapsed ? 'auto' : 'fit-content',
      alignSelf: 'center',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
    },
    logoutIcon: {
      background: 'none',
      fontSize: '18px',
      marginRight: isCollapsed ? '0' : '8px',
      display: 'flex',
      alignItems: 'center',
      color: colors.main,
    },
    logoutText: {
      background: 'none',
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '500',
    },
    mainContent: {
      flex: 1,
      backgroundColor: '#FEFFFD',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '30px',
    },
    collapseButton: {
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      fontSize: '10px',
      color: colors.l_gray,
      transition: 'background-color 0.2s ease',
      marginLeft: '-10px'
    },
    pageTitle: {
      fontSize: '28px',
      fontWeight: 'bold',
      color: colors.main,
      marginBottom: '20px',
    },
    profileButton: {
      color: colors.main,      
      marginTop: '5px',
      marginRight: '5px',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontSize: '32px',
    },
    searchContainer: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '20px',
      gap: '15px',
    },
    searchBox: {
      display: 'flex',
      alignItems: 'center',
      backgroundColor: '#fff',
      border: '1px solid #e0e0e0',
      borderRadius: '8px',
      padding: '10px 15px',
      flex: 1,
      maxWidth: '400px',
    },
    searchIcon: {
      color: '#999',
      marginRight: '10px',
      fontSize: '16px',
    },
    searchInput: {
      border: 'none',
      outline: 'none',
      flex: 1,
      fontSize: '14px',
      color: '#333',
    },
    tableContainer: {
      backgroundColor: '#fff',
      borderRadius: '8px',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
      overflow: 'hidden',
    },
    table: {
      width: '100%',
      borderCollapse: 'collapse',
    },
    tableHeader: {
      backgroundColor: '#f8f9fa',
      borderBottom: '1px solid #e0e0e0',
    },
    tableHeaderCell: {
      padding: '15px 12px',
      textAlign: 'left',
      fontSize: '14px',
      fontWeight: '600',
      color: '#333',
      borderBottom: '1px solid #e0e0e0',
    },
    tableRow: {
      borderBottom: '1px solid #f0f0f0',
    },
    tableCell: {
      padding: '12px',
      fontSize: '14px',
      color: '#333',
      borderBottom: '1px solid #f0f0f0',
    },
    actionButtons: {
      display: 'flex',
      gap: '8px',
    },
    viewActiveButton: {
      backgroundColor: colors.view,
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '6px 12px',
      cursor: 'pointer',
      fontSize: '12px',
      transition: 'background-color 0.2s ease',
    },
    historyButton: {
      backgroundColor: colors.l_gray,
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '6px 12px',
      cursor: 'pointer',
      fontSize: '12px',
      transition: 'background-color 0.2s ease',
    },
    // Edit Modal Styles (copied from Coach_PlanRequests)
    overlay: {
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      zIndex: 1000,
    },
    modal: {
      backgroundColor: '#fff',
      borderRadius: '8px',
      padding: '0',
      width: '800px',
      maxWidth: '90vw',
      maxHeight: '90vh',
      boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
      display: 'flex',
      flexDirection: 'column',
    },
    modalHeader: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '20px 24px',
      borderBottom: '1px solid #e0e0e0',
      flexShrink: 0,
    },
    modalTitle: {
      margin: 0,
      fontSize: '20px',
      fontWeight: 'bold',
      color: '#9FC03B',
    },
    closeButton: {
      background: 'none',
      border: 'none',
      fontSize: '18px',
      cursor: 'pointer',
      color: '#333',
      padding: '4px',
      borderRadius: '4px',
      transition: 'color 0.2s ease',
    },
    modalContent: {
      padding: '24px',
      overflowY: 'auto',
      flex: 1,
      maxHeight: 'calc(90vh - 80px)',
    },
    formGroup: {
      marginBottom: '16px',
    },
    label: {
      display: 'block',
      fontSize: '16px',
      fontWeight: '600',
      color: '#333',
      marginBottom: '6px',
    },
    input: {
      width: '100%',
      padding: '8px 12px',
      border: '1px solid #e0e0e0',
      borderRadius: '4px',
      fontSize: '14px',
      backgroundColor: '#f8f9fa',
      outline: 'none',
      transition: 'border-color 0.2s ease',
      fontFamily: 'Inter',
    },
    daysContainer: {
      display: 'flex',
      gap: '8px',
      marginTop: '8px',
      flexWrap: 'wrap',
    },
    dayButton: {
      marginTop: '25px',
      padding: '8px 36px',
      border: 'none',
      borderRadius: '4px',
      fontSize: '14px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
    },
    dayButtonInactive: {
      backgroundColor: '#e0e0e0',
      color: '#666',
    },
    dayButtonActive: {
      backgroundColor: '#9FC03B',
      color: '#fff',
    },
    exerciseSection: {
      marginTop: '25px',
    },
    exerciseSectionTitle: {
      fontSize: '16px',
      fontWeight: '600',
      color: '#333',
      marginBottom: '12px',
    },
    exerciseItem: {
      display: 'flex',
      gap: '8px',
      alignItems: 'center',
      marginBottom: '8px',
    },
    exerciseInput: {
      width: '490px',
      padding: '8px 12px',
      border: '1px solid #e0e0e0',
      borderRadius: '4px',
      fontSize: '14px',
      backgroundColor: '#f8f9fa',
      outline: 'none',
    },
    smallInput: {
      width: '135px',
      padding: '8px 12px',
      border: '1px solid #e0e0e0',
      borderRadius: '4px',
      fontSize: '14px',
      backgroundColor: '#f8f9fa',
      outline: 'none',
    },
    removeButton: {
      backgroundColor: '#FF6B6B',
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '8px 12px',
      cursor: 'pointer',
      fontSize: '12px',
    },
    addExerciseButton: {
      backgroundColor: '#9FC03B',
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '8px 16px',
      cursor: 'pointer',
      fontSize: '12px',
      marginTop: '8px',
    },
    modalFooter: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: '10px',
      padding: '20px 24px',
      borderTop: '1px solid #e0e0e0',
    },
    saveButton: {
      backgroundColor: "#9FC03B",
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '10px 20px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '500',
      transition: 'background-color 0.2s ease',
    },
    cancelButton: {
      backgroundColor: '#fff',
      color: colors.d_gray,
      border: '1px solid #e0e0e0',
      borderRadius: '6px',
      padding: '10px 20px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '500',
      transition: 'all 0.2s ease',
    },
  };

  const menuItems = [
    { name: 'Dashboard', icon: <FaHome />, route: 'dashboard', active: activeMenu === 'dashboard' },
    { name: 'Plan Requests', icon: <FaCalendarPlus />, route: 'plan-requests', active: activeMenu === 'plan-requests' },
    { name: 'Fitness Plans', icon: <FaList />, route: 'fitness-plans', active: activeMenu === 'fitness-plans' },
    { name: 'Activity Logs', icon: <FaClipboardList />, route: 'activity-logs', active: activeMenu === 'activity-logs' },
    { name: 'Fitness Assessments', icon: <MdFactCheck />, route: 'fitness-assessments', active: activeMenu === 'fitness-assessments' },
    { name: 'Measurements', icon: <IoScaleSharp />, route: 'measurements', active: activeMenu === 'measurements' },
    { name: 'Messages', icon: <IoChatbubbleSharp />, route: 'messages', active: activeMenu === 'messages' },
  ];

  const renderMenuItem = (item, index) => {
    const menuItemStyle = item.active 
      ? (isCollapsed ? styles.menuItemCollapsed : styles.menuItemActive)
      : (isCollapsed ? styles.menuItemCollapsed : styles.menuItem);
    
    const menuTextStyle = item.active ? styles.menuTextActive : styles.menuText;

    return (
      <button
        key={index}
        style={menuItemStyle}
        onClick={() => handleMenuClick(item.route)}
        onMouseEnter={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'rgba(159, 192, 59, 0.1)';
          }
        }}
        onMouseLeave={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'transparent';
          }
        }}
      >
        <span style={styles.menuIcon}>{item.icon}</span>
        {!isCollapsed && (
          <span style={menuTextStyle}>
            {item.name}
          </span>
        )}
      </button>
    );
  };

  const filteredPlans = fitnessPlans.filter(plan =>
    plan.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div style={styles.container}>
      {/* Sidebar */}
      <div style={styles.sidebar}>
        {/* Brand */}
        <div style={styles.brand}>
          <img 
            src="/fnw1.png" 
            alt="FitNWell Logo"
            style={styles.brandIcon}
          />
          {!isCollapsed && (
            <span style={styles.brandText}>FitNWell</span>
          )}
        </div>

        {/* Menu Items */}
        <div style={styles.menuContainer}>
          <div style={styles.menuDivider} />
          
          <div style={styles.menuGroup}>
            {menuItems.slice(0, 7).map((item, index) => renderMenuItem(item, index))}
          </div>
          
          <div style={styles.menuGroup}>
            {menuItems.slice(7).map((item, index) => renderMenuItem(item, index + 7))}
          </div>
        </div>

        {/* Logout Button */}
        <button 
          style={styles.logoutButton}
          onClick={onLogout}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#f5f5f5';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#fff';
          }}
        >
          <span style={styles.logoutIcon}><CiLogout /></span>
          {!isCollapsed && (
            <span style={styles.logoutText}>Log Out</span>
          )}
        </button>
      </div>

      {/* Main Content */}
      <div style={styles.mainContent}>
        {/* Header */}
        <div style={styles.header}>
          <button 
            style={styles.collapseButton}
            onClick={() => setIsCollapsed(!isCollapsed)}
          >
            {isCollapsed ? <FaChevronRight /> : <FaChevronLeft />}
          </button>
          <span style={styles.pageTitle}>Fitness Plans</span>
          <button style={styles.profileButton}
          onClick={() => navigate('/coach-user-profile')}
          >
            <FaUserCircle />
          </button>
        </div>

        {/* Search */}
        <div style={styles.searchContainer}>
          <div style={styles.searchBox}>
            <FaSearch style={styles.searchIcon} />
            <input
              type="text"
              placeholder="Search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={styles.searchInput}
            />
          </div>
        </div>

        {/* Fitness Plans Table */}
        <div style={styles.tableContainer}>
          <table style={styles.table}>
            <thead style={styles.tableHeader}>
              <tr>
                <th style={styles.tableHeaderCell}>ID</th>
                <th style={styles.tableHeaderCell}>Name</th>
                <th style={styles.tableHeaderCell}>Plans</th>
                <th style={styles.tableHeaderCell}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredPlans.map((plan) => (
                <tr 
                  key={plan.id} 
                  style={styles.tableRow}
                  onMouseEnter={(e) => {
                    e.target.parentElement.style.backgroundColor = '#f8f9fa';
                  }}
                  onMouseLeave={(e) => {
                    e.target.parentElement.style.backgroundColor = 'transparent';
                  }}
                >
                  <td style={styles.tableCell}>{plan.id}</td>
                  <td style={styles.tableCell}>{plan.name}</td>
                  <td style={styles.tableCell}>{plan.plans}</td>
                  <td style={styles.tableCell}>
                    <div style={styles.actionButtons}>
                      {plan.plans !== "No plans" && (
                        <button 
                          style={styles.viewActiveButton}
                          onMouseEnter={(e) => {
                            e.target.style.backgroundColor = '#6aa3d9';
                          }}
                          onMouseLeave={(e) => {
                            e.target.style.backgroundColor = colors.view;
                          }}
                          onClick={() => handleViewActivePlan(plan)}
                        >
                          View Active Plan
                        </button>
                      )}
                      <button 
                        style={styles.historyButton}
                        onMouseEnter={(e) => {
                          e.target.style.backgroundColor = '#5a6268';
                        }}
                        onMouseLeave={(e) => {
                          e.target.style.backgroundColor = colors.l_gray;
                        }}
                        onClick={() => handleHistoryPlan(plan)}
                      >
                        History Plan
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Active Plan Modal */}
      {isActivePlanModalOpen && activePlan && (
        <CHK_ActivePlan
          visible={isActivePlanModalOpen}
          planData={activePlan}
          onClose={handleCloseActivePlanModal}
        />
      )}

      {/* Edit Fitness Plan Modal */}
      {showEditModal && (
        <div style={styles.overlay}>
          <div style={styles.modal}>
            <div style={styles.modalHeader}>
              <h3 style={styles.modalTitle}>Edit Fitness Plan</h3>
              <button 
                style={styles.closeButton}
                onClick={closeEditModal}
                onMouseEnter={(e) => {
                  e.target.style.color = '#666';
                }}
                onMouseLeave={(e) => {
                  e.target.style.color = '#333';
                }}
              >
                ✕
              </button>
            </div>
            
            <div style={styles.modalContent}>
              {/* Plan Title */}
              <div style={styles.formGroup}>
                <label style={styles.label}>Plan Title</label>
                <input
                  type="text"
                  style={styles.input}
                  value={formData.planTitle}
                  onChange={(e) => setFormData(prev => ({ ...prev, planTitle: e.target.value }))}
                />
              </div>

              {/* Start Date */}
              <div style={styles.formGroup}>
                <label style={styles.label}>Start Date</label>
                <input
                  type="date"
                  style={styles.input}
                  value={formData.startDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, startDate: e.target.value }))}
                />
              </div>

              {/* End Date */}
              <div style={styles.formGroup}>
                <label style={styles.label}>End Date</label>
                <input
                  type="date"
                  style={styles.input}
                  value={formData.endDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, endDate: e.target.value }))}
                />
              </div>

              {/* Days Selection */}
              <div style={styles.formGroup}>
                <div style={styles.daysContainer}>
                  {daysOfWeek.map((day) => (
                    <button
                      key={day}
                      style={{
                        ...styles.dayButton,
                        ...(formData.selectedDays.includes(day) 
                          ? styles.dayButtonActive 
                          : styles.dayButtonInactive)
                      }}
                      onClick={() => handleDayToggle(day)}
                    >
                      {day}
                    </button>
                  ))}
                </div>
              </div>

              {/* Warm Up Section */}
              <div style={styles.exerciseSection}>
                <div style={styles.exerciseSectionTitle}>Warm Up</div>
                {formData.warmUpExercises.map((exercise, index) => (
                  <div key={index} style={styles.exerciseItem}>
                    <input
                      type="text"
                      placeholder="Exercise Name"
                      style={styles.exerciseInput}
                      value={exercise.name}
                      onChange={(e) => updateWarmUpExercise(index, 'name', e.target.value)}
                    />
                    <input
                      type="text"
                      placeholder="Time (e.g., 1 min)"
                      style={styles.smallInput}
                      value={exercise.time}
                      onChange={(e) => updateWarmUpExercise(index, 'time', e.target.value)}
                    />
                    {formData.warmUpExercises.length > 1 && (
                      <button
                        style={styles.removeButton}
                        onClick={() => removeWarmUpExercise(index)}
                      >
                        Remove
                      </button>
                    )}
                  </div>
                ))}
                <button style={styles.addExerciseButton} onClick={addWarmUpExercise}>
                  + Add Warm Up Exercise
                </button>
              </div>

              {/* Main Exercise Section */}
              <div style={styles.exerciseSection}>
                <div style={styles.exerciseSectionTitle}>Main Exercise</div>
                {formData.mainExercises.map((exercise, index) => (
                  <div key={index} style={styles.exerciseItem}>
                    <input
                      type="text"
                      placeholder="Exercise Name"
                      style={styles.exerciseInput}
                      value={exercise.name}
                      onChange={(e) => updateMainExercise(index, 'name', e.target.value)}
                    />
                    <input
                      type="text"
                      placeholder="Sets"
                      style={styles.smallInput}
                      value={exercise.sets}
                      onChange={(e) => updateMainExercise(index, 'sets', e.target.value)}
                    />
                    <input
                      type="text"
                      placeholder="Reps"
                      style={styles.smallInput}
                      value={exercise.reps}
                      onChange={(e) => updateMainExercise(index, 'reps', e.target.value)}
                    />
                    {formData.mainExercises.length > 1 && (
                      <button
                        style={styles.removeButton}
                        onClick={() => removeMainExercise(index)}
                      >
                        Remove
                      </button>
                    )}
                  </div>
                ))}
                <button style={styles.addExerciseButton} onClick={addMainExercise}>
                  + Add Main Exercise
                </button>
              </div>

              {/* Cool Down Section */}
              <div style={styles.exerciseSection}>
                <div style={styles.exerciseSectionTitle}>Cool Down</div>
                {formData.coolDownExercises.map((exercise, index) => (
                  <div key={index} style={styles.exerciseItem}>
                    <input
                      type="text"
                      placeholder="Exercise Name"
                      style={styles.exerciseInput}
                      value={exercise.name}
                      onChange={(e) => updateCoolDownExercise(index, 'name', e.target.value)}
                    />
                    <input
                      type="text"
                      placeholder="Time (e.g., 1 min)"
                      style={styles.smallInput}
                      value={exercise.time}
                      onChange={(e) => updateCoolDownExercise(index, 'time', e.target.value)}
                    />
                    {formData.coolDownExercises.length > 1 && (
                      <button
                        style={styles.removeButton}
                        onClick={() => removeCoolDownExercise(index)}
                      >
                        Remove
                      </button>
                    )}
                  </div>
                ))}
                <button style={styles.addExerciseButton} onClick={addCoolDownExercise}>
                  + Add Cool Down Exercise
                </button>
              </div>
            </div>
            
            <div style={styles.modalFooter}>
              <button 
                style={styles.cancelButton} 
                onClick={handleCancelEdit}
                onMouseEnter={(e) => {
                  e.target.style.backgroundColor = '#f8f9fa';
                  e.target.style.borderColor = '#d0d7dd';
                }}
                onMouseLeave={(e) => {
                  e.target.style.backgroundColor = '#fff';
                  e.target.style.borderColor = '#e0e0e0';
                }}
              >
                Cancel
              </button>
              <button style={styles.saveButton} onClick={handleSaveEdit}>
                Save Plan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Plan Modal */}
      {showDeleteModal && planToDelete && (
        <DeletePlan
          visible={showDeleteModal}
          onConfirm={handleConfirmDelete}
          onClose={handleCancelDelete}
          planData={{
            name: planToDelete.name,
            planId: planToDelete.plans
          }}
        />
      )}
    </div>
  );
};

export default Coach_FitnessPlans;