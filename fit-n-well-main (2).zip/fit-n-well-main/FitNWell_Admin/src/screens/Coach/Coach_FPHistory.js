import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { colors } from '../../utils/colors';
import { FaUserCircle, FaHome, FaClipboardList, FaList, FaSearch, FaArrowLeft } from "react-icons/fa";
import { FaCalendarPlus } from "react-icons/fa6";
import { IoScaleSharp, IoChatbubbleSharp } from "react-icons/io5";
import { MdFactCheck } from "react-icons/md";
import { CiLogout } from "react-icons/ci";
import { FaChevronRight, FaChevronLeft } from "react-icons/fa";

const Coach_FPHistory = ({ onLogout }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isViewPlanModalOpen, setIsViewPlanModalOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [activeMenu, setActiveMenu] = useState('fitness-plans');

  // Get user data from location state or use default
  const userData = location.state?.userData || {
    id: 1,
    name: "Jimmy Reyes",
    plans: "01"
  };


  const [fitnessPlanHistory] = useState(() => {

    const userPlans = userData.plans;
    const userName = userData.name;
    
    if (userName === "Jimmy Reyes") {
      return [
        {
          id: 1,
          planTitle: "Workout 1",
          startDate: "June 29",
          endDate: "July 12",
          status: "Completed"
        },
        {
          id: 2,
          planTitle: "Workout 2", 
          startDate: "July 13",
          endDate: "July 26",
          status: "Completed"
        },
        {
          id: 3,
          planTitle: "Workout 3",
          startDate: "July 27", 
          endDate: "August 9",
          status: "Completed"
        },
        {
          id: 4,
          planTitle: "Workout 4",
          startDate: "August 10",
          endDate: "August 23", 
          status: "Active"
        }
      ];
    } else if (userName === "Grace Mendoza") {
      return [
        {
          id: 1,
          planTitle: "Workout 2",
          startDate: "July 13",
          endDate: "July 26",
          status: "Completed"
        },
        {
          id: 2,
          planTitle: "Workout 3", 
          startDate: "July 27",
          endDate: "August 9",
          status: "Completed"
        },
        {
          id: 3,
          planTitle: "Workout 4",
          startDate: "August 10", 
          endDate: "August 23",
          status: "Active"
        }
      ];
    } else if (userName === "Carlo Chua") {
      return [
        {
          id: 1,
          planTitle: "Workout 4",
          startDate: "August 10",
          endDate: "August 23",
          status: "Active"
        }
      ];
    } else if (userName === "Daniel Torres") {
      return [
        {
          id: 1,
          planTitle: "Workout 2",
          startDate: "July 13",
          endDate: "July 26",
          status: "Completed"
        },
        {
          id: 2,
          planTitle: "Workout 3", 
          startDate: "July 27",
          endDate: "August 9",
          status: "Completed"
        }
      ];
    } else {
      // Default history for unknown users
      return [
        {
          id: 1,
          planTitle: `Workout ${userPlans}`,
          startDate: "August 10",
          endDate: "August 23",
          status: "Active"
        }
      ];
    }
  });

  // View Plan Modal handlers
  const handleViewPlan = (plan) => {
    // Generate varied plan data based on plan title and user
    const planData = generatePlanData(plan, userData);
    setSelectedPlan(planData);
    setIsViewPlanModalOpen(true);
  };

  const handleCloseViewPlanModal = () => {
    setIsViewPlanModalOpen(false);
    setSelectedPlan(null);
  };

  const generatePlanData = (plan, userData) => {
    const planTitle = plan.planTitle;
    const userName = userData.name;
    
    // Different exercise sets based on plan title and user
    if (planTitle === "Workout 1") {
      return {
        planId: '01',
        planTitle: planTitle,
        name: userName,
        date: `${plan.startDate} - ${plan.endDate}`,
        days: 'Mon, Wed, Fri',
        exercises: {
          warmUp: [
            { name: 'Light Jogging', duration: '5 min' },
            { name: 'Dynamic Stretches', duration: '3 min' }
          ],
          mainExercise: [
            { name: 'Push-ups', sets: 3, reps: 10 },
            { name: 'Squats', sets: 3, reps: 15 },
            { name: 'Plank', sets: 3, reps: 30 }
          ],
          coolDown: [
            { name: 'Static Stretches', duration: '5 min' },
            { name: 'Deep Breathing', duration: '2 min' }
          ]
        }
      };
    } else if (planTitle === "Workout 2") {
      return {
        planId: '02',
        planTitle: planTitle,
        name: userName,
        date: `${plan.startDate} - ${plan.endDate}`,
        days: 'Tue, Thu, Sat',
        exercises: {
          warmUp: [
            { name: 'Jumping Jacks', duration: '3 min' },
            { name: 'Arm Circles', duration: '2 min' }
          ],
          mainExercise: [
            { name: 'Lunges', sets: 4, reps: 12 },
            { name: 'Dumbbell Rows', sets: 3, reps: 10 },
            { name: 'Burpees', sets: 3, reps: 8 }
          ],
          coolDown: [
            { name: 'Foam Rolling', duration: '5 min' },
            { name: 'Yoga Stretches', duration: '3 min' }
          ]
        }
      };
    } else if (planTitle === "Workout 3") {
      return {
        planId: '03',
        planTitle: planTitle,
        name: userName,
        date: `${plan.startDate} - ${plan.endDate}`,
        days: 'Mon, Tue, Thu',
        exercises: {
          warmUp: [
            { name: 'High Knees', duration: '4 min' },
            { name: 'Butt Kicks', duration: '2 min' }
          ],
          mainExercise: [
            { name: 'Deadlifts', sets: 4, reps: 8 },
            { name: 'Pull-ups', sets: 3, reps: 5 },
            { name: 'Mountain Climbers', sets: 3, reps: 20 }
          ],
          coolDown: [
            { name: 'Walking', duration: '5 min' },
            { name: 'Meditation', duration: '3 min' }
          ]
        }
      };
    } else if (planTitle === "Workout 4") {
      return {
        planId: '04',
        planTitle: planTitle,
        name: userName,
        date: `${plan.startDate} - ${plan.endDate}`,
        days: 'Wed, Fri, Sun',
        exercises: {
          warmUp: [
            { name: 'Bicycle Crunches', duration: '3 min' },
            { name: 'Leg Swings', duration: '2 min' }
          ],
          mainExercise: [
            { name: 'Bench Press', sets: 4, reps: 10 },
            { name: 'Overhead Press', sets: 3, reps: 8 },
            { name: 'Russian Twists', sets: 3, reps: 15 }
          ],
          coolDown: [
            { name: 'Light Stretching', duration: '5 min' },
            { name: 'Hydration Break', duration: '2 min' }
          ]
        }
      };
    } else {
      // Default plan data
      return {
        planId: '01',
        planTitle: planTitle,
        name: userName,
        date: `${plan.startDate} - ${plan.endDate}`,
        days: 'Mon, Tue, Wed',
        exercises: {
          warmUp: [
            { name: 'Stretch', duration: '1 min' }
          ],
          mainExercise: [
            { name: 'Squats', sets: 5, reps: 10 }
          ],
          coolDown: [
            { name: 'Stretch', duration: '1 min' }
          ]
        }
      };
    }
  };

  const styles = {
    container: {
      display: 'flex',
      flexDirection: 'row',
      height: '100vh',
      backgroundColor: '#FEFFFD',
      overflow: 'auto',
    },
    sidebar: {
      backgroundColor: '#F1F1F2',
      padding: '17px 15px',
      width: isCollapsed ? '80px' : '230px',
      transition: 'width 0.3s ease, padding 0.3s ease',
      display: 'flex',
      flexDirection: 'column',
    },
    brand: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '15px',
      padding: isCollapsed ? '0' : '0 10px',
      justifyContent: isCollapsed ? 'center' : 'flex-start',
    },
    brandIcon: {
      width: '47px',
      height: '40px',
    },
    brandText: {
      fontSize: '25px',
      color: colors.d_gray,
      fontWeight: 'bold',
      fontStyle: 'italic',
      marginLeft: '15px',
    },
    menuContainer: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
    },
    menuGroup: {
      marginBottom: '20px',
    },
    menuDivider: {
      height: '1px',
      backgroundColor: '#e0e0e0',
      marginBottom: '15px',
    },
    menuItem: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemActive: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'rgba(159, 192, 59, 0.2)',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemCollapsed: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '12px 8px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuIcon: {
      fontSize: '20px',
      marginRight: isCollapsed ? '0' : '12px',
      color: colors.main,
      display: 'flex',
      alignItems: 'center',
    },
    menuText: {
      fontSize: '14px',
      color: colors.d_gray,
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    menuTextActive: {
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '600',
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    logoutButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#fff',
      border: 'none',
      borderRadius: '30px',
      padding: isCollapsed ? '2px 3px' : '7px 12px',
      marginTop: '20px',
      marginBottom: '10px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      width: isCollapsed ? 'auto' : 'fit-content',
      alignSelf: 'center',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
    },
    logoutIcon: {
      background: 'none',
      fontSize: '18px',
      marginRight: isCollapsed ? '0' : '8px',
      display: 'flex',
      alignItems: 'center',
      color: colors.main,
    },
    logoutText: {
      background: 'none',
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '500',
    },
    mainContent: {
      flex: 1,
      backgroundColor: '#FEFFFD',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '30px',
    },
    collapseButton: {
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      fontSize: '10px',
      color: colors.l_gray,
      transition: 'background-color 0.2s ease',
      marginLeft: '-10px'
    },
    pageTitle: {
      fontSize: '28px',
      fontWeight: 'bold',
      color: colors.main,
      marginBottom: '20px',
    },
    profileButton: {
      color: colors.main,      
      marginTop: '5px',
      marginRight: '5px',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontSize: '32px',
    },
    backButton: {
      display: 'flex',
      alignItems: 'center',
      backgroundColor: '#fff',
      color: colors.d_gray,
      border: '1px solid #e0e0e0',
      borderRadius: '6px',
      padding: '8px 16px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '500',
      transition: 'all 0.2s ease',
      marginBottom: '20px',
      width: 'fit-content',
    },
    clientInfo: {
      fontSize: '18px',
      fontWeight: 'bold',
      color: colors.d_gray,
      marginBottom: '20px',
    },
    searchContainer: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '20px',
      gap: '15px',
    },
    searchBox: {
      display: 'flex',
      alignItems: 'center',
      backgroundColor: '#fff',
      border: '1px solid #e0e0e0',
      borderRadius: '8px',
      padding: '10px 15px',
      flex: 1,
      maxWidth: '400px',
    },
    searchIcon: {
      color: '#999',
      marginRight: '10px',
      fontSize: '16px',
    },
    searchInput: {
      border: 'none',
      outline: 'none',
      flex: 1,
      fontSize: '14px',
      color: '#333',
    },
    tableContainer: {
      backgroundColor: '#fff',
      borderRadius: '8px',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
      overflow: 'hidden',
    },
    table: {
      width: '100%',
      borderCollapse: 'collapse',
    },
    tableHeader: {
      backgroundColor: '#f8f9fa',
      borderBottom: '1px solid #e0e0e0',
    },
    tableHeaderCell: {
      padding: '15px 12px',
      textAlign: 'left',
      fontSize: '14px',
      fontWeight: '600',
      color: '#333',
      borderBottom: '1px solid #e0e0e0',
    },
    tableRow: {
      borderBottom: '1px solid #f0f0f0',
    },
    tableCell: {
      padding: '12px',
      fontSize: '14px',
      color: '#333',
      borderBottom: '1px solid #f0f0f0',
    },
    actionButtons: {
      display: 'flex',
      gap: '8px',
    },
    viewButton: {
      backgroundColor: colors.view,
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '6px 12px',
      cursor: 'pointer',
      fontSize: '12px',
      transition: 'background-color 0.2s ease',
    },
    statusBadge: {
      padding: '4px 8px',
      borderRadius: '4px',
      fontSize: '12px',
      fontWeight: '500',
    },
    statusCompleted: {
      backgroundColor: colors.verified,
      color: '#fff',
    },
    statusActive: {
      backgroundColor: colors.main,
      color: '#fff',
    },
  };

  // View Plan Modal Styles
  const viewPlanModalStyles = {
    overlay: {
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      zIndex: 1000,
    },
    modal: {
      backgroundColor: '#fff',
      borderRadius: '8px',
      padding: '0',
      width: '500px',
      maxWidth: '90vw',
      boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '20px 24px',
      borderBottom: '1px solid #e0e0e0',
    },
    title: {
      margin: 0,
      fontSize: '20px',
      fontWeight: 'bold',
      color: colors.main,
    },
    closeButton: {
      background: 'none',
      border: 'none',
      fontSize: '18px',
      cursor: 'pointer',
      color: '#333',
      padding: '4px',
      borderRadius: '4px',
      transition: 'color 0.2s ease',
    },
    content: {
      padding: '24px',
    },
    detailRow: {
      display: 'flex',
      marginBottom: '12px',
      alignItems: 'flex-start',
    },
    detailLabel: {
      fontWeight: '600',
      color: '#333',
      minWidth: '80px',
      marginRight: '8px',
    },
    detailValue: {
      color: colors.d_gray,
      flex: 1,
    },
    exercisesSection: {
      marginTop: '20px',
    },
    exercisesTitle: {
      fontWeight: '600',
      color: '#333',
      marginBottom: '12px',
      fontSize: '16px',
    },
    exerciseCategory: {
      marginBottom: '16px',
    },
    categoryTitle: {
      fontWeight: '600',
      color: '#333',
      marginBottom: '8px',
    },
    exerciseItem: {
      color: colors.d_gray,
      marginLeft: '16px',
      marginBottom: '4px',
    },
  };

  const menuItems = [
    { name: 'Dashboard', icon: <FaHome />, route: 'dashboard', active: activeMenu === 'dashboard' },
    { name: 'Plan Requests', icon: <FaCalendarPlus />, route: 'plan-requests', active: activeMenu === 'plan-requests' },
    { name: 'Fitness Plans', icon: <FaList />, route: 'fitness-plans', active: activeMenu === 'fitness-plans' },
    { name: 'Activity Logs', icon: <FaClipboardList />, route: 'activity-logs', active: activeMenu === 'activity-logs' },
    { name: 'Fitness Assessments', icon: <MdFactCheck />, route: 'fitness-assessments', active: activeMenu === 'fitness-assessments' },
    { name: 'Measurements', icon: <IoScaleSharp />, route: 'measurements', active: activeMenu === 'measurements' },
    { name: 'Messages', icon: <IoChatbubbleSharp />, route: 'messages', active: activeMenu === 'messages' },
  ];

  const renderMenuItem = (item, index) => {
    const menuItemStyle = item.active 
      ? (isCollapsed ? styles.menuItemCollapsed : styles.menuItemActive)
      : (isCollapsed ? styles.menuItemCollapsed : styles.menuItem);
    
    const menuTextStyle = item.active ? styles.menuTextActive : styles.menuText;

    return (
      <button
        key={index}
        style={menuItemStyle}
        onClick={() => {
          if (item.route) {
            navigate(item.route);
          }
        }}
        onMouseEnter={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'rgba(159, 192, 59, 0.1)';
          }
        }}
        onMouseLeave={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'transparent';
          }
        }}
      >
        <span style={styles.menuIcon}>{item.icon}</span>
        {!isCollapsed && (
          <span style={menuTextStyle}>
            {item.name}
          </span>
        )}
      </button>
    );
  };

  const getStatusStyle = (status) => {
    return status === 'Completed' ? styles.statusCompleted : styles.statusActive;
  };

  const filteredHistory = fitnessPlanHistory.filter(plan =>
    plan.planTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
    plan.status.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div style={styles.container}>
      {/* Sidebar */}
      <div style={styles.sidebar}>
        {/* Brand */}
        <div style={styles.brand}>
          <img 
            src="/fnw1.png" 
            alt="FitNWell Logo"
            style={styles.brandIcon}
          />
          {!isCollapsed && (
            <span style={styles.brandText}>FitNWell</span>
          )}
        </div>

        {/* Menu Items */}
        <div style={styles.menuContainer}>
          <div style={styles.menuDivider} />
          
          <div style={styles.menuGroup}>
            {menuItems.slice(0, 7).map((item, index) => renderMenuItem(item, index))}
          </div>
          
          <div style={styles.menuGroup}>
            {menuItems.slice(7).map((item, index) => renderMenuItem(item, index + 7))}
          </div>
        </div>

        {/* Logout Button */}
        <button 
          style={styles.logoutButton}
          onClick={onLogout}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#f5f5f5';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#fff';
          }}
        >
          <span style={styles.logoutIcon}><CiLogout /></span>
          {!isCollapsed && (
            <span style={styles.logoutText}>Log Out</span>
          )}
        </button>
      </div>

      {/* Main Content */}
      <div style={styles.mainContent}>
        {/* Header */}
        <div style={styles.header}>
          <button 
            style={styles.collapseButton}
            onClick={() => setIsCollapsed(!isCollapsed)}
          >
            {isCollapsed ? <FaChevronRight /> : <FaChevronLeft />}
          </button>
          <span style={styles.pageTitle}>Fitness Plans</span>
          <button style={styles.profileButton}
          onClick={() => navigate('/coach-user-profile')}
          >
            <FaUserCircle />
          </button>
        </div>

        {/* Back Button */}
        <button 
          style={styles.backButton}
          onClick={() => navigate('/coach-fitness-plans')}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#f8f9fa';
            e.target.style.borderColor = '#d0d0d0';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#fff';
            e.target.style.borderColor = '#e0e0e0';
          }}
        >
          <FaArrowLeft style={{ marginRight: '8px' }} />
          Back to Fitness Plans
        </button>

        {/* Client Information */}
        <div style={styles.clientInfo}>
          Client Name: {userData.name}
        </div>

        {/* Search */}
        <div style={styles.searchContainer}>
          <div style={styles.searchBox}>
            <FaSearch style={styles.searchIcon} />
            <input
              type="text"
              placeholder="Search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={styles.searchInput}
            />
          </div>
        </div>

        {/* Fitness Plan History Table */}
        <div style={styles.tableContainer}>
          <table style={styles.table}>
            <thead style={styles.tableHeader}>
              <tr>
                <th style={styles.tableHeaderCell}>ID</th>
                <th style={styles.tableHeaderCell}>Plan Title</th>
                <th style={styles.tableHeaderCell}>Start Date</th>
                <th style={styles.tableHeaderCell}>End Date</th>
                <th style={styles.tableHeaderCell}>Status</th>
                <th style={styles.tableHeaderCell}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredHistory.map((plan) => (
                <tr 
                  key={plan.id} 
                  style={styles.tableRow}
                  onMouseEnter={(e) => {
                    e.target.parentElement.style.backgroundColor = '#f8f9fa';
                  }}
                  onMouseLeave={(e) => {
                    e.target.parentElement.style.backgroundColor = 'transparent';
                  }}
                >
                  <td style={styles.tableCell}>{plan.id}</td>
                  <td style={styles.tableCell}>{plan.planTitle}</td>
                  <td style={styles.tableCell}>{plan.startDate}</td>
                  <td style={styles.tableCell}>{plan.endDate}</td>
                  <td style={styles.tableCell}>
                    <span style={{...styles.statusBadge, ...getStatusStyle(plan.status)}}>
                      {plan.status}
                    </span>
                  </td>
                  <td style={styles.tableCell}>
                    <div style={styles.actionButtons}>
                      <button 
                        style={styles.viewButton}
                        onClick={() => handleViewPlan(plan)}
                        onMouseEnter={(e) => {
                          e.target.style.backgroundColor = '#6aa3d9';
                        }}
                        onMouseLeave={(e) => {
                          e.target.style.backgroundColor = colors.view;
                        }}
                      >
                        View
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* View Fitness Plan Modal */}
      {isViewPlanModalOpen && selectedPlan && (
        <div style={viewPlanModalStyles.overlay}>
          <div style={viewPlanModalStyles.modal}>
            <div style={viewPlanModalStyles.header}>
              <h3 style={viewPlanModalStyles.title}>View Fitness Plan</h3>
              <button 
                style={viewPlanModalStyles.closeButton}
                onClick={handleCloseViewPlanModal}
                onMouseEnter={(e) => {
                  e.target.style.color = '#666';
                }}
                onMouseLeave={(e) => {
                  e.target.style.color = '#333';
                }}
              >
                ✕
              </button>
            </div>
            <div style={viewPlanModalStyles.content}>
              <div style={viewPlanModalStyles.detailRow}>
                <span style={viewPlanModalStyles.detailLabel}>Plan ID:</span>
                <span style={viewPlanModalStyles.detailValue}>{selectedPlan.planId}</span>
              </div>
              <div style={viewPlanModalStyles.detailRow}>
                <span style={viewPlanModalStyles.detailLabel}>Plan Title:</span>
                <span style={viewPlanModalStyles.detailValue}>{selectedPlan.planTitle}</span>
              </div>
              <div style={viewPlanModalStyles.detailRow}>
                <span style={viewPlanModalStyles.detailLabel}>Name:</span>
                <span style={viewPlanModalStyles.detailValue}>{selectedPlan.name}</span>
              </div>
              <div style={viewPlanModalStyles.detailRow}>
                <span style={viewPlanModalStyles.detailLabel}>Date:</span>
                <span style={viewPlanModalStyles.detailValue}>{selectedPlan.date}</span>
              </div>
              <div style={viewPlanModalStyles.detailRow}>
                <span style={viewPlanModalStyles.detailLabel}>Days:</span>
                <span style={viewPlanModalStyles.detailValue}>{selectedPlan.days}</span>
              </div>

              <div style={viewPlanModalStyles.exercisesSection}>
                <div style={viewPlanModalStyles.exercisesTitle}>Exercises:</div>
                
                <div style={viewPlanModalStyles.exerciseCategory}>
                  <div style={viewPlanModalStyles.categoryTitle}>Warm Up:</div>
                  {selectedPlan.exercises.warmUp.map((exercise, index) => (
                    <div key={index} style={viewPlanModalStyles.exerciseItem}>
                      {exercise.name} - {exercise.duration}
                    </div>
                  ))}
                </div>

                <div style={viewPlanModalStyles.exerciseCategory}>
                  <div style={viewPlanModalStyles.categoryTitle}>Main Exercise:</div>
                  {selectedPlan.exercises.mainExercise.map((exercise, index) => (
                    <div key={index} style={viewPlanModalStyles.exerciseItem}>
                      {exercise.name} - {exercise.sets} sets x {exercise.reps} reps
                    </div>
                  ))}
                </div>

                <div style={viewPlanModalStyles.exerciseCategory}>
                  <div style={viewPlanModalStyles.categoryTitle}>Cool Down:</div>
                  {selectedPlan.exercises.coolDown.map((exercise, index) => (
                    <div key={index} style={viewPlanModalStyles.exerciseItem}>
                      {exercise.name} - {exercise.duration}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Coach_FPHistory; 