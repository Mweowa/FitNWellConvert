import React, { useState } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { colors } from '../../utils/colors';
import { FaUserCircle, FaHome, FaClipboardList, FaList, FaSearch, FaArrowLeft } from "react-icons/fa";
import { FaCalendarPlus, FaChevronRight, FaChevronLeft } from "react-icons/fa6";
import { IoScaleSharp, IoChatbubbleSharp } from "react-icons/io5";
import { MdFactCheck } from "react-icons/md";
import { CiLogout } from "react-icons/ci";
import Approved from '../../components/Approved';
import Rejected from '../../components/Rejected';
import PhotoProofModal from '../../components/PhotoProofModal';

const Coach_ALView = ({ onLogout }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { clientName } = useParams(); // Get clientName from URL parameters
  const decodedClientName = decodeURIComponent(clientName); // Decode the client name
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [activeMenu, setActiveMenu] = useState('activity-logs');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedActivity, setSelectedActivity] = useState(null);
  const [showPhotoModal, setShowPhotoModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [showRejectedModal, setShowRejectedModal] = useState(false);

  // Get user data from location state or use default
  const userData = location.state?.userData || {
    id: 1,
    name: decodedClientName,
    plans: "01"
  };

  const handleLogout = () => {
    onLogout();
    navigate('/');
  };

  const handleMenuClick = (route) => {
    setActiveMenu(route);
    if (route === 'dashboard') {
      navigate('/coach-dashboard');
    } else if (route === 'plan-requests') {
      navigate('/coach-plan-requests');
    } else if (route === 'fitness-plans') {
      navigate('/coach-fitness-plans');
    } else if (route === 'activity-logs') {
      navigate('/coach-activity-logs');
    } else if (route === 'fitness-assessments') {
      navigate('/coach-fitness-assessments');
    } else if (route === 'measurements') {
      navigate('/coach-measurements');
    } else if (route === 'messages') {
      navigate('/coach-messages');
    }
  };

  // Handle back navigation
  const handleBack = () => {
    navigate('/coach-activity-logs');
  };

  // Generate activity logs data based on client name - updated to match CHK_FPHistory pattern
  const [activityLogs, setActivityLogs] = useState(() => {
    const userName = userData.name;
    
    if (userName === "Jimmy Reyes") {
      return [
        { id: 1, planTitle: "Workout 1", date: "August 7", activityStatus: "Done", proofStatus: "Approved" },
        { id: 2, planTitle: "Workout 1", date: "August 8", activityStatus: "Missed", proofStatus: "Rejected" },
        { id: 3, planTitle: "Workout 2", date: "August 21", activityStatus: "Done", proofStatus: "Approved" },
        { id: 4, planTitle: "Workout 3", date: "August 30", activityStatus: "Done", proofStatus: "Pending" }
      ];
    } else if (userName === "Grace Mendoza") {
      return [
        { id: 1, planTitle: "Cardio Session 1", date: "August 5", activityStatus: "Done", proofStatus: "Approved" },
        { id: 2, planTitle: "Strength Training", date: "August 10", activityStatus: "Done", proofStatus: "Approved" },
        { id: 3, planTitle: "Yoga Session", date: "August 15", activityStatus: "Missed", proofStatus: "Rejected" },
        { id: 4, planTitle: "HIIT Workout", date: "August 25", activityStatus: "Done", proofStatus: "Pending" }
      ];
    } else if (userName === "Carlo Chua") {
      return [
        { id: 1, planTitle: "Push Day", date: "August 3", activityStatus: "Done", proofStatus: "Approved" },
        { id: 2, planTitle: "Pull Day", date: "August 6", activityStatus: "Done", proofStatus: "Approved" },
        { id: 3, planTitle: "Leg Day", date: "August 12", activityStatus: "Done", proofStatus: "Approved" },
        { id: 4, planTitle: "Rest Day Walk", date: "August 20", activityStatus: "Missed", proofStatus: "Rejected" },
        { id: 5, planTitle: "Upper Body", date: "August 28", activityStatus: "Done", proofStatus: "Pending" }
      ];
    } else if (userName === "Daniel Torres") {
      return [
        { id: 1, planTitle: "Morning Run", date: "August 1", activityStatus: "Done", proofStatus: "Approved" },
        { id: 2, planTitle: "Weight Training", date: "August 8", activityStatus: "Done", proofStatus: "Approved" },
        { id: 3, planTitle: "Swimming", date: "August 14", activityStatus: "Done", proofStatus: "Approved" },
        { id: 4, planTitle: "Core Workout", date: "August 22", activityStatus: "Done", proofStatus: "Pending" }
      ];
    } else {
      return [
        { id: 1, planTitle: "General Workout 1", date: "August 5", activityStatus: "Done", proofStatus: "Approved" },
        { id: 2, planTitle: "General Workout 2", date: "August 12", activityStatus: "Missed", proofStatus: "Rejected" },
        { id: 3, planTitle: "General Workout 3", date: "August 19", activityStatus: "Done", proofStatus: "Pending" }
      ];
    }
  });

  const handleViewProof = (log) => {
    console.log('Viewing proof for:', log.planTitle, 'on', log.date);
  
    const logWithFullInfo = {
      ...log,
      status: log.proofStatus, // 👈 Added this so modals get `activity.status`
      activityStatusStyle: getStatusStyle(log.activityStatus, 'activity'),
      proofStatusStyle: getStatusStyle(log.proofStatus, 'proof')
    };
  
    setSelectedActivity(logWithFullInfo);
  
    if (log.proofStatus === 'Approved') {
      setShowDetailModal(true);
    } else if (log.proofStatus === 'Rejected') {
      setShowRejectedModal(true);
    } else if (log.proofStatus === 'Pending') {
      setShowPhotoModal(true);
    }
  };
  
  
  const handleApprove = () => {
    if (selectedActivity) {
      setActivityLogs(prevLogs =>
        prevLogs.map(log =>
          log.id === selectedActivity.id
            ? { ...log, proofStatus: 'Approved' }
            : log
        )
      );
      setSelectedActivity(prev =>
        prev ? { ...prev, proofStatus: 'Approved' } : null
      );
    }
    setShowPhotoModal(false);
  };
  
  const handleReject = (reason) => {
    if (selectedActivity) {
      setActivityLogs(prevLogs =>
        prevLogs.map(log =>
          log.id === selectedActivity.id
            ? { ...log, proofStatus: 'Rejected', rejectionReason: reason }
            : log
        )
      );
      setSelectedActivity(prev =>
        prev ? { ...prev, proofStatus: 'Rejected', rejectionReason: reason } : null
      );
    }
    setShowPhotoModal(false);
  };


  const getStatusStyle = (status, type) => {
    const baseStyle = {
      padding: '4px 12px',
      borderRadius: '12px',
      fontSize: '11px',
      fontWeight: '500',
      border: 'none',
      cursor: type === 'proof' ? 'pointer' : 'default',
      minWidth: '70px',
      textAlign: 'center'
    };

    if (type === 'activity') {
      if (status === 'Done') {
        return { ...baseStyle, backgroundColor: colors.verified, color: '#fff' };
      } else if (status === 'Missed') {
        return { ...baseStyle, backgroundColor: colors.delete, color:  '#fff' };
      }
    } else if (type === 'proof') {
      if (status === 'Approved') {
        return { ...baseStyle, backgroundColor: colors.verified, color:  '#fff'};
      } else if (status === 'Rejected') {
        return { ...baseStyle, backgroundColor: colors.delete, color:  '#fff' };
      } else if (status === 'Pending') {
        return { ...baseStyle, backgroundColor: colors.rejected, color:  '#fff' };
      }
    }

    return baseStyle;
  };

  // Add search functionality
  const filteredLogs = activityLogs.filter(log =>
    log.planTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
    log.activityStatus.toLowerCase().includes(searchTerm.toLowerCase()) ||
    log.proofStatus.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const styles = {
    container: {
      display: 'flex',
      flexDirection: 'row',
      height: '100vh',
      backgroundColor: '#FEFFFD',
      overflow: 'auto',
    },
    sidebar: {
      backgroundColor: '#F1F1F2',
      padding: '17px 15px',
      width: isCollapsed ? '80px' : '230px',
      transition: 'width 0.3s ease, padding 0.3s ease',
      display: 'flex',
      flexDirection: 'column',
    },
    brand: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '15px',
      padding: isCollapsed ? '0' : '0 10px',
      justifyContent: isCollapsed ? 'center' : 'flex-start',
    },
    brandIcon: {
      width: '47px',
      height: '40px',
    },
    brandText: {
      fontSize: '25px',
      color: colors.d_gray,
      fontWeight: 'bold',
      fontStyle: 'italic',
      marginLeft: '15px',
    },
    menuContainer: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
    },
    menuGroup: {
      marginBottom: '20px',
    },
    menuDivider: {
      height: '1px',
      backgroundColor: '#e0e0e0',
      marginBottom: '15px',
    },
    menuItem: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemActive: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'rgba(159, 192, 59, 0.2)',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemCollapsed: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '12px 8px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuIcon: {
      fontSize: '20px',
      marginRight: isCollapsed ? '0' : '12px',
      color: colors.main,
      display: 'flex',
      alignItems: 'center',
    },
    menuText: {
      fontSize: '14px',
      color: colors.d_gray,
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    menuTextActive: {
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '600',
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    logoutButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#fff',
      border: 'none',
      borderRadius: '30px',
      padding: isCollapsed ? '2px 3px' : '7px 12px',
      marginTop: '20px',
      marginBottom: '10px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      width: isCollapsed ? 'auto' : 'fit-content',
      alignSelf: 'center',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
    },
    logoutIcon: {
      background: 'none',
      fontSize: '18px',
      marginRight: isCollapsed ? '0' : '8px',
      display: 'flex',
      alignItems: 'center',
      color: colors.main,
    },
    logoutText: {
      background: 'none',
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '500',
    },
    mainContent: {
      flex: 1,
      backgroundColor: '#FEFFFD',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '30px',
    },
    collapseButton: {
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      fontSize: '10px',
      color: colors.l_gray,
      transition: 'background-color 0.2s ease',
      marginLeft: '-10px'
    },
    pageTitle: {
      fontSize: '28px',
      fontWeight: 'bold',
      color: colors.main,
      marginBottom: '20px',
    },
    profileButton: {
      color: colors.main,      
      marginTop: '5px',
      marginRight: '5px',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontSize: '32px',
    },
    backButton: {
      display: 'flex',
      alignItems: 'center',
      backgroundColor: '#fff',
      color: colors.d_gray,
      border: '1px solid #e0e0e0',
      borderRadius: '6px',
      padding: '8px 16px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '500',
      transition: 'all 0.2s ease',
      marginBottom: '20px',
      width: 'fit-content',
    },
    clientInfo: {
      fontSize: '18px',
      fontWeight: 'bold',
      color: colors.d_gray,
      marginBottom: '20px',
    },
    searchContainer: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '20px',
      gap: '15px',
    },
    searchBox: {
      display: 'flex',
      alignItems: 'center',
      backgroundColor: '#fff',
      border: '1px solid #e0e0e0',
      borderRadius: '8px',
      padding: '10px 15px',
      flex: 1,
      maxWidth: '400px',
    },
    searchIcon: {
      color: '#999',
      marginRight: '10px',
      fontSize: '16px',
    },
    searchInput: {
      border: 'none',
      outline: 'none',
      flex: 1,
      fontSize: '14px',
      color: '#333',
    },
    tableContainer: {
      backgroundColor: '#fff',
      borderRadius: '8px',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
      overflow: 'hidden',
    },
    table: {
      width: '100%',
      borderCollapse: 'collapse',
    },
    tableHeader: {
      backgroundColor: '#f8f9fa',
      borderBottom: '1px solid #e0e0e0',
    },
    tableHeaderCell: {
      padding: '15px 12px',
      textAlign: 'left',
      fontSize: '14px',
      fontWeight: '600',
      color: '#333',
      borderBottom: '1px solid #e0e0e0',
    },
    tableRow: {
      borderBottom: '1px solid #f0f0f0',
    },
    tableCell: {
      padding: '12px',
      fontSize: '14px',
      color: '#333',
      borderBottom: '1px solid #f0f0f0',
    },
    viewButton: {
      backgroundColor: colors.view,
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '6px 12px',
      cursor: 'pointer',
      fontSize: '12px',
      transition: 'background-color 0.2s ease',
    }
  };

  const menuItems = [
    { name: 'Dashboard', icon: <FaHome />, route: 'dashboard', active: activeMenu === 'dashboard' },
    { name: 'Plan Requests', icon: <FaCalendarPlus />, route: 'plan-requests', active: activeMenu === 'plan-requests' },
    { name: 'Fitness Plans', icon: <FaList />, route: 'fitness-plans', active: activeMenu === 'fitness-plans' },
    { name: 'Activity Logs', icon: <FaClipboardList />, route: 'activity-logs', active: activeMenu === 'activity-logs' },
    { name: 'Fitness Assessments', icon: <MdFactCheck />, route: 'fitness-assessments', active: activeMenu === 'fitness-assessments' },
    { name: 'Measurements', icon: <IoScaleSharp />, route: 'measurements', active: activeMenu === 'measurements' },
    { name: 'Messages', icon: <IoChatbubbleSharp />, route: 'messages', active: activeMenu === 'messages' },
  ];

  const renderMenuItem = (item, index) => {
    const menuItemStyle = item.active 
      ? (isCollapsed ? styles.menuItemCollapsed : styles.menuItemActive)
      : (isCollapsed ? styles.menuItemCollapsed : styles.menuItem);
    
    const menuTextStyle = item.active ? styles.menuTextActive : styles.menuText;

    return (
      <button
        key={index}
        style={menuItemStyle}
        onClick={() => handleMenuClick(item.route)}
        onMouseEnter={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'rgba(159, 192, 59, 0.1)';
          }
        }}
        onMouseLeave={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'transparent';
          }
        }}
      >
        <span style={styles.menuIcon}>{item.icon}</span>
        {!isCollapsed && (
          <span style={menuTextStyle}>
            {item.name}
          </span>
        )}
      </button>
    );
  };

  return (
    <div style={styles.container}>
      {/* Sidebar */}
      <div style={styles.sidebar}>
        {/* Brand */}
        <div style={styles.brand}>
          <img 
            src="/fnw1.png" 
            alt="FitNWell Logo"
            style={styles.brandIcon}
          />
          {!isCollapsed && (
            <span style={styles.brandText}>FitNWell</span>
          )}
        </div>

        {/* Menu Items */}
        <div style={styles.menuContainer}>
          <div style={styles.menuDivider} />
          
          <div style={styles.menuGroup}>
            {menuItems.slice(0, 7).map((item, index) => renderMenuItem(item, index))}
          </div>
          
          <div style={styles.menuGroup}>
            {menuItems.slice(7).map((item, index) => renderMenuItem(item, index + 7))}
          </div>
        </div>

        {/* Logout Button */}
        <button 
          style={styles.logoutButton}
          onClick={handleLogout}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#f5f5f5';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#fff';
          }}
        >
          <span style={styles.logoutIcon}><CiLogout /></span>
          {!isCollapsed && (
            <span style={styles.logoutText}>Log Out</span>
          )}
        </button>
      </div>

      {/* Main Content */}
      <div style={styles.mainContent}>
        {/* Header */}
        <div style={styles.header}>
          <button 
            style={styles.collapseButton}
            onClick={() => setIsCollapsed(!isCollapsed)}
          >
            {isCollapsed ? <FaChevronRight /> : <FaChevronLeft />}
          </button>
          <span style={styles.pageTitle}>Activity Logs</span>
          <button style={styles.profileButton}
          onClick={() => navigate('/coach-user-profile')}
          >
            <FaUserCircle />
          </button>
        </div>

        {/* Back Button */}
        <button 
          style={styles.backButton}
          onClick={handleBack}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#f8f9fa';
            e.target.style.borderColor = '#d0d0d0';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#fff';
            e.target.style.borderColor = '#e0e0e0';
          }}
        >
          <FaArrowLeft style={{ marginRight: '8px' }} />
          Back to Activity Logs
        </button>

        {/* Client Info */}
        <div style={styles.clientInfo}>
          Client Name: {userData.name}
        </div>

        {/* Search */}
        <div style={styles.searchContainer}>
          <div style={styles.searchBox}>
            <FaSearch style={styles.searchIcon} />
            <input
              type="text"
              placeholder="Search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={styles.searchInput}
            />
          </div>
        </div>

        {/* Activity Logs Table */}
        <div style={styles.tableContainer}>
          <table style={styles.table}>
            <thead style={styles.tableHeader}>
              <tr>
                <th style={styles.tableHeaderCell}>ID</th>
                <th style={styles.tableHeaderCell}>Plan Title</th>
                <th style={styles.tableHeaderCell}>Date</th>
                <th style={styles.tableHeaderCell}>Activity Status</th>
                <th style={{ ...styles.tableHeaderCell, borderLeft: '1px solid #D9D9D9' }}>
                  Proof
                </th>
                <th style={styles.tableHeaderCell}>Proof Status</th>
               </tr>
            </thead>
            <tbody>
              {filteredLogs.map((log) => (
                <tr 
                  key={log.id} 
                  style={styles.tableRow}
                  onMouseEnter={(e) => {
                    e.target.parentElement.style.backgroundColor = '#f8f9fa';
                  }}
                  onMouseLeave={(e) => {
                    e.target.parentElement.style.backgroundColor = 'transparent';
                  }}
                >
                  <td style={styles.tableCell}>{log.id}</td>
                  <td style={styles.tableCell}>{log.planTitle}</td>
                  <td style={styles.tableCell}>{log.date}</td>
                  <td style={styles.tableCell}>
                    <span style={getStatusStyle(log.activityStatus, 'activity')}>
                      {log.activityStatus}
                    </span>
                  </td>
                  <td style={{
                    ...styles.tableCell,
                    borderLeft: '1px solid #D9D9D9'
                  }}>
                    <button 
                      style={styles.viewButton}
                      onClick={() => handleViewProof(log)}
                      onMouseEnter={(e) => {
                        e.target.style.backgroundColor = '#6aa3d9';
                      }}
                      onMouseLeave={(e) => {
                        e.target.style.backgroundColor = colors.view;
                      }}
                    >
                      View
                    </button>
                  </td>
                  <td style={styles.tableCell}>
                    <span style={getStatusStyle(log.proofStatus, 'proof')}>
                      {log.proofStatus}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Photo Proof Modal */}
      <PhotoProofModal
        visible={showPhotoModal}
        onClose={() => {
          setShowPhotoModal(false);
          setSelectedActivity(null);
        }}
        onApprove={handleApprove}
        onReject={handleReject}
        photoUrl={selectedActivity?.proof}
      />

      {/* Rejected Modal */}
      <Rejected
        visible={showRejectedModal}
        onClose={() => {
          setShowRejectedModal(false);
          setSelectedActivity(null);
        }}
        activity={selectedActivity}
      />

      {/* Activity Detail Modal (Approved) */}
      <Approved
        visible={showDetailModal}
        onClose={() => {
          setShowDetailModal(false);
          setSelectedActivity(null);
        }}
        activity={selectedActivity}
      />
    </div>
  );
};

export default Coach_ALView;
