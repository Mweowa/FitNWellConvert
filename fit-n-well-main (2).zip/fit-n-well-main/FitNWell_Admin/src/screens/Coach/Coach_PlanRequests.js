import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaUserCircle, FaHome, FaClipboardList, FaList, FaSearch, FaChevronRight, FaChevronLeft } from "react-icons/fa";
import { FaCalendarPlus } from "react-icons/fa6";
import { IoScaleSharp, IoChatbubbleSharp } from "react-icons/io5";
import { MdFactCheck } from "react-icons/md";
import { CiLogout } from "react-icons/ci";

const Coach_PlanRequests = ({ onLogout }) => {
  const navigate = useNavigate();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeMenu, setActiveMenu] = useState('plan-requests');
  const [showModal, setShowModal] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState(null);

  // Modal form state
  const [formData, setFormData] = useState({
    planTitle: '',
    startDate: '',
    endDate: '',
    selectedDays: [],
    warmUpExercises: [{ name: '', time: '' }],
    mainExercises: [{ name: '', sets: '', reps: '' }],
    coolDownExercises: [{ name: '', time: '' }]
  });

  const handleLogout = () => {
    onLogout();
    navigate('/');
  };

  const handleMenuClick = (route) => {
    setActiveMenu(route);
    if (route === 'dashboard') {
      navigate('/coach-dashboard');
    } else if (route === 'plan-requests') {
      navigate('/coach-plan-requests');
    } else if (route === 'fitness-plans') {
      navigate('/coach-fitness-plans');
    } else if (route === 'activity-logs') {
      navigate('/coach-activity-logs');
    } else if (route === 'fitness-assessments') {
      navigate('/coach-fitness-assessments');
    } else if (route === 'measurements') {
      navigate('/coach-measurements');
    } else if (route === 'messages') {
      navigate('/coach-messages');
    }
  };

  // Sample fitness plans data
  const [fitnessPlans] = useState([
    { id: 1, name: "Jimmy Reyes", plans: "01" },
    { id: 2, name: "Grace Mendoza", plans: "02" },
    { id: 3, name: "Carlo Chua", plans: "04" },
    { id: 4, name: "Daniel Torres", plans: "02" }
  ]);

  const daysOfWeek = ['Mon', 'Tues', 'Wed', 'Thurs', 'Fri', 'Sat', 'Sun'];

  const handleDayToggle = (day) => {
    setFormData(prev => ({
      ...prev,
      selectedDays: prev.selectedDays.includes(day)
        ? prev.selectedDays.filter(d => d !== day)
        : [...prev.selectedDays, day]
    }));
  };

  const addWarmUpExercise = () => {
    setFormData(prev => ({
      ...prev,
      warmUpExercises: [...prev.warmUpExercises, { name: '', time: '' }]
    }));
  };

  const addMainExercise = () => {
    setFormData(prev => ({
      ...prev,
      mainExercises: [...prev.mainExercises, { name: '', sets: '', reps: '' }]
    }));
  };

  const addCoolDownExercise = () => {
    setFormData(prev => ({
      ...prev,
      coolDownExercises: [...prev.coolDownExercises, { name: '', time: '' }]
    }));
  };

  const removeWarmUpExercise = (index) => {
    setFormData(prev => ({
      ...prev,
      warmUpExercises: prev.warmUpExercises.filter((_, i) => i !== index)
    }));
  };

  const removeMainExercise = (index) => {
    setFormData(prev => ({
      ...prev,
      mainExercises: prev.mainExercises.filter((_, i) => i !== index)
    }));
  };

  const removeCoolDownExercise = (index) => {
    setFormData(prev => ({
      ...prev,
      coolDownExercises: prev.coolDownExercises.filter((_, i) => i !== index)
    }));
  };

  const updateWarmUpExercise = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      warmUpExercises: prev.warmUpExercises.map((exercise, i) =>
        i === index ? { ...exercise, [field]: value } : exercise
      )
    }));
  };

  const updateMainExercise = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      mainExercises: prev.mainExercises.map((exercise, i) =>
        i === index ? { ...exercise, [field]: value } : exercise
      )
    }));
  };

  const updateCoolDownExercise = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      coolDownExercises: prev.coolDownExercises.map((exercise, i) =>
        i === index ? { ...exercise, [field]: value } : exercise
      )
    }));
  };

  const openModal = (plan) => {
    setSelectedPlan(plan);
    setShowModal(true);
    // Reset form data
    setFormData({
      planTitle: '',
      startDate: '',
      endDate: '',
      selectedDays: [],
      warmUpExercises: [{ name: '', time: '' }],
      mainExercises: [{ name: '', sets: '', reps: '' }],
      coolDownExercises: [{ name: '', time: '' }]
    });
  };

  const closeModal = () => {
    setShowModal(false);
    setSelectedPlan(null);
  };

  const handleSave = () => {
    console.log('Saving plan:', formData);
    // Handle save logic here
    closeModal();
  };

  const styles = {
    container: {
      display: 'flex',
      flexDirection: 'row',
      height: '100vh',
      backgroundColor: '#FEFFFD',
      overflow: 'auto',
    },
    sidebar: {
      backgroundColor: '#F1F1F2',
      padding: '17px 15px',
      width: isCollapsed ? '80px' : '230px',
      transition: 'width 0.3s ease, padding 0.3s ease',
      display: 'flex',
      flexDirection: 'column',
    },
    brand: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '15px',
      padding: isCollapsed ? '0' : '0 10px',
      justifyContent: isCollapsed ? 'center' : 'flex-start',
    },
    brandIcon: {
      width: '47px',
      height: '40px',
    },
    brandText: {
      fontSize: '25px',
      color:  "#5B5B5B",
      fontWeight: 'bold',
      fontStyle: 'italic',
      marginLeft: '15px',
    },
    menuContainer: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
    },
    menuGroup: {
      marginBottom: '20px',
    },
    menuDivider: {
      height: '1px',
      backgroundColor: '#e0e0e0',
      marginBottom: '15px',
    },
    menuItem: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemActive: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'rgba(159, 192, 59, 0.2)',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemCollapsed: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '12px 8px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuIcon: {
      fontSize: '20px',
      marginRight: isCollapsed ? '0' : '12px',
      color: "#9FC03B",
      display: 'flex',
      alignItems: 'center',
    },
    menuText: {
      fontSize: '14px',
      color: "#5B5B5B",
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    menuTextActive: {
      fontSize: '14px',
      color: "#5B5B5B",
      fontWeight: '600',
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    logoutButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#fff',
      border: 'none',
      borderRadius: '30px',
      padding: isCollapsed ? '2px 3px' : '7px 12px',
      marginTop: '20px',
      marginBottom: '10px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      width: isCollapsed ? 'auto' : 'fit-content',
      alignSelf: 'center',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
    },
    logoutIcon: {
      background: 'none',
      fontSize: '18px',
      marginRight: isCollapsed ? '0' : '8px',
      display: 'flex',
      alignItems: 'center',
      color: "#9FC03B",
    },
    logoutText: {
      background: 'none',
      fontSize: '14px',
      color: "#5B5B5B",
      fontWeight: '500',
    },
    mainContent: {
      flex: 1,
      backgroundColor: '#FEFFFD',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '30px',
    },
    collapseButton: {
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      fontSize: '10px',
      color: "#8E8B8B",
      transition: 'background-color 0.2s ease',
      marginLeft: '-10px'
    },
    pageTitle: {
      fontSize: '28px',
      fontWeight: 'bold',
      color: "#9FC03B",
      marginBottom: '20px',
    },
    profileButton: {
      color: "#9FC03B",      
      marginTop: '5px',
      marginRight: '5px',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontSize: '32px',
    },
    searchContainer: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '20px',
      gap: '15px',
    },
    searchBox: {
      display: 'flex',
      alignItems: 'center',
      backgroundColor: '#fff',
      border: '1px solid #e0e0e0',
      borderRadius: '8px',
      padding: '10px 15px',
      flex: 1,
      maxWidth: '400px',
    },
    searchIcon: {
      color: '#999',
      marginRight: '10px',
      fontSize: '16px',
    },
    searchInput: {
      border: 'none',
      outline: 'none',
      flex: 1,
      fontSize: '14px',
      color: '#333',
    },
    tableContainer: {
      backgroundColor: '#fff',
      borderRadius: '8px',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
      overflow: 'hidden',
    },
    table: {
      width: '100%',
      borderCollapse: 'collapse',
    },
    tableHeader: {
      backgroundColor: '#f8f9fa',
      borderBottom: '1px solid #e0e0e0',
    },
    tableHeaderCell: {
      padding: '15px 12px',
      textAlign: 'left',
      fontSize: '14px',
      fontWeight: '600',
      color: '#333',
      borderBottom: '1px solid #e0e0e0',
    },
    tableRow: {
      borderBottom: '1px solid #f0f0f0',
    },
    tableCell: {
      padding: '12px',
      fontSize: '14px',
      color: '#333',
      borderBottom: '1px solid #f0f0f0',
    },
    actionButtons: {
      display: 'flex',
      gap: '8px',
    },
    addButton: {
      backgroundColor: "#9FC03B",
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '6px 12px',
      cursor: 'pointer',
      fontSize: '12px',
      transition: 'background-color 0.2s ease',
    },
    // Modal Styles
    overlay: {
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      zIndex: 1000,
    },
    modal: {
      backgroundColor: '#fff',
      borderRadius: '8px',
      padding: '0',
      width: '800px',
      maxWidth: '90vw',
      maxHeight: '90vh',
      boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
      display: 'flex',
      flexDirection: 'column',
    },
    modalHeader: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '20px 24px',
      borderBottom: '1px solid #e0e0e0',
      flexShrink: 0,
    },
    modalTitle: {
      margin: 0,
      fontSize: '20px',
      fontWeight: 'bold',
      color: '#9FC03B',
    },
    closeButton: {
      background: 'none',
      border: 'none',
      fontSize: '18px',
      cursor: 'pointer',
      color: '#333',
      padding: '4px',
      borderRadius: '4px',
      transition: 'color 0.2s ease',
    },
    modalContent: {
      padding: '24px',
      overflowY: 'auto',
      flex: 1,
      maxHeight: 'calc(90vh - 80px)',
    },
    formGroup: {
      marginBottom: '16px',
    },
    label: {
      display: 'block',
      fontSize: '16px',
      fontWeight: '600',
      color: '#333',
      marginBottom: '6px',
    },
    input: {
      width: '100%',
      padding: '8px 12px',
      border: '1px solid #e0e0e0',
      borderRadius: '4px',
      fontSize: '14px',
      backgroundColor: '#f8f9fa',
      outline: 'none',
      transition: 'border-color 0.2s ease',
      fontFamily: 'Inter',
    },
    daysContainer: {
      display: 'flex',
      gap: '8px',
      marginTop: '8px',
      flexWrap: 'wrap',
    },
    dayButton: {
      marginTop: '25px',
      padding: '8px 36px',
      border: 'none',
      borderRadius: '4px',
      fontSize: '14px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
    },
    dayButtonInactive: {
      backgroundColor: '#e0e0e0',
      color: '#666',
    },
    dayButtonActive: {
      backgroundColor: '#9FC03B',
      color: '#fff',
    },
    exerciseSection: {
      marginTop: '25px',
    },
    exerciseSectionTitle: {
      fontSize: '16px',
      fontWeight: '600',
      color: '#333',
      marginBottom: '12px',
    },
    exerciseItem: {
      display: 'flex',
      gap: '8px',
      alignItems: 'center',
      marginBottom: '8px',
    },
    exerciseInput: {
      width: '490px',
      padding: '8px 12px',
      border: '1px solid #e0e0e0',
      borderRadius: '4px',
      fontSize: '14px',
      backgroundColor: '#f8f9fa',
      outline: 'none',
    },
    smallInput: {
      width: '135px',
      padding: '8px 12px',
      border: '1px solid #e0e0e0',
      borderRadius: '4px',
      fontSize: '14px',
      backgroundColor: '#f8f9fa',
      outline: 'none',
    },
    removeButton: {
      backgroundColor: '#FF6B6B',
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '8px 12px',
      cursor: 'pointer',
      fontSize: '12px',
    },
    addExerciseButton: {
      backgroundColor: '#9FC03B',
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '8px 16px',
      cursor: 'pointer',
      fontSize: '12px',
      marginTop: '8px',
    },
    modalFooter: {
      display: 'flex',
      justifyContent: 'flex-end',
      padding: '20px 24px',
      borderTop: '1px solid #e0e0e0',
    },
    saveButton: {
      backgroundColor: "#9FC03B",
      color: '#fff',
      border: 'none',
      borderRadius: '4px',
      padding: '10px 20px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '500',
      transition: 'background-color 0.2s ease',
    },
  };

  const menuItems = [
    { name: 'Dashboard', icon: <FaHome />, route: 'dashboard', active: activeMenu === 'dashboard' },
    { name: 'Plan Requests', icon: <FaCalendarPlus />, route: 'plan-requests', active: activeMenu === 'plan-requests' },
    { name: 'Fitness Plans', icon: <FaList />, route: 'fitness-plans', active: activeMenu === 'fitness-plans' },
    { name: 'Activity Logs', icon: <FaClipboardList />, route: 'activity-logs', active: activeMenu === 'activity-logs' },
    { name: 'Fitness Assessments', icon: <MdFactCheck />, route: 'fitness-assessments', active: activeMenu === 'fitness-assessments' },
    { name: 'Measurements', icon: <IoScaleSharp />, route: 'measurements', active: activeMenu === 'measurements' },
    { name: 'Messages', icon: <IoChatbubbleSharp />, route: 'messages', active: activeMenu === 'messages' },
  ];

  const renderMenuItem = (item, index) => {
    const menuItemStyle = item.active 
      ? (isCollapsed ? styles.menuItemCollapsed : styles.menuItemActive)
      : (isCollapsed ? styles.menuItemCollapsed : styles.menuItem);
    
    const menuTextStyle = item.active ? styles.menuTextActive : styles.menuText;

    return (
      <button
        key={index}
        style={menuItemStyle}
        onClick={() => handleMenuClick(item.route)}
        onMouseEnter={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'rgba(159, 192, 59, 0.1)';
          }
        }}
        onMouseLeave={(e) => {
          if (!item.active) {
            e.target.style.backgroundColor = 'transparent';
          }
        }}
      >
        <span style={styles.menuIcon}>{item.icon}</span>
        {!isCollapsed && (
          <span style={menuTextStyle}>
            {item.name}
          </span>
        )}
      </button>
    );
  };

  const filteredPlans = fitnessPlans.filter(plan =>
    plan.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div style={styles.container}>
      {/* Sidebar */}
      <div style={styles.sidebar}>
        {/* Brand */}
        <div style={styles.brand}>
          <img 
            src="/fnw1.png" 
            alt="FitNWell Logo"
            style={styles.brandIcon}
          />
          {!isCollapsed && (
            <span style={styles.brandText}>FitNWell</span>
          )}
        </div>

        {/* Menu Items */}
        <div style={styles.menuContainer}>
          <div style={styles.menuDivider} />
          
          <div style={styles.menuGroup}>
            {menuItems.slice(0, 7).map((item, index) => renderMenuItem(item, index))}
          </div>
        </div>

        {/* Logout Button */}
        <button 
          style={styles.logoutButton}
          onClick={onLogout}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#f5f5f5';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#fff';
          }}
        >
          <span style={styles.logoutIcon}><CiLogout /></span>
          {!isCollapsed && (
            <span style={styles.logoutText}>Log Out</span>
          )}
        </button>
      </div>

      {/* Main Content */}
      <div style={styles.mainContent}>
        {/* Header */}
        <div style={styles.header}>
          <button 
            style={styles.collapseButton}
            onClick={() => setIsCollapsed(!isCollapsed)}
          >
            {isCollapsed ? <FaChevronRight /> : <FaChevronLeft />}
          </button>
          <span style={styles.pageTitle}>Fitness Plans</span>
          <button style={styles.profileButton}
          onClick={() => navigate('/coach-user-profile')}
          >
            <FaUserCircle />
          </button>
        </div>

        {/* Search */}
        <div style={styles.searchContainer}>
          <div style={styles.searchBox}>
            <FaSearch style={styles.searchIcon} />
            <input
              type="text"
              placeholder="Search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={styles.searchInput}
            />
          </div>
        </div>

        {/* Fitness Plans Table */}
        <div style={styles.tableContainer}>
          <table style={styles.table}>
            <thead style={styles.tableHeader}>
              <tr>
                <th style={styles.tableHeaderCell}>ID</th>
                <th style={styles.tableHeaderCell}>Name</th>
                <th style={styles.tableHeaderCell}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredPlans.map((plan) => (
                <tr 
                  key={plan.id} 
                  style={styles.tableRow}
                  onMouseEnter={(e) => {
                    e.target.parentElement.style.backgroundColor = '#f8f9fa';
                  }}
                  onMouseLeave={(e) => {
                    e.target.parentElement.style.backgroundColor = 'transparent';
                  }}
                >
                  <td style={styles.tableCell}>{plan.id}</td>
                  <td style={styles.tableCell}>{plan.name}</td>
                  <td style={styles.tableCell}>
                    <div style={styles.actionButtons}>
                      <button 
                        style={styles.addButton}
                        onClick={() => openModal(plan)}
                        onMouseEnter={(e) => {
                          e.target.style.backgroundColor = '#87a333ff';
                        }}
                        onMouseLeave={(e) => {
                          e.target.style.backgroundColor = "#9FC03B";
                        }}
                      >
                        Add Exercise Plan
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Assign Fitness Plan Modal */}
      {showModal && (
        <div style={styles.overlay}>
          <div style={styles.modal}>
            <div style={styles.modalHeader}>
              <h3 style={styles.modalTitle}>Assign Fitness Plan</h3>
              <button 
                style={styles.closeButton}
                onClick={closeModal}
                onMouseEnter={(e) => {
                  e.target.style.color = '#666';
                }}
                onMouseLeave={(e) => {
                  e.target.style.color = '#333';
                }}
              >
                ✕
              </button>
            </div>
            
            <div style={styles.modalContent}>
              {/* Plan Title */}
              <div style={styles.formGroup}>
                <label style={styles.label}>Plan Title</label>
                <input
                  type="text"
                  style={styles.input}
                  value={formData.planTitle}
                  onChange={(e) => setFormData(prev => ({ ...prev, planTitle: e.target.value }))}
                />
              </div>

              {/* Start Date */}
              <div style={styles.formGroup}>
                <label style={styles.label}>Start Date</label>
                <input
                  type="date"
                  style={styles.input}
                  value={formData.startDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, startDate: e.target.value }))}
                />
              </div>

              {/* End Date */}
              <div style={styles.formGroup}>
                <label style={styles.label}>End Date</label>
                <input
                  type="date"
                  style={styles.input}
                  value={formData.endDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, endDate: e.target.value }))}
                />
              </div>

              {/* Days Selection */}
              <div style={styles.formGroup}>
                <div style={styles.daysContainer}>
                  {daysOfWeek.map((day) => (
                    <button
                      key={day}
                      style={{
                        ...styles.dayButton,
                        ...(formData.selectedDays.includes(day) 
                          ? styles.dayButtonActive 
                          : styles.dayButtonInactive)
                      }}
                      onClick={() => handleDayToggle(day)}
                    >
                      {day}
                    </button>
                  ))}
                </div>
              </div>

              {/* Warm Up Section */}
              <div style={styles.exerciseSection}>
                <div style={styles.exerciseSectionTitle}>Warm Up</div>
                {formData.warmUpExercises.map((exercise, index) => (
                  <div key={index} style={styles.exerciseItem}>
                    <input
                      type="text"
                      placeholder="Exercise Name"
                      style={styles.exerciseInput}
                      value={exercise.name}
                      onChange={(e) => updateWarmUpExercise(index, 'name', e.target.value)}
                    />
                    <input
                      type="text"
                      placeholder="Time (e.g., 1 min)"
                      style={styles.smallInput}
                      value={exercise.time}
                      onChange={(e) => updateWarmUpExercise(index, 'time', e.target.value)}
                    />
                    {formData.warmUpExercises.length > 1 && (
                      <button
                        style={styles.removeButton}
                        onClick={() => removeWarmUpExercise(index)}
                      >
                        Remove
                      </button>
                    )}
                  </div>
                ))}
                <button style={styles.addExerciseButton} onClick={addWarmUpExercise}>
                  + Add Warm Up Exercise
                </button>
              </div>

              {/* Main Exercise Section */}
              <div style={styles.exerciseSection}>
                <div style={styles.exerciseSectionTitle}>Main Exercise</div>
                {formData.mainExercises.map((exercise, index) => (
                  <div key={index} style={styles.exerciseItem}>
                    <input
                      type="text"
                      placeholder="Exercise Name"
                      style={styles.exerciseInput}
                      value={exercise.name}
                      onChange={(e) => updateMainExercise(index, 'name', e.target.value)}
                    />
                    <input
                      type="text"
                      placeholder="Sets"
                      style={styles.smallInput}
                      value={exercise.sets}
                      onChange={(e) => updateMainExercise(index, 'sets', e.target.value)}
                    />
                    <input
                      type="text"
                      placeholder="Reps"
                      style={styles.smallInput}
                      value={exercise.reps}
                      onChange={(e) => updateMainExercise(index, 'reps', e.target.value)}
                    />
                    {formData.mainExercises.length > 1 && (
                      <button
                        style={styles.removeButton}
                        onClick={() => removeMainExercise(index)}
                      >
                        Remove
                      </button>
                    )}
                  </div>
                ))}
                <button style={styles.addExerciseButton} onClick={addMainExercise}>
                  + Add Main Exercise
                </button>
              </div>

              {/* Cool Down Section */}
              <div style={styles.exerciseSection}>
                <div style={styles.exerciseSectionTitle}>Cool Down</div>
                {formData.coolDownExercises.map((exercise, index) => (
                  <div key={index} style={styles.exerciseItem}>
                    <input
                      type="text"
                      placeholder="Exercise Name"
                      style={styles.exerciseInput}
                      value={exercise.name}
                      onChange={(e) => updateCoolDownExercise(index, 'name', e.target.value)}
                    />
                    <input
                      type="text"
                      placeholder="Time (e.g., 1 min)"
                      style={styles.smallInput}
                      value={exercise.time}
                      onChange={(e) => updateCoolDownExercise(index, 'time', e.target.value)}
                    />
                    {formData.coolDownExercises.length > 1 && (
                      <button
                        style={styles.removeButton}
                        onClick={() => removeCoolDownExercise(index)}
                      >
                        Remove
                      </button>
                    )}
                  </div>
                ))}
                <button style={styles.addExerciseButton} onClick={addCoolDownExercise}>
                  + Add Cool Down Exercise
                </button>
              </div>
            </div>
            
            <div style={styles.modalFooter}>
              <button style={styles.saveButton} onClick={handleSave}>
                Save Plan
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Coach_PlanRequests;
