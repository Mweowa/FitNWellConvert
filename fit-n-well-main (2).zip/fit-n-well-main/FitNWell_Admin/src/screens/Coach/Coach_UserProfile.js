import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { colors } from '../../utils/colors';
import { FaUserCircle, FaHome, FaClipboardList, FaList, FaCamera, FaSave, FaEye, FaEyeSlash } from "react-icons/fa";
import { FaCalendarPlus } from "react-icons/fa6";
import { IoScaleSharp, IoChatbubbleSharp } from "react-icons/io5";
import { MdFactCheck } from "react-icons/md";
import { CiLogout } from "react-icons/ci";
import { FaChevronRight, FaChevronLeft } from "react-icons/fa";

const Coach_UserProfile = ({ onLogout }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [profileData, setProfileData] = useState({
    name: '',
    username: '',
    role: 'Admin',
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  
  const [profileImage, setProfileImage] = useState(null);
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setSaveLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');
  
  const fileInputRef = useRef(null);
  const navigate = useNavigate();

  const handleLogout = () => {
    onLogout();
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProfileData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setMessage('Image size should be less than 5MB');
        setMessageType('error');
        return;
      }
      
      const reader = new FileReader();
      reader.onload = (e) => {
        setProfileImage(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const validatePasswords = () => {
    if (profileData.newPassword && profileData.newPassword.length < 6) {
      setMessage('New password must be at least 6 characters long');
      setMessageType('error');
      return false;
    }
    
    if (profileData.newPassword !== profileData.confirmPassword) {
      setMessage('New password and confirm password do not match');
      setMessageType('error');
      return false;
    }
    
    return true;
  };

  const handleSaveChanges = async () => {
    if (!validatePasswords()) return;
    
    setSaveLoading(true);
    setMessage('');
    
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const dataToSave = {
        ...profileData,
        profileImage: profileImage
      };
      
      console.log('Saving profile data:', dataToSave);
      
      setMessage('Profile updated successfully!');
      setMessageType('success');
      
      setProfileData(prev => ({
        ...prev,
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      }));
      
    } catch (error) {
      setMessage('Failed to update profile. Please try again.');
      setMessageType('error');
    }
    
    setSaveLoading(false);
  };

  // Inline styles object matching your design system
  const styles = {
    container: {
      display: 'flex',
      flexDirection: 'row',
      height: '100vh',
      backgroundColor: '#FEFFFD',
      overflow: 'auto',
    },
    sidebar: {
      backgroundColor: '#F1F1F2',
      padding: '17px 15px',
      width: isCollapsed ? '80px' : '230px',
      transition: 'width 0.3s ease, padding 0.3s ease',
      display: 'flex',
      flexDirection: 'column',
    },
    brand: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '15px',
      padding: isCollapsed ? '0' : '0 10px',
      justifyContent: isCollapsed ? 'center' : 'flex-start',
    },
    brandIcon: {
      width: '47px',
      height: '40px',
    },
    brandText: {
      fontSize: '25px',
      color: colors.d_gray,
      fontWeight: 'bold',
      fontStyle: 'italic',
      marginLeft: '15px',
    },
    menuContainer: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
    },
    menuGroup: {
      marginBottom: '20px',
    },
    menuDivider: {
      height: '1px',
      backgroundColor: '#e0e0e0',
      marginBottom: '15px',
    },
    menuItem: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 10px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuItemCollapsed: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '12px 8px',
      borderRadius: '8px',
      marginBottom: '5px',
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      width: '100%',
      textAlign: 'left',
    },
    menuIcon: {
      fontSize: '20px',
      marginRight: isCollapsed ? '0' : '12px',
      color: colors.main,
      display: 'flex',
      alignItems: 'center',
    },
    menuText: {
      fontSize: '14px',
      color: colors.d_gray,
      display: 'flex',
      alignItems: 'center',
      lineHeight: '1',
    },
    logoutButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#fff',
      border: 'none',
      borderRadius: '30px',
      padding: isCollapsed ? '2px 3px' : '7px 12px',
      marginTop: '20px',
      marginBottom: '10px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      width: isCollapsed ? 'auto' : 'fit-content',
      alignSelf: 'center',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
    },
    logoutIcon: {
      background: 'none',
      fontSize: '18px',
      marginRight: isCollapsed ? '0' : '8px',
      display: 'flex',
      alignItems: 'center',
      color: colors.main,
    },
    logoutText: {
      background: 'none',
      fontSize: '14px',
      color: colors.d_gray,
      fontWeight: '500',
    },
    mainContent: {
      flex: 1,
      backgroundColor: '#FEFFFD',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '30px',
    },
    collapseButton: {
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      fontSize: '10px',
      color: colors.l_gray,
      transition: 'background-color 0.2s ease',
      marginLeft: '-10px'
    },
    greeting: {
      fontSize: '28px',
      fontWeight: 'bold',
      color: colors.main,
      marginBottom: '20px',
    },
    profileButton: {
      color: colors.main,      
      marginTop: '5px',
      marginRight: '5px',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontSize: '32px',
    },
    contentScrollView: {
      flex: 1,
      overflowY: 'auto',
    },
    profileContainer: {
      maxWidth: '600px',
      margin: '0 auto',
      backgroundColor: '#fff',
      borderRadius: '12px',
      padding: '30px',
      boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
    },
    profileImageSection: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      marginBottom: '30px',
    },
    profileImageContainer: {
      position: 'relative',
      marginBottom: '10px',
    },
    profileImage: {
      width: '120px',
      height: '120px',
      borderRadius: '50%',
      backgroundColor: '#f0f0f0',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      overflow: 'hidden',
      border: `3px solid ${colors.main}`,
    },
    profileImagePreview: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
    },
    profileImageIcon: {
      fontSize: '48px',
      color: colors.l_gray,
    },
    cameraButton: {
      position: 'absolute',
      bottom: '5px',
      right: '5px',
      backgroundColor: colors.main,
      color: '#fff',
      border: 'none',
      borderRadius: '50%',
      width: '35px',
      height: '35px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
      fontSize: '14px',
      boxShadow: '0 2px 5px rgba(0, 0, 0, 0.2)',
      transition: 'background-color 0.2s ease',
    },
    uploadHint: {
      fontSize: '12px',
      color: colors.l_gray,
      textAlign: 'center',
    },
    formGroup: {
      marginBottom: '20px',
    },
    label: {
      display: 'block',
      fontSize: '14px',
      fontWeight: '600',
      color: colors.d_gray,
      marginBottom: '8px',
    },
    input: {
      width: '100%',
      padding: '12px 15px',
      border: `2px solid #e0e0e0`,
      borderRadius: '8px',
      fontSize: '14px',
      color: colors.d_gray,
      backgroundColor: '#fff',
      transition: 'border-color 0.2s ease',
      boxSizing: 'border-box',
    },
    inputFocus: {
      borderColor: colors.main,
      outline: 'none',
    },
    select: {
      width: '100%',
      padding: '12px 15px',
      border: `2px solid #e0e0e0`,
      borderRadius: '8px',
      fontSize: '14px',
      color: colors.d_gray,
      backgroundColor: '#fff',
      transition: 'border-color 0.2s ease',
      boxSizing: 'border-box',
      cursor: 'pointer',
    },
    passwordContainer: {
      position: 'relative',
    },
    passwordToggle: {
      position: 'absolute',
      right: '15px',
      top: '50%',
      transform: 'translateY(-50%)',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: colors.l_gray,
      fontSize: '14px',
    },
    sectionDivider: {
      height: '1px',
      backgroundColor: '#e0e0e0',
      margin: '30px 0 20px 0',
    },
    sectionTitle: {
      fontSize: '18px',
      fontWeight: '600',
      color: colors.d_gray,
      marginBottom: '20px',
    },
    message: {
      padding: '12px 15px',
      borderRadius: '8px',
      marginBottom: '20px',
      fontSize: '14px',
      fontWeight: '500',
    },
    messageSuccess: {
      backgroundColor: 'rgba(159, 192, 59, 0.1)',
      color: colors.main,
      border: `1px solid ${colors.main}`,
    },
    messageError: {
      backgroundColor: 'rgba(220, 53, 69, 0.1)',
      color: '#dc3545',
      border: '1px solid #dc3545',
    },
    saveButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: colors.main,
      color: '#fff',
      border: 'none',
      borderRadius: '8px',
      padding: '12px 30px',
      fontSize: '14px',
      fontWeight: '600',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease',
      margin: '0 auto',
      minWidth: '150px',
    },
    saveButtonDisabled: {
      backgroundColor: colors.l_gray,
      cursor: 'not-allowed',
    },
    saveButtonIcon: {
      marginRight: '8px',
      fontSize: '14px',
    },
    loadingSpinner: {
      width: '16px',
      height: '16px',
      border: '2px solid #fff',
      borderTop: '2px solid transparent',
      borderRadius: '50%',
      animation: 'spin 1s linear infinite',
      marginRight: '8px',
    },
    hiddenInput: {
      display: 'none',
    },
  };

  const menuItems = [
    { name: 'Dashboard', icon: <FaHome /> },
    { name: 'Plan Request', icon: <FaCalendarPlus /> },
    { name: 'Fitness Plans', icon: <FaList/> },
    { name: 'Activity Logs', icon: <FaClipboardList/> },
    { name: 'Fitness Assessments', icon: <MdFactCheck /> },
    { name: 'Measurements', icon: <IoScaleSharp /> },
    { name: 'Messages', icon: <IoChatbubbleSharp /> },
  ];

  const renderMenuItem = (item, index) => {
    const menuItemStyle = isCollapsed ? styles.menuItemCollapsed : styles.menuItem;

    const handleMenuClick = () => {
      console.log(`Clicked: ${item.name}`);
      switch(item.name) {
        case 'Dashboard':
          navigate('/coach-dashboard');
          break;
        case 'Plan Request':
          navigate('/coach-plan-requests');
          break;
        case 'Fitness Plans':
          navigate('/coach-fitness-plans');
          break;
        case 'Activity Logs':
          navigate('/coach-activity-logs');
          break;
        case 'Fitness Assessments':
          navigate('/coach-fitness-assessments');
          break;
        case 'Measurements':
          navigate('/coach-measurements');
          break;
        case 'Messages':
          navigate('/coach-messages');
          break;
        default:
          console.log('Menu item clicked');
      }
    };

    return (
      <button
        key={index}
        style={menuItemStyle}
        onClick={handleMenuClick}
        onMouseEnter={(e) => {
          e.target.style.backgroundColor = 'rgba(159, 192, 59, 0.1)';
        }}
        onMouseLeave={(e) => {
          e.target.style.backgroundColor = 'transparent';
        }}
      >
        <span style={styles.menuIcon}>{item.icon}</span>
        {!isCollapsed && (
          <span style={styles.menuText}>
            {item.name}
          </span>
        )}
      </button>
    );
  };

  return (
    <div style={styles.container}>
      {/* Sidebar */}
      <div style={styles.sidebar}>
        {/* Brand */}
        <div style={styles.brand}>
          <img 
            src="/fnw1.png" 
            alt="FitNWell Logo"
            style={styles.brandIcon}
          />
          {!isCollapsed && (
            <span style={styles.brandText}>FitNWell</span>
          )}
        </div>

        {/* Menu Items */}
        <div style={styles.menuContainer}>
          <div style={styles.menuDivider} />
          
          <div style={styles.menuGroup}>
            {menuItems.slice(0, 7).map((item, index) => renderMenuItem(item, index))}
          </div>
          
          <div style={styles.menuGroup}>
            {menuItems.slice(7).map((item, index) => renderMenuItem(item, index + 7))}
          </div>
        </div>

        {/* Logout Button */}
        <button 
          style={styles.logoutButton}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#f5f5f5';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#fff';
          }}
          onClick={handleLogout}
        >
          <span style={styles.logoutIcon}><CiLogout /></span>
          {!isCollapsed && (
            <span style={styles.logoutText}>Log Out</span>
          )}
        </button>
      </div>

      {/* Main Content */}
      <div style={styles.mainContent}>
        {/* Header */}
        <div style={styles.header}>
          <button 
            style={styles.collapseButton}
            onClick={() => setIsCollapsed(!isCollapsed)}
          >
            {isCollapsed ? <FaChevronRight /> : <FaChevronLeft />}
          </button>
          <span style={styles.greeting}>Admin Profile</span>
          <button style={styles.profileButton}
          onClick={() => navigate('/coach-user-profile')}
          >
            <FaUserCircle />
          </button>
        </div>

        {/* Content Area */}
        <div style={styles.contentScrollView}>
          <div style={styles.profileContainer}>
            
            {/* Profile Image Section */}
            <div style={styles.profileImageSection}>
              <div style={styles.profileImageContainer}>
                <div style={styles.profileImage}>
                  {profileImage ? (
                    <img 
                      src={profileImage} 
                      alt="Profile" 
                      style={styles.profileImagePreview}
                    />
                  ) : (
                    <FaUserCircle style={styles.profileImageIcon} />
                  )}
                </div>
                <button
                  style={styles.cameraButton}
                  onClick={() => fileInputRef.current?.click()}
                  onMouseEnter={(e) => {
                    e.target.style.backgroundColor = '#8ab83f';
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.backgroundColor = colors.main;
                  }}
                >
                  <FaCamera />
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  style={styles.hiddenInput}
                />
              </div>
              <div style={styles.uploadHint}>Click camera icon to upload photo</div>
            </div>

            {/* Message Display */}
            {message && (
              <div style={{
                ...styles.message,
                ...(messageType === 'success' ? styles.messageSuccess : styles.messageError)
              }}>
                {message}
              </div>
            )}

            {/* Basic Information */}
            <div style={styles.formGroup}>
              <label style={styles.label}>Name</label>
              <input
                type="text"
                name="name"
                value={profileData.name}
                onChange={handleInputChange}
                style={styles.input}
                placeholder="Enter your full name"
                onFocus={(e) => e.target.style.borderColor = colors.main}
                onBlur={(e) => e.target.style.borderColor = '#e0e0e0'}
              />
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>Username</label>
              <input
                type="text"
                name="username"
                value={profileData.username}
                onChange={handleInputChange}
                style={styles.input}
                placeholder="Enter your username"
                onFocus={(e) => e.target.style.borderColor = colors.main}
                onBlur={(e) => e.target.style.borderColor = '#e0e0e0'}
              />
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>Role</label>
              <select
                name="role"
                value={profileData.role}
                onChange={handleInputChange}
                style={styles.select}
                onFocus={(e) => e.target.style.borderColor = colors.main}
                onBlur={(e) => e.target.style.borderColor = '#e0e0e0'}
              >
                <option value="CHK Admin">CHK Admin</option>
                <option value="Coach">Coach</option>
                <option value="MP Admin">MP Admin</option>
              </select>
            </div>

            {/* Password Section */}
            <div style={styles.sectionDivider} />
            <h3 style={styles.sectionTitle}>Change Password</h3>
            
            <div style={styles.formGroup}>
              <label style={styles.label}>Current Password</label>
              <div style={styles.passwordContainer}>
                <input
                  type={showCurrentPassword ? "text" : "password"}
                  name="currentPassword"
                  value={profileData.currentPassword}
                  onChange={handleInputChange}
                  style={styles.input}
                  placeholder="Enter current password"
                  onFocus={(e) => e.target.style.borderColor = colors.main}
                  onBlur={(e) => e.target.style.borderColor = '#e0e0e0'}
                />
                <button
                  type="button"
                  style={styles.passwordToggle}
                  onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                >
                  {showCurrentPassword ? <FaEyeSlash /> : <FaEye />}
                </button>
              </div>
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>New Password</label>
              <div style={styles.passwordContainer}>
                <input
                  type={showNewPassword ? "text" : "password"}
                  name="newPassword"
                  value={profileData.newPassword}
                  onChange={handleInputChange}
                  style={styles.input}
                  placeholder="Enter new password (min 6 characters)"
                  onFocus={(e) => e.target.style.borderColor = colors.main}
                  onBlur={(e) => e.target.style.borderColor = '#e0e0e0'}
                />
                <button
                  type="button"
                  style={styles.passwordToggle}
                  onClick={() => setShowNewPassword(!showNewPassword)}
                >
                  {showNewPassword ? <FaEyeSlash /> : <FaEye />}
                </button>
              </div>
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>Confirm New Password</label>
              <div style={styles.passwordContainer}>
                <input
                  type={showConfirmPassword ? "text" : "password"}
                  name="confirmPassword"
                  value={profileData.confirmPassword}
                  onChange={handleInputChange}
                  style={styles.input}
                  placeholder="Confirm new password"
                  onFocus={(e) => e.target.style.borderColor = colors.main}
                  onBlur={(e) => e.target.style.borderColor = '#e0e0e0'}
                />
                <button
                  type="button"
                  style={styles.passwordToggle}
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                >
                  {showConfirmPassword ? <FaEyeSlash /> : <FaEye />}
                </button>
              </div>
            </div>

            {/* Save Button */}
            <button
              onClick={handleSaveChanges}
              disabled={isLoading}
              style={{
                ...styles.saveButton,
                ...(isLoading ? styles.saveButtonDisabled : {})
              }}
              onMouseEnter={(e) => {
                if (!isLoading) {
                  e.target.style.backgroundColor = '#8ab83f';
                }
              }}
              onMouseLeave={(e) => {
                if (!isLoading) {
                  e.target.style.backgroundColor = colors.main;
                }
              }}
            >
              {isLoading ? (
                <>
                  <div style={styles.loadingSpinner}></div>
                  Saving...
                </>
              ) : (
                <>
                  <FaSave style={styles.saveButtonIcon} />
                  Save Changes
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* CSS Animation for spinner */}
      <style>
        {`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}
      </style>
    </div>
  );
};

export default Coach_UserProfile;